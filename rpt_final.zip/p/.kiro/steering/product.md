---
inclusion: always
---

# Product Rules — Deep Learning-Based Intelligent Vehicle Surveillance System

## Project Identity

**Full title:** Deep Learning-Based Intelligent Vehicle Surveillance System  
**Sub-systems:** YOLO11 object detection · ByteTrack multi-object tracking · EasyOCR ANPR (Indian plates) · Multi-frame majority-vote plate validation · Watchlist database · Simulated SMS alerts  
**Primary deliverable:** A research dashboard that presents, explains, and evaluates all system components for academic reviewers and conference audiences.

---

## Audience

Audience is **academic reviewers and conference audiences**. Every design decision must prioritise:

1. **Credibility over flash.** No decorative metrics, no faked results, no inflated numbers.
2. **Reproducibility.** Every number shown must be traceable to a data source, a simulation, or an explicit placeholder.
3. **Transparency.** The dashboard must always be honest about what is real, what is simulated, and what is not yet implemented.

---

## Provenance Tags (NON-NEGOTIABLE)

Every metric, KPI, chart value, and status indicator displayed in the UI **must** carry exactly one provenance tag:

| Tag | Meaning | Visual style |
|-----|---------|--------------|
| `MEASURED` | Value derived from real dataset processing | Solid cyan badge |
| `SIMULATED` | Value produced by a deterministic simulation or Monte Carlo model | Amber badge with italic label |
| `PLACEHOLDER` | Hard-coded stand-in; not yet connected to real data | Red/orange badge, dashed border |
| `DEMO` | Value from the seeded demo-data module | Purple badge |

**Rules:**
- A `PLACEHOLDER` or `DEMO` value must **never** visually resemble a `MEASURED` value.
- While **any** `PLACEHOLDER` value is visible on screen, a **persistent warning banner** must appear at the top of the main content area. The banner must state that placeholder data is present and must not be dismissed.
- Provenance tags must be rendered as the `ProvenanceBadge` component defined in the shared component library.

---

## SMS Alerts — Simulation Only

- SMS alerts are **simulated only**.
- **Never** integrate a real messaging provider (Twilio, AWS SNS, Firebase, etc.).
- Simulated alerts must be clearly labelled "SIMULATED" in the UI.
- The alert log may be written to `outputs/alerts.csv`; it must never trigger an actual network call to an external messaging endpoint.

---

## Privacy & Ethics Notice

Every page of the dashboard must be reachable from a persistent **Privacy & Ethics** notice accessible via the sidebar or top bar. The notice must state:

> This system is developed for academic research purposes. It processes vehicle images and licence plate data. All datasets used are publicly available research benchmarks. No personally identifiable information is stored beyond what is required for academic evaluation. Surveillance technologies carry significant civil-liberties implications; responsible deployment requires appropriate legal authorisation, oversight, and data-minimisation practices.

---

## 5-Phase Roadmap (non-negotiable order)

| Phase | Title | Key deliverables |
|-------|-------|-----------------|
| 1 | **Foundation** | Scaffolding, app shell, shared components, demo mode, PlateValidator service, README |
| 2 | **ANPR Lab + Validation Simulator** | OCR upload/test page, multi-frame validation simulator page |
| 3 | **Detection & Tracking + Dataset Explorer** | Live/batch detection page, dataset explorer page |
| 4 | **Watchlist & Alerts + Overview** | Watchlist management page, simulated alert log page, overview/dashboard page |
| 5 | **Evaluation + Report + Methodology + QA** | Evaluation metrics page, report export, methodology page, full QA pass |

Pages for future phases must show a polished **"Coming in Phase N"** empty state — not a blank screen, not a 404.

---

## General Non-Negotiables

- No hardcoded file paths anywhere in application code. All paths via `config.py` + `.env`.
- No external network calls at runtime except the first-time model weight download (ultralytics cache).
- Upload inputs must have size and MIME-type validation with clear error messages.
- Every metric exposed by the backend must record its `provenance` field in its Pydantic response model.
