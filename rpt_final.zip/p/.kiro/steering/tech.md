---
inclusion: always
---

# Tech Stack — Deep Learning-Based Intelligent Vehicle Surveillance System

## Backend

| Component | Choice | Notes |
|-----------|--------|-------|
| Language | Python 3.10+ | Type hints required everywhere |
| Web framework | FastAPI | App-factory pattern; lifespan for startup/shutdown |
| Server | Uvicorn | Dev: `--reload`; prod: workers via config |
| Validation | Pydantic v2 | All request/response models; `model_config` not `class Config` |
| Detection | ultralytics YOLO11n + ByteTrack | Load once at startup, never per request |
| OCR | easyocr | GPU if available; CPU fallback required |
| Image processing | opencv-python-headless | No GUI dependencies |
| Data | pandas, numpy | For dataset loading and metric aggregation |
| ML utilities | scikit-learn | Metrics, confusion matrix |
| Config | `backend/app/core/config.py` + `.env` | Pydantic `BaseSettings`; no hardcoded paths |
| Logging | Python `logging` + JSON formatter | Structured; every run logs config, seed, model version, timestamp |

### Backend rules
- **Models load once** at application lifespan startup; never inside a request handler.
- **CUDA optional**: detect `torch.cuda.is_available()`; fall back to CPU silently with a log warning.
- **Graceful degradation**: missing dataset files, missing model weights, or corrupt images must return structured error responses (never 500 crashes with stack traces exposed to the client).
- Pydantic response models must include a `provenance: Literal["MEASURED","SIMULATED","PLACEHOLDER","DEMO"]` field on every metric-bearing model.
- All file I/O paths derived from config; never `os.path.join("../datasets/...")` literals in service code.
- Upload endpoints: validate MIME type (`image/jpeg`, `image/png`) and max size (configurable, default 10 MB).
- No external network calls at runtime (model weights may download on first startup from ultralytics cache — acceptable).

---

## Frontend

| Component | Choice | Notes |
|-----------|--------|-------|
| Framework | React 18 + TypeScript | Strict mode; `strict: true` in tsconfig |
| Build tool | Vite | Fast HMR; `vite.config.ts` |
| Styling | Tailwind CSS | Custom theme tokens (see Design Standards) |
| Component library | shadcn/ui | Add components with `npx shadcn-ui@latest add` |
| Charts | Recharts | All charts wrapped in `ChartCard` with PNG export |
| Data fetching | TanStack Query v5 | `QueryClient` at root; stale-time 30 s default |
| Routing | React Router v6 | `createBrowserRouter` pattern |
| Icons | lucide-react | No other icon library |
| State | React context + hooks | No Redux; server state via TanStack Query |

### Frontend rules
- TypeScript strict mode; no `any` except in explicit escape-hatch files (comment required).
- All data-fetching via TanStack Query hooks in `src/hooks/`; no raw `fetch` in components.
- Every page that can show loading state must use **skeleton loaders** (not spinners alone).
- Every page that can be empty must use the `EmptyState` shared component.
- All user-facing errors surfaced via **toast** notifications (shadcn/ui Toast).
- Components must be keyboard-accessible; interactive elements need visible focus rings.
- WCAG AA contrast required for all text/background combinations.

---

## Design Standards (apply to ALL phases)

### Theme tokens (Tailwind config + CSS variables)

```
--color-navy:      #0B1220   (page background)
--color-surface:   #111A2E   (card/panel background)
--color-accent:    #22D3EE   (primary accent / cyan)
--color-authorized: #22C55E  (green — authorized plates)
--color-unknown:   #F59E0B   (amber — unknown plates)
--color-watchlist: #EF4444   (red — watchlist hits)
--color-text:      #E2E8F0   (primary text)
--color-muted:     #64748B   (secondary/muted text)
```

Typography: **Inter** (Google Fonts or local). Font scale follows Tailwind defaults.  
Grid: **8 px base grid**. All spacing values multiples of 8 px.  
Border radius: `rounded-lg` (8 px) for cards; `rounded-md` (6 px) for inputs/buttons.

### Theme toggle
A **light/dark toggle** must be present in the top bar. Dark is the default ("security operations center" aesthetic).

### Component checklist (every page)
- [ ] Skeleton loader while data is loading
- [ ] `EmptyState` when no data
- [ ] `ProvenanceBadge` on every metric
- [ ] Toast for async errors
- [ ] Keyboard-navigable

---

## Testing

| Layer | Tool | Location |
|-------|------|----------|
| Backend unit | pytest | `backend/tests/` |
| Frontend unit/component | Vitest + React Testing Library | `frontend/src/__tests__/` |

- Backend tests use `pytest-asyncio` for async endpoints.
- Frontend tests run with `vitest --run` (non-watch) in CI.
- No test may make real network calls or touch the filesystem outside `tmp` fixtures.

---

## Linting & Formatting

| Tool | Config file | Scope |
|------|-------------|-------|
| Ruff | `pyproject.toml` | Python lint |
| Black | `pyproject.toml` | Python format |
| ESLint | `.eslintrc.cjs` | TypeScript/TSX lint |
| Prettier | `.prettierrc` | TypeScript/TSX/JSON/CSS format |

---

## Dev Runner

One command starts both servers:

```bash
# Option A — npm concurrently (cross-platform)
npm run dev          # from project root

# Option B — make
make dev
```

The root `package.json` uses `concurrently` to run:
- `uvicorn backend.app.main:app --reload --port 8000`
- `vite --port 5173` (from `frontend/`)

---

## Environment

- Runs locally on **Windows, macOS, Linux**.
- CUDA: used if available; CPU fallback must work without any manual configuration.
- Python env: `venv` or `conda`; requirements pinned in `backend/requirements.txt`.
- Node: `>=18`; dependencies pinned in `frontend/package.json` lockfile.
