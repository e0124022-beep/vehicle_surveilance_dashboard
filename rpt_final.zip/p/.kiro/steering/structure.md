---
inclusion: always
---

# Project Structure — Deep Learning-Based Intelligent Vehicle Surveillance System

## ⚠️ Golden Rule

> **Never modify, move, rename, delete, or reformat any file or directory under `vehicle_surveillance_project/datasets/` or `vehicle_surveillance_project/outputs/`.** These are pre-existing research artefacts. All application code must treat them as read-only sources.

---

## Root Layout

```
vehicle_surveilance_dashboard/          ← workspace root
├── vehicle_surveillance_project/       ← research artefacts (READ-ONLY)
│   ├── datasets/
│   │   ├── ua_detrac/
│   │   │   └── DETRAC-Images/
│   │   │       └── DETRAC-Images/
│   │   │           └── MVI_xxxxx/
│   │   │               └── imgNNNNN.jpg
│   │   └── indian_plates/              ← Indian plate image samples
│   └── outputs/
│       ├── alerts.csv
│       ├── ocr_validation_simulation.csv
│       ├── validation_comparison.csv
│       ├── photo_anpr_result.csv
│       ├── detected_plate_crop.png
│       └── evidence/                   ← cropped plate evidence images
│
├── backend/                            ← FastAPI application
│   ├── app/
│   │   ├── main.py                     ← app factory + lifespan
│   │   ├── core/
│   │   │   ├── config.py               ← Pydantic BaseSettings
│   │   │   └── logging.py              ← structured JSON logger
│   │   ├── api/
│   │   │   ├── v1/
│   │   │   │   ├── router.py           ← include all sub-routers
│   │   │   │   ├── health.py           ← GET /api/v1/health
│   │   │   │   └── config_endpoint.py  ← GET /api/v1/config (Phase 1)
│   │   ├── services/
│   │   │   ├── plate_validator.py      ← PlateValidator (deque, majority vote)
│   │   │   ├── plate_classifier.py     ← authorized / watchlist / unauthorized
│   │   │   ├── monte_carlo.py          ← seeded Monte Carlo simulation
│   │   │   └── demo_data.py            ← seed-data module for demo mode
│   │   └── models/                     ← Pydantic request/response schemas
│   │       ├── health.py
│   │       └── common.py               ← ProvenanceEnum, base response types
│   ├── tests/
│   │   ├── conftest.py
│   │   ├── test_plate_validator.py
│   │   ├── test_plate_classifier.py
│   │   └── test_monte_carlo.py
│   ├── requirements.txt
│   └── pyproject.toml                  ← Ruff + Black config
│
├── frontend/                           ← React + Vite application
│   ├── index.html
│   ├── vite.config.ts
│   ├── tsconfig.json
│   ├── tailwind.config.ts
│   ├── postcss.config.cjs
│   ├── .eslintrc.cjs
│   ├── .prettierrc
│   ├── package.json
│   └── src/
│       ├── main.tsx                    ← React entry + QueryClient
│       ├── App.tsx                     ← router + shell layout
│       ├── pages/
│       │   ├── Overview.tsx            ← Phase 4
│       │   ├── AnprLab.tsx             ← Phase 2
│       │   ├── ValidationSimulator.tsx ← Phase 2
│       │   ├── Detection.tsx           ← Phase 3
│       │   ├── DatasetExplorer.tsx     ← Phase 3
│       │   ├── Watchlist.tsx           ← Phase 4
│       │   ├── Alerts.tsx              ← Phase 4
│       │   ├── Evaluation.tsx          ← Phase 5
│       │   └── ComingSoon.tsx          ← reusable "Phase N" empty state
│       ├── components/
│       │   ├── layout/
│       │   │   ├── Sidebar.tsx
│       │   │   ├── TopBar.tsx
│       │   │   └── ShellLayout.tsx
│       │   ├── shared/
│       │   │   ├── ProvenanceBadge.tsx
│       │   │   ├── PlaceholderBanner.tsx
│       │   │   ├── KpiCard.tsx
│       │   │   ├── StatusBadge.tsx
│       │   │   ├── ChartCard.tsx
│       │   │   └── EmptyState.tsx
│       │   └── ui/                     ← shadcn/ui generated components
│       ├── hooks/
│       │   ├── useHealth.ts
│       │   └── useConfig.ts
│       ├── lib/
│       │   ├── api.ts                  ← axios/fetch base client
│       │   ├── queryClient.ts
│       │   └── utils.ts                ← cn() and other helpers
│       └── styles/
│           └── globals.css             ← Tailwind directives + CSS vars
│
├── .kiro/
│   ├── steering/
│   │   ├── product.md
│   │   ├── tech.md
│   │   └── structure.md
│   └── specs/
│       └── vehicle-surveillance/
│           ├── requirements.md
│           ├── design.md
│           └── tasks.md
│
├── package.json                        ← root; concurrently dev script
├── Makefile                            ← `make dev`, `make test`
├── .env.example
└── README.md
```

---

## Naming Conventions

| Layer | Convention | Example |
|-------|-----------|---------|
| Python modules | `snake_case` | `plate_validator.py` |
| Python classes | `PascalCase` | `PlateValidator` |
| React components | `PascalCase.tsx` | `ProvenanceBadge.tsx` |
| React hooks | `camelCase`, prefix `use` | `useHealth.ts` |
| Tailwind CSS classes | utility-first, no custom classes except tokens | — |
| API routes | `/api/v1/<resource>` | `/api/v1/health` |
| Env vars | `UPPER_SNAKE_CASE` | `BACKEND_PORT`, `DEMO_MODE` |

---

## Config & Environment Variables (`.env.example`)

```dotenv
# Application
APP_ENV=development
DEBUG=true
DEMO_MODE=true

# Paths (relative to project root or absolute)
DATASETS_ROOT=../vehicle_surveillance_project/datasets
OUTPUTS_ROOT=../vehicle_surveillance_project/outputs

# Server
BACKEND_HOST=0.0.0.0
BACKEND_PORT=8000
FRONTEND_PORT=5173

# Model
YOLO_MODEL_PATH=yolo11n.pt
YOLO_CONFIDENCE=0.5
DEVICE=auto   # auto | cpu | cuda

# Plate Validator
VALIDATOR_WINDOW=7
VALIDATOR_MIN_CONF=0.70

# Upload limits
MAX_UPLOAD_SIZE_MB=10
```

---

## Output Files (read-only references for the backend)

The backend reads — never writes — from:

| File | Content |
|------|---------|
| `outputs/alerts.csv` | Simulated alert log |
| `outputs/ocr_validation_simulation.csv` | Frame-by-frame OCR simulation results |
| `outputs/validation_comparison.csv` | Single-frame vs multi-frame comparison |
| `outputs/photo_anpr_result.csv` | Static photo ANPR results |
| `outputs/detected_plate_crop.png` | Representative cropped plate image |
| `outputs/evidence/` | Per-detection evidence crops |

Demo mode (`DEMO_MODE=true`) generates synthetic equivalents of these files in memory; it never writes to the real paths.
