# Tasks — Deep Learning-Based Intelligent Vehicle Surveillance System (Phase 1)

**Phase:** 1 — Foundation  
**Version:** 1.0  
**Date:** 2026-10-25  
**Requirements:** `requirements.md` | **Design:** `design.md`

---

## Conventions

- Tasks are ordered; each is independently testable before moving to the next.
- Every task lists its **Requirement IDs**, **Acceptance Test**, and **Done When** condition.
- "Done When" is the minimum verifiable state — not aspirational completeness.
- Tasks marked `[BE]` are backend-only, `[FE]` frontend-only, `[BOTH]` touch both.

---

## Group A — Project Scaffolding

### TASK-01 · Root workspace layout `[BOTH]`

**Req IDs:** REQ-BE-08, REQ-DV-01, REQ-DV-02, REQ-RM-01

Create the top-level files that glue both sub-projects together.

**Files to create:**
- `.env.example` — all env vars from design.md §2 with descriptions and defaults
- `package.json` (root) — `dev`, `dev:api`, `dev:ui` scripts using `concurrently`
- `Makefile` — `dev`, `test`, `lint` targets
- `README.md` — all 11 sections from REQ-RM-01 (placeholder content for sections not yet built)

**Acceptance test:**
```bash
cat .env.example          # shows every variable with a default
node -e "require('./package.json').scripts.dev"   # prints the concurrently command
make -n dev               # dry-run prints the npm run dev command
```

**Done when:** `.env.example`, root `package.json`, `Makefile`, and `README.md` all exist and are syntactically valid.

---

### TASK-02 · Backend Python project skeleton `[BE]`

**Req IDs:** REQ-BE-01, REQ-BE-06, REQ-BE-08

Create the Python package structure with empty/stub files.

**Files to create:**
```
backend/
  app/__init__.py
  app/main.py              # stub: create_app() returns FastAPI()
  app/core/__init__.py
  app/core/config.py       # stub: class Settings(BaseSettings)
  app/core/logging.py      # stub: get_logger()
  app/api/__init__.py
  app/api/v1/__init__.py
  app/api/v1/router.py     # stub: APIRouter
  app/api/v1/health.py     # stub: router with GET /health
  app/api/v1/config_endpoint.py  # stub
  app/services/__init__.py
  app/models/__init__.py
  app/models/common.py     # ProvenanceEnum, ProvenanceMixin, ErrorResponse
  app/models/health.py     # HealthResponse, ConfigResponse stubs
  tests/__init__.py
  tests/conftest.py        # empty conftest
  requirements.txt         # pinned deps
  pyproject.toml           # Ruff + Black config
```

**Acceptance test:**
```bash
cd backend
python -m pytest tests/ -v   # 0 tests collected, 0 errors
python -c "from app.main import create_app; create_app()"   # no ImportError
```

**Done when:** `cd backend && python -c "from app.main import create_app"` succeeds without errors.

---

### TASK-03 · Frontend Vite + React + TypeScript scaffold `[FE]`

**Req IDs:** REQ-FE-01, REQ-FE-02

Bootstrap the frontend project.

**Steps:**
1. `npm create vite@latest frontend -- --template react-ts`
2. Install Tailwind CSS, PostCSS, Autoprefixer
3. Install core deps: `react-router-dom`, `@tanstack/react-query`, `lucide-react`, `recharts`, `axios`
4. Install dev deps: `vitest`, `@testing-library/react`, `@testing-library/jest-dom`, `jsdom`, `eslint`, `prettier`
5. Configure `tsconfig.json` with `strict: true`
6. Configure `tailwind.config.ts` with custom design tokens from design.md §5
7. Write `src/styles/globals.css` with all CSS custom properties (dark + light theme)
8. Configure `.eslintrc.cjs` and `.prettierrc`

**Acceptance test:**
```bash
cd frontend && npm run build   # exits 0 with no TS errors
```

**Done when:** `npm run build` in `frontend/` completes without TypeScript or Tailwind errors.

---

### TASK-04 · shadcn/ui initialisation `[FE]`

**Req IDs:** REQ-FE-01, REQ-SC-05

Initialise shadcn/ui and add the components needed for Phase 1.

**Steps:**
1. `npx shadcn-ui@latest init` (choose: TypeScript, Tailwind, `src/components/ui/`)
2. Add components: `npx shadcn-ui@latest add badge button card skeleton toast`
3. Verify `components/ui/` contains the generated files
4. Add `Toaster` to `src/main.tsx`

**Acceptance test:**
```bash
cd frontend && npm run build   # still exits 0
grep -r "Skeleton" src/components/ui/   # file exists
```

**Done when:** shadcn/ui `skeleton` and `toast` components exist in `src/components/ui/`.

---

## Group B — Backend Core

### TASK-05 · Pydantic Settings + .env loading `[BE]`

**Req IDs:** REQ-BE-06, REQ-BE-07, REQ-BE-08, REQ-BE-04

Implement `backend/app/core/config.py`.

**Requirements:**
- All env vars from `.env.example` as typed fields with defaults
- `DEMO_MODE: bool = True` for safe local defaults
- `DATASETS_ROOT`, `OUTPUTS_ROOT` as `Path` fields
- Validator that raises `ValueError` for obviously invalid paths in production mode
- Export a `get_settings()` cached function using `@lru_cache`

**Acceptance test:**
```bash
cd backend
cp ../.env.example ../.env
python -c "from app.core.config import get_settings; s = get_settings(); print(s.demo_mode)"
# prints: True
```

**Done when:** `get_settings()` returns a populated `Settings` object without error when `.env` is present.

---

### TASK-06 · Structured JSON logger `[BE]`

**Req IDs:** REQ-BE-05

Implement `backend/app/core/logging.py`.

**Requirements:**
- `get_logger(name: str) -> logging.Logger`
- JSON formatter with fields: `timestamp` (ISO 8601), `level`, `logger`, `message`, `context`
- Log level configurable via `LOG_LEVEL` env var (default `INFO`)
- No colour codes in output (structured JSON only)

**Acceptance test:**
```bash
cd backend
python -c "
import json, logging
from app.core.logging import get_logger
logger = get_logger('test')
# Capture output — should be parseable JSON
"
# Manual: run and verify output line is valid JSON with timestamp/level/logger/message
```

**Done when:** `get_logger('test').info('hello')` emits a single JSON line parseable by `json.loads()`.

---

### TASK-07 · FastAPI app factory + lifespan `[BE]`

**Req IDs:** REQ-BE-01, REQ-BE-02, REQ-BE-03, REQ-BE-09, REQ-BE-10

Implement `backend/app/main.py`.

**Requirements:**
- `create_app()` function returns a configured `FastAPI` instance
- Lifespan context manager: log startup info (version, demo_mode, device, seed, timestamp), set `app.state.start_time`, load model stubs (YOLO + EasyOCR — skip actual load, just set `models_loaded` flags)
- CORS middleware: allow origin from `settings.frontend_url` (default `http://localhost:5173`)
- Request-ID middleware: generate UUID, attach as `X-Request-ID` request/response header
- Include `/api/v1` router

**Acceptance test:**
```bash
cd backend
uvicorn app.main:app --port 8000 &
sleep 2
curl -s http://localhost:8000/api/v1/health   # returns JSON (even if stub)
curl -si http://localhost:8000/api/v1/health | grep X-Request-ID   # header present
pkill -f uvicorn
```

**Done when:** Uvicorn starts without errors, `X-Request-ID` header appears on every response.

---

### TASK-08 · `/health` and `/config` endpoints `[BE]`

**Req IDs:** REQ-BE-11, REQ-BE-12, REQ-BE-13

Implement `backend/app/api/v1/health.py` and `config_endpoint.py`.

**`/health` must return:**
- `status: "ok"` | `"degraded"` based on `app.state.models_loaded`
- `version`, `demo_mode`, `uptime_seconds` (computed from `app.state.start_time`), `models_loaded`, `errors: []`, `timestamp`
- Response time < 200 ms

**`/config` must return:**
- All fields from `ConfigResponse` schema (design.md §2.2)
- No secrets, no passwords

**Acceptance test:**
```bash
curl -s http://localhost:8000/api/v1/health | python -m json.tool
# → { "status": "ok"|"degraded", "version": "...", "demo_mode": true, ... }
curl -s http://localhost:8000/api/v1/config | python -m json.tool
# → { "demo_mode": true, "app_env": "development", ... }
```

**Done when:** Both endpoints return HTTP 200 with valid JSON matching their Pydantic schemas.

---

## Group C — Services

### TASK-09 · `PlateValidator` + `IndianPlateParser` `[BE]`

**Req IDs:** REQ-PV-01, REQ-PV-02, REQ-PV-03, REQ-PV-04, REQ-PV-05, REQ-PV-06, REQ-PV-07

Implement `backend/app/services/plate_validator.py`. Port directly from notebook logic; do not rewrite the algorithm.

**`PlateValidator` requirements:**
- `deque(maxlen=window_size)` internal window
- `add_frame(plate, confidence)`: skip if `confidence < min_conf`; normalise plate to uppercase
- `validate()`: return plate with `count > window_size / 2`, else `None`
- `state()`: return `ValidatorState` Pydantic model with window contents, validated_plate, vote_count, window_size, is_valid
- `reset()`: clear the deque

**`IndianPlateParser` requirements:**
- Regex: `^([A-Z]{2})(\d{1,2})([A-Z]{1,3})(\d{1,4})$`
- Strip whitespace, convert to uppercase before matching
- Return `ParseResult` with valid/state_code/rto_code/series/number/raw

**Acceptance test:**
```bash
cd backend
python -c "
from app.services.plate_validator import PlateValidator, IndianPlateParser
v = PlateValidator(window_size=3, min_conf=0.7)
v.add_frame('TN01AB1234', 0.9)
v.add_frame('TN01AB1234', 0.8)
v.add_frame('TN01AB1234', 0.85)
assert v.validate() == 'TN01AB1234'
r = IndianPlateParser.parse('TN01AB1234')
assert r.valid and r.state_code == 'TN'
print('PlateValidator: OK')
"
```

**Done when:** Acceptance test passes without assertion errors.

---

### TASK-10 · `PlateClassifier` `[BE]`

**Req IDs:** REQ-PC-01, REQ-PC-02, REQ-PC-03, REQ-PC-04

Implement `backend/app/services/plate_classifier.py`.

**Requirements:**
- Seeded sets at class definition: `_authorized = {"TN01AB1234", "TN02CD5678"}`, `_watchlist = {"TN03EF9012"}`
- `classify()`: check watchlist first (higher priority), then authorized, else `unauthorized_unrecognized`
- `ClassificationResult` includes `provenance: DEMO` for seeded data, `MEASURED` when sourced from real outputs
- `add_authorized()` / `add_watchlist()` update the respective sets at runtime

**Acceptance test:**
```bash
cd backend
python -c "
from app.services.plate_classifier import PlateClassifier
pc = PlateClassifier()
assert pc.classify('TN01AB1234').status == 'authorized'
assert pc.classify('TN03EF9012').status == 'watchlist'
assert pc.classify('XX99ZZ9999').status == 'unauthorized_unrecognized'
pc.add_authorized('MH12AB3456')
assert pc.classify('MH12AB3456').status == 'authorized'
print('PlateClassifier: OK')
"
```

**Done when:** Acceptance test passes.

---

### TASK-11 · `MonteCarloSimulator` `[BE]`

**Req IDs:** REQ-MC-01, REQ-MC-02, REQ-MC-03, REQ-MC-04

Implement `backend/app/services/monte_carlo.py`. Port from notebook; preserve the seeded NumPy random logic exactly.

**Requirements:**
- Constructor: `seed: int`, `model_version: str`
- `run(n_frames, n_trials, per_frame_error_rate)` → `SimulationResult`
- Single-frame: `error = bernoulli(per_frame_error_rate)` over `n_trials`
- Multi-frame: majority-vote over `n_frames` bernoulli draws per trial
- `improvement_factor = single_frame_error_rate / multi_frame_error_rate` (guard divide-by-zero)
- `provenance` always `"SIMULATED"`
- Record `seed`, `model_version`, `timestamp` in result

**Acceptance test:**
```bash
cd backend
python -c "
from app.services.monte_carlo import MonteCarloSimulator
sim = MonteCarloSimulator(seed=42, model_version='0.1.0')
r1 = sim.run(n_frames=7, n_trials=10000, per_frame_error_rate=0.2)
r2 = sim.run(n_frames=7, n_trials=10000, per_frame_error_rate=0.2)
assert r1.single_frame_error_rate == r2.single_frame_error_rate, 'Not reproducible'
assert r1.multi_frame_error_rate < r1.single_frame_error_rate, 'Multi-frame not better'
assert r1.provenance == 'SIMULATED'
print(f'Improvement: {r1.improvement_factor:.2f}x')
"
```

**Done when:** Acceptance test passes including reproducibility and improvement assertions.

---

### TASK-12 · `DemoDataProvider` `[BE]`

**Req IDs:** REQ-DD-01, REQ-DD-02, REQ-DD-03, REQ-DD-04

Implement `backend/app/services/demo_data.py`.

**Requirements:**
- All methods return data with `provenance = "DEMO"`
- Constructor takes `seed: int = 42`; use `numpy.random.default_rng(seed)` for all random values
- Implement at minimum:
  - `health()` → dict matching `HealthResponse`
  - `plate_validation_history(n=20)` → list of frame-result dicts
  - `ocr_results(n=10)` → list of OCR result dicts
  - `alert_log(n=5)` → list of alert dicts (simulated, never real SMS)
  - `detection_summary()` → dict with counts and rates
  - `watchlist_summary()` → dict with plate statuses
- Same seed produces identical output across calls (no `time.time()` or `uuid4()` in data values)

**Acceptance test:**
```bash
cd backend
python -c "
from app.services.demo_data import DemoDataProvider
d1 = DemoDataProvider(seed=42)
d2 = DemoDataProvider(seed=42)
assert d1.alert_log() == d2.alert_log(), 'Not deterministic'
assert all(a['provenance'] == 'DEMO' for a in d1.alert_log())
print('DemoDataProvider: OK')
"
```

**Done when:** Acceptance test passes.

---

## Group D — Backend Tests

### TASK-13 · pytest tests for `PlateValidator` + `IndianPlateParser` `[BE]`

**Req IDs:** REQ-TS-01, REQ-TS-02

Write `backend/tests/test_plate_validator.py`.

**Test cases required:**

| Test | What it checks |
|------|---------------|
| `test_window_size_enforced` | Adding `window_size + 2` frames keeps deque at `window_size` |
| `test_confidence_filter` | Frames below `min_conf` are not added to deque |
| `test_majority_vote_passes` | Majority plate wins when `count > window/2` |
| `test_majority_vote_fails` | Returns `None` when no plate has majority |
| `test_empty_window` | `validate()` on empty deque returns `None` |
| `test_single_entry` | Single frame only wins if `1 > window_size/2` (i.e. `window_size=1`) |
| `test_all_below_threshold` | All frames below `min_conf` → empty deque → `None` |
| `test_valid_plate_full` | `IndianPlateParser` parses `TN01AB1234` correctly |
| `test_valid_plate_min_length` | Parses `MH1A1` (RTO=1 digit, series=1 letter, number=1 digit) — note: adjust if invalid per regex |
| `test_invalid_lowercase` | Lower-case input normalised and parsed correctly |
| `test_invalid_wrong_format` | `ABCDE` returns `valid=False` |
| `test_invalid_state_numeric` | `12AB1234` returns `valid=False` |

**Acceptance test:**
```bash
cd backend && python -m pytest tests/test_plate_validator.py -v
# All tests PASSED
```

**Done when:** All tests in this file pass with no warnings.

---

### TASK-14 · pytest tests for `PlateClassifier` `[BE]`

**Req IDs:** REQ-TS-03

Write `backend/tests/test_plate_classifier.py`.

| Test | What it checks |
|------|---------------|
| `test_authorized_plate_1` | `TN01AB1234` → `authorized` |
| `test_authorized_plate_2` | `TN02CD5678` → `authorized` |
| `test_watchlist_plate` | `TN03EF9012` → `watchlist` |
| `test_unknown_plate` | `XX99ZZ9999` → `unauthorized_unrecognized` |
| `test_runtime_add_authorized` | Added plate classifies as `authorized` |
| `test_runtime_add_watchlist` | Added plate classifies as `watchlist` |
| `test_watchlist_priority` | Plate in both sets classifies as `watchlist` |
| `test_provenance_seeded` | Seeded results carry `provenance = "DEMO"` |

**Acceptance test:**
```bash
cd backend && python -m pytest tests/test_plate_classifier.py -v
```

**Done when:** All tests pass.

---

### TASK-15 · pytest tests for `MonteCarloSimulator` `[BE]`

**Req IDs:** REQ-TS-04

Write `backend/tests/test_monte_carlo.py`.

| Test | What it checks |
|------|---------------|
| `test_reproducibility` | Two runs with same seed produce identical `single_frame_error_rate` |
| `test_different_seeds` | Different seeds produce different results |
| `test_multi_frame_better` | `multi_frame_error_rate < single_frame_error_rate` for `error_rate=0.2, n_frames=7` |
| `test_provenance_simulated` | `result.provenance == "SIMULATED"` |
| `test_seed_in_result` | `result.seed` matches constructor seed |
| `test_improvement_factor` | `improvement_factor > 1.0` for reasonable inputs |
| `test_divide_by_zero_guard` | `per_frame_error_rate=0.0` does not raise |

**Acceptance test:**
```bash
cd backend && python -m pytest tests/test_monte_carlo.py -v
```

**Done when:** All tests pass.

---

## Group E — Frontend Shell

### TASK-16 · React Router setup + page stubs `[FE]`

**Req IDs:** REQ-FE-03, REQ-CS-01, REQ-CS-02

**Steps:**
1. Create `src/router.tsx` using `createBrowserRouter` with all 8 routes (design.md §7)
2. Create stub page files in `src/pages/`: `Overview.tsx`, `AnprLab.tsx`, `ValidationSimulator.tsx`, `Detection.tsx`, `DatasetExplorer.tsx`, `Watchlist.tsx`, `Alerts.tsx`, `Evaluation.tsx`
3. Create `src/pages/ComingSoon.tsx` accepting `{ title, phase, description }` props
4. Wire each page stub to render `<ComingSoon ... />` with correct phase number
5. Update `src/App.tsx` to use `<RouterProvider router={router} />`

**Acceptance test:**
```bash
cd frontend && npm run build   # no TS errors
# Browser: navigate to /anpr → shows ComingSoon with "Phase 2"
# Browser: navigate to /evaluation → shows ComingSoon with "Phase 5"
```

**Done when:** Build passes; all 8 routes resolve without 404.

---

### TASK-17 · TanStack Query setup + API client `[FE]`

**Req IDs:** REQ-FE-04

**Steps:**
1. Create `src/lib/queryClient.ts` — export `QueryClient` with `defaultOptions.queries.staleTime = 30_000`
2. Create `src/lib/api.ts` — axios instance with `baseURL` from `import.meta.env.VITE_API_URL` (default `http://localhost:8000`)
3. Create `src/hooks/useHealth.ts` and `src/hooks/useConfig.ts` per design.md §8
4. Wrap `<App>` in `<QueryClientProvider client={queryClient}>` in `src/main.tsx`

**Acceptance test:**
```bash
# With backend running:
cd frontend && npm run dev
# useHealth() resolves without error in browser network tab
```

**Done when:** `useHealth` hook exists and TypeScript compiles without error.

---

### TASK-18 · `ProvenanceBadge` shared component `[FE]`

**Req IDs:** REQ-SC-01, REQ-SC-02

Implement `src/components/shared/ProvenanceBadge.tsx`.

**Requirements:**
- Accepts `provenance: "MEASURED" | "SIMULATED" | "PLACEHOLDER" | "DEMO"`, `size?: "sm" | "md"`, `className?`
- MEASURED: solid cyan border + text
- SIMULATED: amber background + italic text
- PLACEHOLDER: orange border dashed + text
- DEMO: purple background + text
- Accessible: `role="status"` or `aria-label` describing the provenance

**Acceptance test (Vitest — TASK-22):** See TASK-22.

**Done when:** Component renders without error for all 4 provenance values; visual inspection matches design tokens.

---

### TASK-19 · `PlaceholderBanner`, `EmptyState`, `StatusBadge` `[FE]`

**Req IDs:** REQ-SC-03, REQ-SC-04, REQ-SC-06, REQ-SC-09

Implement three shared components:

**`PlaceholderBanner`** (`src/components/shared/PlaceholderBanner.tsx`):
- Create `PlaceholderContext` with `{ hasPlaceholder: boolean; setHasPlaceholder: ... }`
- `PlaceholderBannerProvider` wraps the app; `ProvenanceBadge` calls `setHasPlaceholder(true)` when `provenance="PLACEHOLDER"` mounts, `false` on unmount
- Banner renders at top of main content when `hasPlaceholder=true`
- Non-dismissible; text: "⚠ This page contains PLACEHOLDER data. Values shown are not measured results."

**`EmptyState`** (`src/components/shared/EmptyState.tsx`):
- Accepts `icon?`, `title`, `description`, `action?: { label, onClick }`
- Renders centred in its container with muted styling

**`StatusBadge`** (`src/components/shared/StatusBadge.tsx`):
- authorized → green `#22C55E` dot + label
- unknown → amber `#F59E0B` dot + label
- watchlist → red `#EF4444` dot + label + visually distinct (e.g. pulsing dot)

**Done when:** All three components render without errors; `PlaceholderBanner` appears when a PLACEHOLDER badge is mounted.

---

### TASK-20 · `KpiCard` and `ChartCard` `[FE]`

**Req IDs:** REQ-SC-05, REQ-SC-07, REQ-SC-08

**`KpiCard`** (`src/components/shared/KpiCard.tsx`):
- Props: `title`, `value`, `unit?`, `delta?`, `provenance`, `loading?`, `icon?`, `className?`
- When `loading=true`: render `<Skeleton>` matching card shape (title, value, badge)
- Delta: positive → green up-arrow, negative → red down-arrow, zero/undefined → neutral
- Always includes `<ProvenanceBadge provenance={provenance} size="sm" />`

**`ChartCard`** (`src/components/shared/ChartCard.tsx`):
- Props: `title`, `provenance`, `description?`, `exportFileName?`, `className?`, `children`
- PNG export: use `html2canvas` or `ref` + `canvas.toBlob()` to capture the chart area
- Export filename: `${slugify(title)}-${Date.now()}.png`
- `<ProvenanceBadge>` displayed below title

**Done when:** `KpiCard` renders skeleton when `loading=true` and shows value when loaded; `ChartCard` export button triggers a PNG download.

---

### TASK-21 · App shell: `ShellLayout`, `Sidebar`, `TopBar` `[FE]`

**Req IDs:** REQ-FE-05, REQ-FE-06, REQ-FE-07, REQ-FE-08, REQ-FE-09, REQ-FE-11

**`ShellLayout`** (`src/components/layout/ShellLayout.tsx`):
- Flex layout: fixed sidebar (left) + main column (right)
- Main column: `TopBar` + `PlaceholderBanner` + `<ErrorBoundary>` + `<Outlet>`

**`Sidebar`** (`src/components/layout/Sidebar.tsx`):
- Dark navy background, `border-r border-border`
- Each `NavItem`: lucide icon, label, `NavLink` with active highlight
- Phase badge on unbuilt items: small `"Ph N"` chip in muted colour
- Bottom section: privacy notice link
- Keyboard accessible: Tab order, focus ring on each item

**`TopBar`** (`src/components/layout/TopBar.tsx`):
- App title left; status badge + demo indicator + theme toggle right
- `SystemStatusBadge`: uses `useHealth()`, green/amber/red based on response
- `DemoModeIndicator`: amber pill "DEMO DATA", only rendered when `config.demo_mode = true`
- `ThemeToggle`: toggles `.light` class on `<html>`; persists to `localStorage`
- WHEN `useHealth` returns error/degraded: toast fires via shadcn `useToast()`

**`ErrorBoundary`** (`src/components/ErrorBoundary.tsx`):
- Class component implementing `componentDidCatch`
- Fallback: page title "Something went wrong" + description + "Reload" button (`window.location.reload()`)

**Acceptance test:**
```bash
cd frontend && npm run dev
# Browser: sidebar visible, all 8 items present, TopBar shows status badge
# Toggle theme: background changes navy ↔ light
# Kill backend: status badge turns red, toast appears
```

**Done when:** Shell renders with sidebar + topbar; theme toggle works; error boundary wraps outlet.

---

### TASK-22 · Vitest unit tests `[FE]`

**Req IDs:** REQ-TS-05, REQ-TS-06

Write tests in `frontend/src/__tests__/`.

**`ProvenanceBadge.test.tsx`:**

| Test | Assertion |
|------|-----------|
| `renders MEASURED badge` | Contains text "MEASURED"; has cyan class |
| `renders SIMULATED badge` | Contains text "SIMULATED"; has italic styling |
| `renders PLACEHOLDER badge` | Contains text "PLACEHOLDER"; has dashed border class |
| `renders DEMO badge` | Contains text "DEMO"; has purple class |
| `accessible label present` | `aria-label` or `role="status"` exists |

**`KpiCard.test.tsx`:**

| Test | Assertion |
|------|-----------|
| `renders value` | Given `value="42"`, shows "42" in DOM |
| `renders unit` | Given `unit="fps"`, shows "fps" |
| `renders skeleton on loading` | When `loading=true`, Skeleton present, value absent |
| `renders provenance badge` | `ProvenanceBadge` present in output |
| `positive delta renders green` | delta=5 → green arrow/text class |

**Acceptance test:**
```bash
cd frontend && npx vitest --run
# All tests PASSED
```

**Done when:** All Vitest tests pass with `npx vitest --run`.

---

## Group F — Integration & Smoke Test

### TASK-23 · Demo mode end-to-end wiring `[BOTH]`

**Req IDs:** REQ-BE-07, REQ-DD-01, REQ-DD-02, REQ-FE-06

**Steps:**
1. Update `GET /api/v1/health` to return `DemoDataProvider().health()` when `DEMO_MODE=true`
2. Verify `demo_mode: true` in health response drives `DemoModeIndicator` in TopBar
3. Verify "DEMO DATA" pill is visible in browser when `DEMO_MODE=true`
4. Verify "DEMO DATA" pill is hidden when `DEMO_MODE=false`

**Acceptance test:**
```bash
# With DEMO_MODE=true (default):
curl -s http://localhost:8000/api/v1/health | python -c "import sys,json; d=json.load(sys.stdin); assert d['demo_mode']==True"
# Browser: "DEMO DATA" pill visible in TopBar
# Set DEMO_MODE=false in .env, restart backend:
# Browser: "DEMO DATA" pill gone
```

**Done when:** Demo indicator correctly reflects `DEMO_MODE` env var value.

---

### TASK-24 · Full smoke test `[BOTH]`

**Req IDs:** REQ-DV-01, REQ-DV-02, REQ-BE-11, REQ-BE-13 + design.md §13

Run through all 10 acceptance criteria from design.md §13.

**Steps:**
1. `cp .env.example .env` (ensure `DEMO_MODE=true`)
2. `npm run dev` from project root
3. Execute each check from the smoke test table:

| # | Action | Expected |
|---|--------|---------|
| 1 | Open `http://localhost:5173` | ShellLayout renders |
| 2 | Inspect TopBar | Green "OK" status badge |
| 3 | Inspect Sidebar | All 8 links visible |
| 4 | Click each sidebar link | ComingSoon with correct phase number |
| 5 | Inspect TopBar | "DEMO DATA" pill visible |
| 6 | Click theme toggle | Theme switches; reload retains choice |
| 7 | `curl http://localhost:8000/api/v1/health` | HTTP 200, `status: "ok"` |
| 8 | `curl http://localhost:8000/api/v1/config` | HTTP 200, no secrets |
| 9 | `cd backend && python -m pytest tests/ -v` | All pass |
| 10 | `cd frontend && npx vitest --run` | All pass |

**Done when:** All 10 checks pass. Phase 1 is complete.

---

## Task Summary

| Task | Group | Type | Key Req IDs |
|------|-------|------|-------------|
| TASK-01 | A — Scaffolding | BOTH | REQ-BE-08, REQ-DV-01-02, REQ-RM-01 |
| TASK-02 | A — Scaffolding | BE | REQ-BE-01, REQ-BE-06 |
| TASK-03 | A — Scaffolding | FE | REQ-FE-01, REQ-FE-02 |
| TASK-04 | A — Scaffolding | FE | REQ-FE-01, REQ-SC-05 |
| TASK-05 | B — Backend Core | BE | REQ-BE-06, REQ-BE-07 |
| TASK-06 | B — Backend Core | BE | REQ-BE-05 |
| TASK-07 | B — Backend Core | BE | REQ-BE-01, REQ-BE-02, REQ-BE-09, REQ-BE-10 |
| TASK-08 | B — Backend Core | BE | REQ-BE-11, REQ-BE-12, REQ-BE-13 |
| TASK-09 | C — Services | BE | REQ-PV-01 – PV-07 |
| TASK-10 | C — Services | BE | REQ-PC-01 – PC-04 |
| TASK-11 | C — Services | BE | REQ-MC-01 – MC-04 |
| TASK-12 | C — Services | BE | REQ-DD-01 – DD-04 |
| TASK-13 | D — BE Tests | BE | REQ-TS-01, REQ-TS-02 |
| TASK-14 | D — BE Tests | BE | REQ-TS-03 |
| TASK-15 | D — BE Tests | BE | REQ-TS-04 |
| TASK-16 | E — FE Shell | FE | REQ-FE-03, REQ-CS-01, REQ-CS-02 |
| TASK-17 | E — FE Shell | FE | REQ-FE-04 |
| TASK-18 | E — FE Shell | FE | REQ-SC-01, REQ-SC-02 |
| TASK-19 | E — FE Shell | FE | REQ-SC-03 – SC-04, SC-06, SC-09 |
| TASK-20 | E — FE Shell | FE | REQ-SC-05, REQ-SC-07, REQ-SC-08 |
| TASK-21 | E — FE Shell | FE | REQ-FE-05 – FE-09, FE-11 |
| TASK-22 | E — FE Shell | FE | REQ-TS-05, REQ-TS-06 |
| TASK-23 | F — Integration | BOTH | REQ-BE-07, REQ-DD-02, REQ-FE-06 |
| TASK-24 | F — Integration | BOTH | Full smoke test (design.md §13) |
