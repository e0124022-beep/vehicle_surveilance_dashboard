# Requirements — Deep Learning-Based Intelligent Vehicle Surveillance System (Phase 1)

**Format:** EARS (Easy Approach to Requirements Syntax)  
**Notation:**
- `WHEN <trigger> THE SYSTEM SHALL <response>` — event-driven
- `WHILE <state> THE SYSTEM SHALL <response>` — state-driven
- `THE SYSTEM SHALL <response>` — ubiquitous (always)
- `WHERE <feature> THE SYSTEM SHALL <response>` — optional feature
- `IF <precondition> THEN THE SYSTEM SHALL <response>` — conditional

**Phase:** 1 — Foundation  
**Version:** 1.0  
**Date:** 2026-10-25

---

## 1. Backend Scaffolding

### 1.1 Application Factory & Lifespan

**REQ-BE-01**  
THE SYSTEM SHALL implement a FastAPI application using the app-factory pattern, where the application instance is created by a `create_app()` function in `backend/app/main.py`.

**REQ-BE-02**  
WHEN the application starts, THE SYSTEM SHALL execute a lifespan startup sequence that: loads all ML models into memory exactly once, initialises structured logging, validates all required configuration values, and logs the application config, random seed, model version, and ISO 8601 timestamp.

**REQ-BE-03**  
WHEN the application shuts down, THE SYSTEM SHALL release ML model resources and flush any pending log buffers.

**REQ-BE-04**  
IF a required configuration value is missing or invalid at startup, THEN THE SYSTEM SHALL log a descriptive error and exit with a non-zero status code before accepting any requests.

**REQ-BE-05**  
THE SYSTEM SHALL emit all log output in structured JSON format, with fields: `timestamp`, `level`, `logger`, `message`, and an optional `context` object.

### 1.2 Configuration

**REQ-BE-06**  
THE SYSTEM SHALL load all configuration from environment variables, falling back to a `.env` file, using a Pydantic `BaseSettings` class defined in `backend/app/core/config.py`. No configuration values shall be hardcoded in application code.

**REQ-BE-07**  
THE SYSTEM SHALL expose a `DEMO_MODE` boolean configuration flag. WHEN `DEMO_MODE` is `true`, THE SYSTEM SHALL serve seeded synthetic data from `backend/app/services/demo_data.py` in place of real dataset reads.

**REQ-BE-08**  
THE SYSTEM SHALL provide `.env.example` at the project root listing every supported environment variable with a description and default value.

### 1.3 CORS & Middleware

**REQ-BE-09**  
THE SYSTEM SHALL configure CORS to allow requests from the configured frontend origin (default `http://localhost:5173`). In production mode, wildcard origins must not be permitted.

**REQ-BE-10**  
THE SYSTEM SHALL add a request-ID middleware that attaches a unique UUID to every incoming request and includes it in the response headers as `X-Request-ID`.

### 1.4 Health Endpoint

**REQ-BE-11**  
WHEN a client sends `GET /api/v1/health`, THE SYSTEM SHALL respond within 200 ms with HTTP 200 and a JSON body containing: `status` ("ok" or "degraded"), `version` (application version string), `demo_mode` (boolean), `uptime_seconds` (float), `models_loaded` (object mapping model name to boolean), and `timestamp` (ISO 8601).

**REQ-BE-12**  
IF any ML model failed to load at startup, THEN the health endpoint SHALL return `status: "degraded"` and include an `errors` array describing each failed model.

**REQ-BE-13**  
WHEN a client sends `GET /api/v1/config`, THE SYSTEM SHALL respond with HTTP 200 and a JSON body containing all non-sensitive configuration values (dataset paths, model paths, demo mode, validator settings). Secrets and credentials must not appear in the response.

---

## 2. PlateValidator Service

### 2.1 Sliding-Window Majority Vote

**REQ-PV-01**  
THE SYSTEM SHALL implement a `PlateValidator` class in `backend/app/services/plate_validator.py` that maintains a sliding deque window of configurable size (default 7 frames) of per-frame OCR results.

**REQ-PV-02**  
WHEN a new OCR result (plate string + confidence score) is added to the `PlateValidator`, THE SYSTEM SHALL add it to the deque and drop the oldest entry if the deque exceeds the configured window size.

**REQ-PV-03**  
WHEN `validate()` is called on the `PlateValidator`, THE SYSTEM SHALL return the plate string that appears in strictly more than half the current window (`count > window_size / 2`), along with its occurrence count and the window size. IF no plate meets the threshold, THE SYSTEM SHALL return `None`.

**REQ-PV-04**  
THE SYSTEM SHALL filter out any OCR result whose confidence score is below the configured `min_conf` threshold (default 0.70) before adding it to the deque.

**REQ-PV-05**  
THE SYSTEM SHALL expose the current window contents, validated plate, and validation status via a `PlateValidator.state()` method returning a Pydantic model.

### 2.2 Indian Plate Regex

**REQ-PV-06**  
THE SYSTEM SHALL implement an `IndianPlateParser` that validates and parses a plate string against the regex `^([A-Z]{2})(\d{1,2})([A-Z]{1,3})(\d{1,4})$`.

**REQ-PV-07**  
WHEN `IndianPlateParser.parse(plate_string)` is called, THE SYSTEM SHALL return a structured result containing: `valid` (boolean), `state_code` (2-letter), `rto_code` (1–2 digit), `series` (1–3 letters), `number` (1–4 digits), and `raw` (original string). IF the string does not match, THE SYSTEM SHALL return `valid: false` with all other fields as `None`.

---

## 3. PlateClassifier Service

**REQ-PC-01**  
THE SYSTEM SHALL implement a `PlateClassifier` class in `backend/app/services/plate_classifier.py` that classifies a validated plate string as one of: `authorized`, `watchlist`, or `unauthorized_unrecognized`.

**REQ-PC-02**  
THE SYSTEM SHALL seed the `PlateClassifier` with the following initial data:
- Authorised: `TN01AB1234`, `TN02CD5678`
- Watchlist: `TN03EF9012`

**REQ-PC-03**  
WHEN `PlateClassifier.classify(plate_string)` is called, THE SYSTEM SHALL return a `ClassificationResult` Pydantic model containing: `plate`, `status` (authorized / watchlist / unauthorized_unrecognized), and `provenance` (DEMO for seeded data, MEASURED for data from real outputs).

**REQ-PC-04**  
THE SYSTEM SHALL support runtime addition of plates to both the authorized list and the watchlist via `PlateClassifier.add_authorized()` and `PlateClassifier.add_watchlist()` methods.

---

## 4. Monte Carlo Simulation Service

**REQ-MC-01**  
THE SYSTEM SHALL implement a `MonteCarloSimulator` class in `backend/app/services/monte_carlo.py` that computes the false-decision rate for single-frame OCR versus N-frame majority-vote validation.

**REQ-MC-02**  
THE SYSTEM SHALL accept a configurable random seed (default from config) so that simulation results are fully reproducible across runs.

**REQ-MC-03**  
WHEN `MonteCarloSimulator.run(n_frames, n_trials, per_frame_error_rate)` is called, THE SYSTEM SHALL return a `SimulationResult` model containing: `single_frame_error_rate`, `multi_frame_error_rate`, `improvement_factor`, `n_trials`, `n_frames`, `seed`, and `provenance: "SIMULATED"`.

**REQ-MC-04**  
THE SYSTEM SHALL record the random seed, model version, and timestamp in every `SimulationResult` so results are traceable.

---

## 5. Demo Data Module

**REQ-DD-01**  
THE SYSTEM SHALL implement a `DemoDataProvider` in `backend/app/services/demo_data.py` that generates realistic synthetic data for all dashboard pages defined in the 5-phase roadmap.

**REQ-DD-02**  
WHEN `DEMO_MODE` is `true`, THE SYSTEM SHALL return data from `DemoDataProvider` instead of reading from the filesystem outputs.

**REQ-DD-03**  
ALL values returned by `DemoDataProvider` SHALL carry `provenance: "DEMO"` in their Pydantic models.

**REQ-DD-04**  
THE SYSTEM SHALL generate demo data deterministically from a fixed seed so that the UI shows consistent values across page refreshes in demo mode.

---

## 6. Frontend Scaffolding

### 6.1 Project Setup

**REQ-FE-01**  
THE SYSTEM SHALL provide a Vite + React 18 + TypeScript frontend project in the `frontend/` directory with `strict: true` in `tsconfig.json`.

**REQ-FE-02**  
THE SYSTEM SHALL configure Tailwind CSS with the custom design tokens defined in the tech stack (navy, surface, accent, authorized, unknown, watchlist colours; Inter font; 8 px grid).

**REQ-FE-03**  
THE SYSTEM SHALL configure React Router v6 using `createBrowserRouter` with routes for all 8 final pages.

**REQ-FE-04**  
THE SYSTEM SHALL configure TanStack Query v5 with a `QueryClient` at the React tree root, with a default stale time of 30 seconds.

### 6.2 App Shell

**REQ-FE-05**  
THE SYSTEM SHALL render a persistent sidebar listing all 8 navigation destinations. Each entry SHALL show an icon (lucide-react), a label, and a phase badge for unbuilt pages.

**REQ-FE-06**  
THE SYSTEM SHALL render a persistent top bar containing: the application title, a real-time system-status badge (polling `GET /api/v1/health` every 30 seconds), a demo-mode indicator ("DEMO DATA") when `DEMO_MODE` is active, and a light/dark theme toggle.

**REQ-FE-07**  
WHILE the backend health check returns `status: "degraded"` or a network error occurs, THE SYSTEM SHALL display the system-status badge in a visually distinct error state (red) and show a toast notification.

**REQ-FE-08**  
THE SYSTEM SHALL implement a React error boundary wrapping the main content area. WHEN an unhandled React render error occurs, THE SYSTEM SHALL display a styled error fallback page with a "Reload" button rather than a blank screen.

### 6.3 Theme & Accessibility

**REQ-FE-09**  
THE SYSTEM SHALL implement a light/dark theme toggle that persists the user's preference to `localStorage` and applies it on subsequent page loads without a flash of incorrect theme.

**REQ-FE-10**  
THE SYSTEM SHALL achieve WCAG AA contrast ratios for all text/background colour combinations in both light and dark themes.

**REQ-FE-11**  
THE SYSTEM SHALL ensure all interactive elements (buttons, links, inputs, sidebar items) have visible keyboard focus indicators and are reachable via Tab key in logical order.

---

## 7. Shared Components

### 7.1 ProvenanceBadge

**REQ-SC-01**  
THE SYSTEM SHALL provide a `ProvenanceBadge` React component that accepts a `provenance` prop of type `"MEASURED" | "SIMULATED" | "PLACEHOLDER" | "DEMO"` and renders a visually distinct badge for each value per the design standards.

**REQ-SC-02**  
WHEN `provenance` is `"PLACEHOLDER"`, THE SYSTEM SHALL render the badge with a dashed border and colour distinct from `MEASURED` and `SIMULATED`.

### 7.2 PlaceholderBanner

**REQ-SC-03**  
THE SYSTEM SHALL provide a `PlaceholderBanner` React component that renders a persistent, non-dismissible warning banner at the top of the main content area.

**REQ-SC-04**  
WHILE any `ProvenanceBadge` with `provenance="PLACEHOLDER"` is mounted anywhere in the current page's component tree, THE SYSTEM SHALL display the `PlaceholderBanner`.

### 7.3 KpiCard

**REQ-SC-05**  
THE SYSTEM SHALL provide a `KpiCard` React component that accepts: `title`, `value`, `unit` (optional), `delta` (optional numeric change), `provenance`, `loading` (boolean), and `icon` (optional). WHEN `loading` is true, THE SYSTEM SHALL render a skeleton loader.

### 7.4 StatusBadge

**REQ-SC-06**  
THE SYSTEM SHALL provide a `StatusBadge` React component that accepts a `status` prop of type `"authorized" | "unknown" | "watchlist"` and renders the correct colour (green / amber / red) with an accessible label.

### 7.5 ChartCard

**REQ-SC-07**  
THE SYSTEM SHALL provide a `ChartCard` React component that wraps a Recharts chart with: a title, a `ProvenanceBadge`, an optional description, and a PNG-export button.

**REQ-SC-08**  
WHEN the user activates the PNG-export button in a `ChartCard`, THE SYSTEM SHALL download the chart as a PNG file with a filename derived from the chart title and current timestamp.

### 7.6 EmptyState

**REQ-SC-09**  
THE SYSTEM SHALL provide an `EmptyState` React component that accepts: `icon`, `title`, `description`, and optional `action` (button label + callback). It SHALL be used for both "no data" and "coming in Phase N" states.

---

## 8. Coming-Soon Pages

**REQ-CS-01**  
THE SYSTEM SHALL render a polished `ComingSoon` page for every route whose feature is not yet implemented, showing: the page title, the phase number in which it will be built, a brief description of planned functionality, and an `EmptyState` component. The page must not show a blank screen or a 404 error.

**REQ-CS-02**  
THE SYSTEM SHALL list the following pages as coming soon with their respective phase numbers:

| Page | Phase |
|------|-------|
| Overview | 4 |
| ANPR Lab | 2 |
| Validation Simulator | 2 |
| Detection & Tracking | 3 |
| Dataset Explorer | 3 |
| Watchlist | 4 |
| Alerts | 4 |
| Evaluation | 5 |

---

## 9. Dev Runner & Tooling

**REQ-DV-01**  
THE SYSTEM SHALL provide a single command (`npm run dev` from the project root, or `make dev`) that concurrently starts both the backend Uvicorn server on port 8000 and the Vite dev server on port 5173.

**REQ-DV-02**  
THE SYSTEM SHALL provide a root `package.json` using `concurrently` to run both servers, and a `Makefile` with at minimum `make dev` and `make test` targets.

**REQ-DV-03**  
THE SYSTEM SHALL provide a `Makefile` target `make test` that runs `pytest` for the backend and `vitest --run` for the frontend, reporting results to stdout.

---

## 10. Testing

**REQ-TS-01**  
THE SYSTEM SHALL provide pytest unit tests for `PlateValidator` covering: window-size enforcement, confidence filtering, majority-vote with sufficient votes, majority-vote with insufficient votes, and edge cases (empty window, single entry, all entries below confidence threshold).

**REQ-TS-02**  
THE SYSTEM SHALL provide pytest unit tests for `IndianPlateParser` covering: valid plates of minimum and maximum length, plates with invalid state codes, plates with wrong character counts, and plates with lower-case characters.

**REQ-TS-03**  
THE SYSTEM SHALL provide pytest unit tests for `PlateClassifier` covering: classification of each seeded authorized plate, classification of the seeded watchlist plate, classification of an unknown plate, and runtime addition of a new plate.

**REQ-TS-04**  
THE SYSTEM SHALL provide pytest unit tests for `MonteCarloSimulator` covering: reproducibility (same seed yields identical results), that multi-frame error rate is lower than single-frame error rate, and that `provenance` is `"SIMULATED"`.

**REQ-TS-05**  
THE SYSTEM SHALL provide Vitest unit tests for `ProvenanceBadge` covering: correct badge text and CSS class for each provenance value.

**REQ-TS-06**  
THE SYSTEM SHALL provide Vitest unit tests for `KpiCard` covering: correct value rendering, skeleton loader when `loading=true`, and provenance badge presence.

---

## 11. README

**REQ-RM-01**  
THE SYSTEM SHALL provide a `README.md` at the project root with the following sections: Project Overview, System Architecture (summary), Prerequisites, Installation, Configuration (`.env` setup), Running the Application, Running Tests, Project Structure, Provenance Tag Guide, Privacy & Ethics Notice, and Phase Roadmap.

**REQ-RM-02**  
THE SYSTEM SHALL document in the README the exact commands needed to: create a Python virtual environment, install backend dependencies, install frontend dependencies, copy `.env.example` to `.env`, and start both servers.

---

## Appendix A — Requirement ID Registry

| ID | Area | Description |
|----|------|-------------|
| REQ-BE-01 – REQ-BE-13 | Backend | Scaffolding, config, CORS, health, config endpoints |
| REQ-PV-01 – REQ-PV-07 | PlateValidator | Sliding window, majority vote, regex parser |
| REQ-PC-01 – REQ-PC-04 | PlateClassifier | Classification, seeded data, runtime updates |
| REQ-MC-01 – REQ-MC-04 | Monte Carlo | Simulation, reproducibility, provenance |
| REQ-DD-01 – REQ-DD-04 | Demo Data | Synthetic data, DEMO provenance, determinism |
| REQ-FE-01 – REQ-FE-11 | Frontend | Scaffolding, shell, theme, accessibility |
| REQ-SC-01 – REQ-SC-09 | Shared Components | ProvenanceBadge, PlaceholderBanner, KpiCard, StatusBadge, ChartCard, EmptyState |
| REQ-CS-01 – REQ-CS-02 | Coming Soon | Phase-N placeholder pages |
| REQ-DV-01 – REQ-DV-03 | Dev Runner | Concurrent start, Makefile |
| REQ-TS-01 – REQ-TS-06 | Tests | pytest + Vitest coverage |
| REQ-RM-01 – REQ-RM-02 | README | Setup and run documentation |
