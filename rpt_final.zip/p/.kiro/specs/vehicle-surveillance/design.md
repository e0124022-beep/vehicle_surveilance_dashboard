# Design — Deep Learning-Based Intelligent Vehicle Surveillance System (Phase 1)

**Phase:** 1 — Foundation  
**Version:** 1.0  
**Date:** 2026-10-25  
**Requirements:** See `requirements.md`

---

## 1. System Architecture

### 1.1 Mermaid Architecture Diagram

```mermaid
graph TB
    subgraph Browser["Browser — React 18 + Vite (Port 5173)"]
        Router["React Router v6\ncreateBrowserRouter"]
        TQ["TanStack Query v5\nQueryClient"]
        Shell["ShellLayout\n(Sidebar + TopBar)"]
        Pages["Page Components\n8 routes"]
        Shared["Shared Components\nProvenanceBadge · KpiCard\nChartCard · StatusBadge\nEmptyState · PlaceholderBanner"]
        EB["Error Boundary"]
    end

    subgraph Backend["Backend — FastAPI + Uvicorn (Port 8000)"]
        Factory["create_app()\nApp Factory"]
        Lifespan["Lifespan\nstartup / shutdown"]
        CORS["CORS Middleware"]
        ReqID["Request-ID Middleware"]
        APIv1["Router /api/v1"]
        Health["GET /health"]
        Config["GET /config"]

        subgraph Services["Services Layer"]
            PV["PlateValidator\ndeque window + majority vote"]
            PP["IndianPlateParser\nregex validation"]
            PC["PlateClassifier\nauthor · watch · unrec"]
            MC["MonteCarloSimulator\nseeded false-decision rate"]
            DD["DemoDataProvider\nseeded synthetic data"]
        end

        subgraph Core["Core Layer"]
            Cfg["config.py\nPydantic BaseSettings"]
            Log["logging.py\nJSON structured"]
        end
    end

    subgraph DataLayer["Data Layer (read-only)"]
        DS["datasets/\nua_detrac · indian_plates"]
        OP["outputs/\nalerts.csv · ocr_validation\nphoto_anpr · evidence/"]
    end

    Router --> Shell
    Shell --> Pages
    Pages --> Shared
    Pages --> EB
    TQ -->|HTTP/JSON| APIv1

    Factory --> Lifespan
    Factory --> CORS
    Factory --> ReqID
    Factory --> APIv1
    APIv1 --> Health
    APIv1 --> Config
    Lifespan --> Services
    Lifespan --> Core
    Services --> DataLayer
    Cfg -->|env/.env| Lifespan
```

### 1.2 High-Level Layers

```
Browser (5173)
  └─ ShellLayout
      ├─ Sidebar + TopBar (persistent chrome)
      ├─ PlaceholderBanner (context-driven)
      ├─ ErrorBoundary
      └─ <Outlet> (page content)
           └─ ComingSoon × 8  [Phase 1]

FastAPI (8000)
  └─ App Factory + Lifespan
      ├─ CORS + Request-ID middleware
      ├─ /api/v1/health
      ├─ /api/v1/config
      └─ Services (PlateValidator, PlateClassifier, MonteCarlo, DemoData)
           └─ Core (config.py, logging.py)
                └─ Data Layer (read-only datasets + outputs)
```

---

## 2. API Endpoint Table (Phase 1)

| Method | Path | Auth | Description | Response Model | Req IDs |
|--------|------|------|-------------|----------------|---------|
| GET | `/api/v1/health` | None | System health; models loaded, uptime, demo mode | `HealthResponse` | REQ-BE-11, REQ-BE-12 |
| GET | `/api/v1/config` | None | Non-sensitive runtime config | `ConfigResponse` | REQ-BE-13 |

### 2.1 `HealthResponse` Schema

```python
class ModelStatus(BaseModel):
    yolo: bool
    easyocr: bool

class HealthResponse(BaseModel):
    status: Literal["ok", "degraded"]
    version: str
    demo_mode: bool
    uptime_seconds: float
    models_loaded: ModelStatus
    errors: list[str] = []
    timestamp: datetime
```

### 2.2 `ConfigResponse` Schema

```python
class ConfigResponse(BaseModel):
    demo_mode: bool
    app_env: str
    backend_port: int
    frontend_port: int
    yolo_model_path: str
    yolo_confidence: float
    device: str
    validator_window: int
    validator_min_conf: float
    datasets_root: str   # resolved path, no secrets
    outputs_root: str
    max_upload_size_mb: int
```

### 2.3 Common Pydantic Bases

```python
class ProvenanceEnum(str, Enum):
    MEASURED    = "MEASURED"
    SIMULATED   = "SIMULATED"
    PLACEHOLDER = "PLACEHOLDER"
    DEMO        = "DEMO"

class ProvenanceMixin(BaseModel):
    provenance: ProvenanceEnum
```

All metric-bearing response models inherit `ProvenanceMixin`.

### 2.4 Error Response Shape

```python
class ErrorResponse(BaseModel):
    error: str          # machine-readable code
    detail: str         # human-readable explanation
    request_id: str
```

---

## 3. Folder Structure

```
vehicle_surveilance_dashboard/
│
├── .kiro/
│   ├── steering/
│   │   ├── product.md
│   │   ├── tech.md
│   │   └── structure.md
│   └── specs/vehicle-surveillance/
│       ├── requirements.md
│       ├── design.md
│       └── tasks.md
│
├── backend/
│   ├── app/
│   │   ├── main.py                    # create_app() + lifespan
│   │   ├── core/
│   │   │   ├── config.py              # Pydantic BaseSettings
│   │   │   └── logging.py             # JSON structured logger
│   │   ├── api/v1/
│   │   │   ├── router.py              # include_router aggregator
│   │   │   ├── health.py              # GET /api/v1/health
│   │   │   └── config_endpoint.py     # GET /api/v1/config
│   │   ├── services/
│   │   │   ├── plate_validator.py     # PlateValidator + IndianPlateParser
│   │   │   ├── plate_classifier.py    # PlateClassifier
│   │   │   ├── monte_carlo.py         # MonteCarloSimulator
│   │   │   └── demo_data.py           # DemoDataProvider
│   │   └── models/
│   │       ├── common.py              # ProvenanceEnum, ProvenanceMixin, ErrorResponse
│   │       └── health.py              # HealthResponse, ConfigResponse
│   ├── tests/
│   │   ├── conftest.py
│   │   ├── test_plate_validator.py
│   │   ├── test_plate_classifier.py
│   │   └── test_monte_carlo.py
│   ├── requirements.txt
│   └── pyproject.toml                 # Ruff + Black config
│
├── frontend/
│   ├── index.html
│   ├── vite.config.ts
│   ├── tsconfig.json
│   ├── tailwind.config.ts
│   ├── postcss.config.cjs
│   ├── .eslintrc.cjs
│   ├── .prettierrc
│   ├── package.json
│   └── src/
│       ├── main.tsx                   # React root + QueryClientProvider
│       ├── App.tsx                    # RouterProvider
│       ├── router.tsx                 # createBrowserRouter definition
│       ├── pages/
│       │   ├── Overview.tsx
│       │   ├── AnprLab.tsx
│       │   ├── ValidationSimulator.tsx
│       │   ├── Detection.tsx
│       │   ├── DatasetExplorer.tsx
│       │   ├── Watchlist.tsx
│       │   ├── Alerts.tsx
│       │   ├── Evaluation.tsx
│       │   └── ComingSoon.tsx
│       ├── components/
│       │   ├── layout/
│       │   │   ├── ShellLayout.tsx
│       │   │   ├── Sidebar.tsx
│       │   │   └── TopBar.tsx
│       │   ├── shared/
│       │   │   ├── ProvenanceBadge.tsx
│       │   │   ├── PlaceholderBanner.tsx
│       │   │   ├── KpiCard.tsx
│       │   │   ├── StatusBadge.tsx
│       │   │   ├── ChartCard.tsx
│       │   │   └── EmptyState.tsx
│       │   └── ui/                    # shadcn/ui generated components
│       ├── hooks/
│       │   ├── useHealth.ts
│       │   └── useConfig.ts
│       ├── lib/
│       │   ├── api.ts                 # base HTTP client
│       │   ├── queryClient.ts
│       │   └── utils.ts               # cn() + helpers
│       └── styles/
│           └── globals.css            # Tailwind directives + CSS vars
│
├── package.json          # root — concurrently dev script
├── Makefile
├── .env.example
└── README.md
```

---

## 4. Component Hierarchy

```
App  (RouterProvider)
└── ShellLayout
    ├── Sidebar
    │   ├── NavItem × 8  (lucide icon + label + PhaseBadge for unbuilt)
    │   └── PrivacyNoticeLink
    ├── TopBar
    │   ├── AppTitle
    │   ├── SystemStatusBadge   ← polls useHealth() every 30 s
    │   ├── DemoModeIndicator   ← visible only when DEMO_MODE=true
    │   └── ThemeToggle
    ├── PlaceholderBanner       ← context-driven; shown while any PLACEHOLDER badge mounted
    ├── ErrorBoundary
    └── <Outlet>  (active page)
        │
        └── ComingSoon  [× 8 in Phase 1]
            └── EmptyState
                ├── Icon (lucide)
                ├── Title
                ├── Description
                └── Action (optional button)
```

### 4.1 Shared Component Prop Contracts

#### `ProvenanceBadge`
```tsx
type Provenance = "MEASURED" | "SIMULATED" | "PLACEHOLDER" | "DEMO";

interface ProvenanceBadgeProps {
  provenance: Provenance;
  size?: "sm" | "md";    // default "sm"
  className?: string;
}
```
Colour mapping: MEASURED → cyan, SIMULATED → amber (italic), PLACEHOLDER → orange (dashed border), DEMO → purple.

#### `PlaceholderBanner`
```tsx
// No props. Reads PlaceholderContext.
// Context { hasPlaceholder: boolean } set by any mounted
// ProvenanceBadge with provenance="PLACEHOLDER".
// Non-dismissible. Renders at top of main content area.
```

#### `KpiCard`
```tsx
interface KpiCardProps {
  title: string;
  value: string | number;
  unit?: string;
  delta?: number;           // positive=green, negative=red, 0/undefined=neutral
  provenance: Provenance;
  loading?: boolean;        // renders Skeleton when true
  icon?: React.ReactNode;
  className?: string;
}
```

#### `StatusBadge`
```tsx
type VehicleStatus = "authorized" | "unknown" | "watchlist";

interface StatusBadgeProps {
  status: VehicleStatus;
  showLabel?: boolean;      // default true
  size?: "sm" | "md";
}
```
Colour mapping: authorized → green `#22C55E`, unknown → amber `#F59E0B`, watchlist → red `#EF4444`.

#### `ChartCard`
```tsx
interface ChartCardProps {
  title: string;
  provenance: Provenance;
  description?: string;
  exportFileName?: string;  // auto: slugify(title) + timestamp
  className?: string;
  children: React.ReactNode;  // Recharts tree
}
```

#### `EmptyState`
```tsx
interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description: string;
  action?: { label: string; onClick: () => void };
}
```

---

## 5. Theme Tokens

### 5.1 CSS Variables (`src/styles/globals.css`)

```css
/* Dark theme — default */
:root {
  --color-navy:            #0B1220;
  --color-surface:         #111A2E;
  --color-surface-2:       #1A2540;
  --color-border:          #1E2D45;
  --color-accent:          #22D3EE;
  --color-accent-dim:      #0E7490;

  --color-authorized:      #22C55E;
  --color-unknown:         #F59E0B;
  --color-watchlist:       #EF4444;

  --color-text:            #E2E8F0;
  --color-muted:           #64748B;
  --color-inverted:        #0B1220;

  --color-prov-measured:   #22D3EE;
  --color-prov-simulated:  #F59E0B;
  --color-prov-placeholder:#F97316;
  --color-prov-demo:       #A855F7;
}

/* Light theme */
.light {
  --color-navy:            #F0F4F8;
  --color-surface:         #FFFFFF;
  --color-surface-2:       #E8EDF2;
  --color-border:          #CBD5E1;
  --color-accent:          #0891B2;
  --color-accent-dim:      #0E7490;
  --color-text:            #0F172A;
  --color-muted:           #64748B;
  --color-inverted:        #FFFFFF;
  /* Status + provenance colours unchanged */
}
```

### 5.2 Tailwind Extension (`tailwind.config.ts`)

```ts
theme: {
  extend: {
    colors: {
      navy:        "var(--color-navy)",
      surface:     "var(--color-surface)",
      "surface-2": "var(--color-surface-2)",
      border:      "var(--color-border)",
      accent:      "var(--color-accent)",
      "accent-dim":"var(--color-accent-dim)",
      authorized:  "var(--color-authorized)",
      unknown:     "var(--color-unknown)",
      watchlist:   "var(--color-watchlist)",
      text:        "var(--color-text)",
      muted:       "var(--color-muted)",
    },
    fontFamily: {
      sans: ["Inter", "ui-sans-serif", "system-ui"],
    },
    borderRadius: {
      card:  "8px",
      input: "6px",
    },
  },
}
```

### 5.3 Typography Scale

| Role | Tailwind classes | Size / Weight |
|------|-----------------|---------------|
| Page title | `text-2xl font-semibold` | 24 px / 600 |
| Section heading | `text-lg font-medium` | 18 px / 500 |
| Card title | `text-sm font-medium uppercase tracking-wide` | 14 px / 500 |
| Body | `text-sm` | 14 px / 400 |
| Muted / label | `text-xs text-muted` | 12 px / 400 |
| KPI value | `text-3xl font-bold tabular-nums` | 30 px / 700 |

---

## 6. Services Design

### 6.1 PlateValidator (outline)

```python
from collections import deque
from typing import Optional
from pydantic import BaseModel

class OcrFrame(BaseModel):
    plate: str
    confidence: float

class ValidatorState(BaseModel):
    window: list[OcrFrame]
    validated_plate: Optional[str]
    vote_count: Optional[int]
    window_size: int
    is_valid: bool

class PlateValidator:
    """Sliding-window majority-vote plate validator (REQ-PV-01 to PV-05)."""
    def __init__(self, window_size: int = 7, min_conf: float = 0.70): ...
    def add_frame(self, plate: str, confidence: float) -> None: ...
    def validate(self) -> Optional[str]: ...       # count > window/2
    def state(self) -> ValidatorState: ...
    def reset(self) -> None: ...
```

### 6.2 IndianPlateParser (outline)

```python
import re
from typing import Optional
from pydantic import BaseModel

PLATE_RE = re.compile(r"^([A-Z]{2})(\d{1,2})([A-Z]{1,3})(\d{1,4})$")

class ParseResult(BaseModel):
    valid: bool
    state_code: Optional[str]
    rto_code:   Optional[str]
    series:     Optional[str]
    number:     Optional[str]
    raw: str

class IndianPlateParser:
    """Validates and parses Indian vehicle registration plates (REQ-PV-06, PV-07)."""
    @staticmethod
    def parse(plate_string: str) -> ParseResult: ...
```

### 6.3 PlateClassifier (outline)

```python
from pydantic import BaseModel
from typing import Literal
from app.models.common import ProvenanceMixin

class ClassificationResult(ProvenanceMixin):
    plate: str
    status: Literal["authorized", "watchlist", "unauthorized_unrecognized"]

class PlateClassifier:
    """Classifies plates against authorized/watchlist sets (REQ-PC-01 to PC-04)."""
    # Seeded: authorized={TN01AB1234, TN02CD5678}, watchlist={TN03EF9012}
    def classify(self, plate: str) -> ClassificationResult: ...
    def add_authorized(self, plate: str) -> None: ...
    def add_watchlist(self, plate: str) -> None: ...
```

### 6.4 MonteCarloSimulator (outline)

```python
from datetime import datetime
from pydantic import BaseModel
from app.models.common import ProvenanceMixin, ProvenanceEnum

class SimulationResult(ProvenanceMixin):
    single_frame_error_rate: float
    multi_frame_error_rate:  float
    improvement_factor:      float
    n_trials:   int
    n_frames:   int
    seed:       int
    model_version: str
    timestamp:  datetime
    provenance: ProvenanceEnum = ProvenanceEnum.SIMULATED

class MonteCarloSimulator:
    """Seeded Monte Carlo false-decision rate simulation (REQ-MC-01 to MC-04)."""
    def __init__(self, seed: int, model_version: str): ...
    def run(self, n_frames: int, n_trials: int,
            per_frame_error_rate: float) -> SimulationResult: ...
```

### 6.5 DemoDataProvider (outline)

```python
class DemoDataProvider:
    """
    Generates deterministic synthetic data for all dashboard pages.
    All returned dicts/models carry provenance=DEMO (REQ-DD-01 to DD-04).
    """
    def __init__(self, seed: int = 42): ...
    def health(self) -> dict: ...
    def plate_validation_history(self) -> list[dict]: ...
    def ocr_results(self) -> list[dict]: ...
    def alert_log(self) -> list[dict]: ...
    def detection_summary(self) -> dict: ...
    def watchlist_summary(self) -> dict: ...
```

---

## 7. Frontend Routing Table

| Route | Component | Phase | Phase 1 status |
|-------|-----------|-------|----------------|
| `/` | `Overview` | 4 | `<ComingSoon phase={4} />` |
| `/anpr` | `AnprLab` | 2 | `<ComingSoon phase={2} />` |
| `/validation` | `ValidationSimulator` | 2 | `<ComingSoon phase={2} />` |
| `/detection` | `Detection` | 3 | `<ComingSoon phase={3} />` |
| `/datasets` | `DatasetExplorer` | 3 | `<ComingSoon phase={3} />` |
| `/watchlist` | `Watchlist` | 4 | `<ComingSoon phase={4} />` |
| `/alerts` | `Alerts` | 4 | `<ComingSoon phase={4} />` |
| `/evaluation` | `Evaluation` | 5 | `<ComingSoon phase={5} />` |

---

## 8. Data-Fetching Hooks

```ts
// src/hooks/useHealth.ts
export function useHealth() {
  return useQuery({
    queryKey: ["health"],
    queryFn: () => api.get<HealthResponse>("/api/v1/health"),
    refetchInterval: 30_000,
    staleTime: 30_000,
  });
}

// src/hooks/useConfig.ts
export function useConfig() {
  return useQuery({
    queryKey: ["config"],
    queryFn: () => api.get<ConfigResponse>("/api/v1/config"),
    staleTime: 60_000,
  });
}
```

---

## 9. Error-Handling Strategy

### 9.1 Backend Error Matrix

| Scenario | HTTP Status | Handling |
|----------|-------------|---------|
| Missing/invalid config at startup | — | `sys.exit(1)` before accepting requests |
| ML model load failure | — | Mark as not loaded; health → `degraded`; affected routes → `503` |
| Missing dataset file | 404 | `{ error: "dataset_not_found", detail: "...", request_id }` |
| Corrupt/invalid image upload | 422 | `{ error: "invalid_image", detail: "...", request_id }` |
| Upload too large | 413 | `{ error: "payload_too_large", detail: "Max Xmb", request_id }` |
| Wrong MIME type | 415 | `{ error: "unsupported_media_type", detail: "...", request_id }` |
| No GPU | — | Log warning at startup; continue on CPU silently |
| Unhandled exception | 500 | Generic `{ error: "internal", request_id }` — no stack trace exposed |

### 9.2 Frontend Error Matrix

| Scenario | Handling |
|----------|---------|
| Backend unreachable | `useHealth` fails → TopBar badge red → toast "Backend unreachable" |
| Backend `degraded` | TopBar badge amber → toast listing degraded models |
| Any TanStack Query error | `onError` → toast with `ErrorResponse.detail` |
| React render error | `ErrorBoundary` → `ErrorFallback` (title + "Reload" button) |
| No data | `EmptyState` component |
| Loading state | `Skeleton` matching shape of real content |

### 9.3 Structured Log Format

```json
{
  "timestamp": "2026-10-25T10:00:00.000Z",
  "level": "INFO",
  "logger": "app.startup",
  "message": "Application started",
  "context": {
    "version": "0.1.0",
    "demo_mode": true,
    "device": "cpu",
    "models_loaded": { "yolo": false, "easyocr": false },
    "seed": 42,
    "timestamp": "2026-10-25T10:00:00.000Z"
  }
}
```

Per-request log fields: `request_id`, `method`, `path`, `status_code`, `duration_ms`, `demo_mode`.

---

## 10. Demo Mode Data Flow

```
Incoming request
      │
      ▼
DEMO_MODE=true? ──yes──► DemoDataProvider.method()
      │                         │
      no                        ▼
      │                  provenance = "DEMO"
      ▼
Real service / filesystem read
      │
      ▼
provenance = "MEASURED" | "SIMULATED"
```

Frontend demo-mode indicators:
1. "DEMO DATA" pill badge in TopBar (amber, non-dismissible).
2. All `KpiCard` / `ChartCard` receive `provenance="DEMO"` via API response.
3. `DemoModeIndicator` component in TopBar renders only when `config.demo_mode === true`.

---

## 11. Dev Runner Design

### `package.json` (root)

```json
{
  "scripts": {
    "dev": "concurrently --names api,ui --prefix-colors cyan,magenta \"npm run dev:api\" \"npm run dev:ui\"",
    "dev:api": "uvicorn backend.app.main:app --reload --port 8000",
    "dev:ui":  "npm run dev --prefix frontend"
  },
  "devDependencies": {
    "concurrently": "^8.2.0"
  }
}
```

### `Makefile`

```makefile
.PHONY: dev test lint

dev:
	npm run dev

test:
	cd backend && python -m pytest tests/ -v
	cd frontend && npx vitest --run

lint:
	cd backend && ruff check app/ && black --check app/
	cd frontend && npx eslint src/ && npx prettier --check src/
```

---

## 12. Security Considerations (Phase 1)

| Concern | Mitigation |
|---------|-----------|
| CORS | Explicit origin allowlist; wildcard forbidden in production |
| Secret exposure | `/config` endpoint filters via explicit field allowlist in `ConfigResponse` |
| Path traversal | All paths resolved through `config.py`; user-supplied paths rejected at Pydantic validation |
| Upload abuse | MIME-type + size check before image processing |
| No auth (Phase 1) | Local-only academic demo; auth deferred to production hardening |
| No external calls | No outbound network at runtime; model cache downloads handled by ultralytics on first startup only |

---

## 13. Phase 1 Smoke Test (acceptance criteria)

After `npm run dev`:

| # | Check | Pass condition |
|---|-------|---------------|
| 1 | Browser opens `http://localhost:5173` | ShellLayout renders — no blank screen, no 404 |
| 2 | TopBar system-status badge | Shows green "OK" (health returns `status: "ok"`) |
| 3 | Sidebar navigation | All 8 links visible and clickable |
| 4 | Each sidebar link | Renders `ComingSoon` page with correct phase number — no error |
| 5 | TopBar demo indicator | "DEMO DATA" pill visible when `DEMO_MODE=true` |
| 6 | Light/dark toggle | Theme switches; preference persists on reload |
| 7 | Backend health endpoint | `curl http://localhost:8000/api/v1/health` → HTTP 200, `status: "ok"` |
| 8 | Backend config endpoint | `curl http://localhost:8000/api/v1/config` → HTTP 200, no secrets |
| 9 | pytest | All PlateValidator / PlateClassifier / MonteCarlo tests pass |
| 10 | vitest --run | All ProvenanceBadge / KpiCard tests pass |
