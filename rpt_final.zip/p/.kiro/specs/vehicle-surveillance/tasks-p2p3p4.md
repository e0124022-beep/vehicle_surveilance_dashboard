# Tasks — Phases 2, 3 & 4 (Combined)
## Deep Learning-Based Intelligent Vehicle Surveillance System

**Phase:** 2 · 3 · 4  
**Version:** 1.0  
**Date:** 2026-10-25  
**Requirements:** `requirements-p2p3p4.md` | **Design:** `design-p2p3p4.md`  
**Builds on:** Phase 1 tasks (TASK-01 – TASK-24 complete)

---

## Conventions

- Tasks are **ordered within each milestone**; complete in sequence.
- Every task lists **Req IDs**, an **Acceptance Test**, and a **Done When** condition.
- `[BE]` = backend only · `[FE]` = frontend only · `[BOTH]` = touches both.
- "Done When" is the minimum verifiable state — not aspirational completeness.
- Tests must pass before the task is marked done.

---

# MILESTONE 1 — ANPR Lab + Multi-Frame Validation Simulator

## Group M1-A — Database & Repository Foundation

### M1-TASK-01 · SQLite database setup + migrations `[BE]`

**Req IDs:** REQ-M3-27 (schema), REQ-G-08

Create the database layer used by all milestones.

**Files:**
- `backend/app/db/database.py` — async SQLAlchemy/SQLModel engine, `get_session` dependency
- `backend/app/db/migrations/001_initial.sql` — full DDL from design.md §6
- `backend/app/repositories/base.py` — `BaseRepository` with `get`, `list`, `insert`, `delete`
- Run migrations on startup inside `lifespan` using `CREATE TABLE IF NOT EXISTS`

**Acceptance test:**
```bash
cd backend
python -c "
import asyncio
from app.db.database import engine
from sqlalchemy import text
async def t():
    async with engine.connect() as c:
        r = await c.execute(text('SELECT name FROM sqlite_master WHERE type=\\'table\\''))
        tables = [row[0] for row in r.fetchall()]
        assert 'vehicles' in tables
        assert 'alerts' in tables
        assert 'detection_tracks' in tables
        print('Tables:', tables)
asyncio.run(t())
"
```

**Done when:** All 6 tables exist after startup; `get_session` yields an async session without error.

---

### M1-TASK-02 · `VehicleRepository` + seeding `[BE]`

**Req IDs:** REQ-M3-05, REQ-M3-06

Implement `backend/app/repositories/vehicle_repo.py`.

**Requirements:**
- `get(plate)`, `list(page, page_size, q, status)`, `insert(VehicleCreate)`, `update(plate, VehicleUpdate)`, `delete(plate)`
- `seed_defaults()` — inserts `TN01AB1234` authorized, `TN02CD5678` authorized, `TN03EF9012` watchlist if not already present
- Call `seed_defaults()` in lifespan startup
- All plate strings normalised to uppercase before write
- Duplicate insert raises `IntegrityError` → caller converts to HTTP 409

**Acceptance test:**
```bash
cd backend
python -c "
import asyncio
from app.db.database import engine
from app.repositories.vehicle_repo import VehicleRepository
async def t():
    async with engine.begin() as conn:
        repo = VehicleRepository(conn)
        await repo.seed_defaults()
        v = await repo.get('TN03EF9012')
        assert v is not None and v.status == 'watchlist'
        print('Seed OK:', v)
asyncio.run(t())
"
```

**Done when:** Seeded vehicles present after startup; `list()` returns them paginated.

---

## Group M1-B — OcrPipeline Service

### M1-TASK-03 · Port `OcrPipeline` service `[BE]`

**Req IDs:** REQ-M1-04, REQ-M1-05, REQ-M1-06, REQ-M1-07, REQ-M1-08, REQ-M1-09, REQ-M1-10

Port the notebook multi-preprocessing OCR pipeline to `backend/app/services/ocr_pipeline.py`.

**Requirements:**
- 4 variants × 3 upscales = 12 sub-images max
- CLAHE: `cv2.createCLAHE(clipLimit=2.0)` → apply → upscale → EasyOCR
- Sharpen: unsharp-mask kernel → upscale → EasyOCR
- Otsu: grayscale → `cv2.threshold(..., THRESH_OTSU)` → upscale → EasyOCR
- Adaptive: `cv2.adaptiveThreshold(..., ADAPTIVE_THRESH_GAUSSIAN_C)` → upscale → EasyOCR
- Optional bilateral denoise (`cv2.bilateralFilter`) and Gaussian blur before upscale
- Best candidate = highest confidence passing `^([A-Z]{2})(\d{1,2})([A-Z]{1,3})(\d{1,4})$`; fallback = highest confidence raw
- Character correction: digit positions → O→0, I→1, S→5, B→8; letter positions → inverse
- Return `OcrRunResult` with `provenance=MEASURED`; if `confidence < 0.70` set `low_confidence=True`
- EasyOCR `Reader` injected at construction (from `app.state.easyocr_reader`)

**Acceptance test:**
```bash
cd backend
python -c "
import numpy as np, cv2
from app.services.ocr_pipeline import OcrPipeline
# Create a synthetic white image with black text (not a real plate — just smoke test)
img = np.ones((64, 200, 3), dtype=np.uint8) * 255
# Pipeline should run without error even if no text detected
from app.core.config import get_settings
import easyocr
reader = easyocr.Reader(['en'], gpu=False, verbose=False)
pipe = OcrPipeline(reader=reader, config=get_settings())
result = pipe.run(img, crop=None, denoise=False)
assert len(result.variants) == 12
assert result.provenance in ('MEASURED', 'DEMO')
print('OcrPipeline OK, variants:', len(result.variants))
"
```

**Done when:** Pipeline runs 12 variants on a synthetic image without error; result has correct schema.

---

### M1-TASK-04 · `AnprRepository` `[BE]`

**Req IDs:** REQ-M1-20, REQ-M1-21

Implement `backend/app/repositories/anpr_repo.py`:
- `insert_run(OcrRunResult)` → persists to `anpr_runs`
- `list_runs(page, page_size)` → returns `Page[AnprRunSummary]`
- `get_run(run_id)` → returns `OcrRunResult | None`

**Done when:** Insert + list round-trip works in a pytest test with an in-memory SQLite DB.

---

### M1-TASK-05 · Job Manager `[BE]`

**Req IDs:** REQ-G-06, REQ-M1-11, REQ-M2-03

Implement `backend/app/core/job_manager.py`.

**Requirements:**
- `Job` dataclass: `job_id`, `status`, `progress_pct`, `result`, `error`, `cancel_event`
- `JobManager` singleton, stored on `app.state.job_manager`
- `submit(async_fn, *args)` → spawns `asyncio.create_task`; returns `job_id`
- `cancel(job_id)` → sets `cancel_event`
- `get(job_id)` → returns `Job` or `None`
- `subscribe(job_id)` → `AsyncGenerator` yielding SSE-formatted strings; fan-out to multiple subscribers via `asyncio.Queue`
- Job dict cleaned up after 1 hour (configurable TTL)

**Acceptance test:**
```bash
cd backend
python -c "
import asyncio
from app.core.job_manager import JobManager
async def fake_job(job_id, jm):
    await jm.update(job_id, progress_pct=50)
    await asyncio.sleep(0.1)
    await jm.complete(job_id, result={'ok': True})

async def t():
    jm = JobManager()
    job_id = await jm.submit(fake_job)
    await asyncio.sleep(0.3)
    job = jm.get(job_id)
    assert job.status == 'completed'
    assert job.result == {'ok': True}
    print('JobManager OK')
asyncio.run(t())
"
```

**Done when:** Job completes and result is retrievable; subscribe generator yields at least one event.

---

### M1-TASK-06 · ANPR API endpoints `[BE]`

**Req IDs:** REQ-M1-01, REQ-M1-03, REQ-M1-11, REQ-M1-21, REQ-G-09

Implement `backend/app/api/v1/anpr.py`:

- `POST /api/v1/anpr/upload` — validate MIME + size → submit `OcrPipeline.run` to `JobManager` → return `{ job_id }`
- `GET /api/v1/anpr/job/{job_id}` — return `OcrJobStatus`
- `GET /api/v1/anpr/stream/{job_id}` — `EventSourceResponse` from `JobManager.subscribe`
- `GET /api/v1/anpr/history` — return `Page[AnprRunSummary]` from `AnprRepository`

Accept crop parameters as form fields: `crop_x`, `crop_y`, `crop_w`, `crop_h` (all optional float 0–1 normalised).

**Acceptance test:**
```bash
cd backend && uvicorn app.main:app --port 8000 &
sleep 2
# Upload a small test image
curl -s -X POST http://localhost:8000/api/v1/anpr/upload \
  -F "file=@tests/fixtures/test_plate.jpg" | python -m json.tool
# → { "job_id": "..." }
JOB_ID=$(curl -s -X POST ... | python -c "import sys,json; print(json.load(sys.stdin)['job_id'])")
sleep 3
curl -s http://localhost:8000/api/v1/anpr/job/$JOB_ID | python -m json.tool
# → { "status": "completed", "result": { ... } }
pkill -f uvicorn
```

**Done when:** Upload returns `job_id`; polling returns `completed` with result; history returns paginated list.

---

### M1-TASK-07 · pytest for OcrPipeline + ANPR API `[BE]`

**Req IDs:** REQ-G-12

Write `backend/tests/test_ocr_pipeline.py` and `backend/tests/test_api_anpr.py`.

**`test_ocr_pipeline.py` cases:**
| Test | Checks |
|------|--------|
| `test_12_variants_produced` | Pipeline returns exactly 12 `OcrVariantResult` entries |
| `test_confidence_filter_low` | `low_confidence=True` when all variants score < 0.70 |
| `test_char_correction_digit_pos` | O→0, I→1 applied in digit positions |
| `test_char_correction_letter_pos` | 0→O in letter positions |
| `test_best_candidate_regex` | Highest regex-passing candidate selected over higher-raw-confidence non-matching |
| `test_no_crop` | Runs without crop parameter |
| `test_with_crop` | Crop region applied before preprocessing |
| `test_provenance_measured` | `result.provenance == "MEASURED"` |

**`test_api_anpr.py` cases (using `httpx.AsyncClient`):**
| Test | Checks |
|------|--------|
| `test_upload_valid_image` | Returns 202 + `job_id` |
| `test_upload_wrong_mime` | Returns 415 |
| `test_upload_too_large` | Returns 413 |
| `test_job_not_found` | `GET /job/bad-id` returns 404 |
| `test_history_empty` | Returns `{ items: [], total: 0 }` |

**Done when:** `pytest tests/test_ocr_pipeline.py tests/test_api_anpr.py -v` all pass.

---

## Group M1-C — Validation Simulator Service & API

### M1-TASK-08 · `SimulationRepository` `[BE]`

**Req IDs:** REQ-M1-29, REQ-M1-30

Implement `backend/app/repositories/simulation_repo.py`:
- `insert_run(SimulationResult)` → serialise `tracks` to JSON, persist to `validation_sim_runs`
- `list_runs(page, page_size)` → `Page[SimRunSummary]`
- `get_run(run_id)` → deserialise JSON back to `SimulationResult`

**Done when:** Round-trip insert + get returns identical `improvement_factor`.

---

### M1-TASK-09 · Extend `MonteCarloSimulator` for comparison curve `[BE]`

**Req IDs:** REQ-M1-23, REQ-M1-27

Extend `backend/app/services/monte_carlo.py` (existing Phase 1 service) to add:
- `run_comparison(n_frames_range: list[int], n_trials: int, per_frame_error_rate: float)` → `list[ComparisonPoint]`
- Each `ComparisonPoint` contains `n_frames`, `single_frame_error`, `multi_frame_error`, `ci_lower`, `ci_upper` (95% Wilson CI or bootstrap)

**Acceptance test:**
```bash
cd backend
python -c "
from app.services.monte_carlo import MonteCarloSimulator
sim = MonteCarloSimulator(seed=42, model_version='test')
curve = sim.run_comparison([1,3,5,7,9], n_trials=1000, per_frame_error_rate=0.2)
assert len(curve) == 5
assert curve[-1].multi_frame_error < curve[0].single_frame_error
assert all(c.ci_lower <= c.multi_frame_error <= c.ci_upper for c in curve)
print('Comparison curve OK')
"
```

**Done when:** Comparison curve has correct length; multi-frame error decreases with more frames.

---

### M1-TASK-10 · Validation Simulator API `[BE]`

**Req IDs:** REQ-M1-22, REQ-M1-23, REQ-M1-28, REQ-M1-30

Implement `backend/app/api/v1/validation.py`:
- `POST /api/v1/validation/run` — validates `SimulationRequest`, runs `MonteCarloSimulator` + `PlateValidator` for each track, persists via `SimulationRepository`, returns `SimulationResult`
- `GET /api/v1/validation/history` — paginated list
- `GET /api/v1/validation/export/{run_id}` — stream CSV with columns: `track_id`, `frame_idx`, `raw_plate`, `confidence`, `accepted`, `current_winner` — compatible with `outputs/ocr_validation_simulation.csv`

**Acceptance test:**
```bash
curl -s -X POST http://localhost:8000/api/v1/validation/run \
  -H "Content-Type: application/json" \
  -d '{"window_size":7,"min_conf":0.70,"error_probability":0.20,"n_tracks":3,"seed":42}' \
  | python -c "import sys,json; d=json.load(sys.stdin); assert d['provenance']=='SIMULATED'; print('OK:', d['improvement_factor'])"
```

**Done when:** Run returns valid `SimulationResult`; CSV export downloads with correct headers.

---

### M1-TASK-11 · pytest for Validation Simulator `[BE]`

**Req IDs:** REQ-G-12

Write `backend/tests/test_api_validation.py`:

| Test | Checks |
|------|--------|
| `test_run_returns_simulated` | `provenance == "SIMULATED"` |
| `test_window_size_respected` | Track frames honour `window_size` |
| `test_csv_export_headers` | CSV has required columns |
| `test_history_after_run` | History count increments |
| `test_invalid_params_422` | `window_size=0` → 422 |

**Done when:** All tests pass.

---

## Group M1-D — Frontend: ANPR Lab Page

### M1-TASK-12 · `CropBox` shared component `[FE]`

**Req IDs:** REQ-M1-02

Implement `frontend/src/components/anpr/CropBox.tsx`:
- Wraps `react-image-crop` (install as dependency)
- Props: `src: string`, `onChange: (crop: PercentCrop) => void`
- Returns crop as normalised percentage coords (0–1)
- Shows "Drag to crop" hint overlay before first interaction
- Keyboard accessible: arrow keys nudge crop region

**Done when:** Component renders uploaded image with draggable crop; `onChange` fires with valid crop object.

---

### M1-TASK-13 · `OcrProgress` + `PreprocessingGrid` + `ConfidenceGauge` `[FE]`

**Req IDs:** REQ-M1-12, REQ-M1-13, REQ-M1-14, REQ-M1-19

**`OcrProgress`** (`src/components/anpr/OcrProgress.tsx`):
- Opens `EventSource` for `jobId`; parses progress events
- Shows progress bar with `{variant} {upscale}x` label
- On `type:done` calls `onComplete(result)` and closes stream

**`PreprocessingGrid`** (`src/components/anpr/PreprocessingGrid.tsx`):
- Accepts `variants: OcrVariantResult[]`
- 3-column grid; each cell: thumbnail URL (fetched from `result.thumbnail_url`), variant label, confidence chip
- Best candidate highlighted with accent border

**`ConfidenceGauge`** (`src/components/anpr/ConfidenceGauge.tsx`):
- Recharts `RadialBarChart` single bar
- Green above 0.70; amber 0.50–0.70; red below 0.50
- Shows numeric value in centre

**Done when:** All three components render without error given mock data; gauge colours correct.

---

### M1-TASK-14 · `OcrCandidatesTable`, `PlateStructureBreakdown`, `CharCorrectionDisplay` `[FE]`

**Req IDs:** REQ-M1-13, REQ-M1-15, REQ-M1-16, REQ-M1-17

**`OcrCandidatesTable`**: sortable table (Shadcn Table); columns: Variant, Upscale, Raw, Cleaned, Confidence (% with colour), Regex Match (✓/✗); best row highlighted.

**`PlateStructureBreakdown`**: 4 tiles (State / RTO / Series / Number) from `ParseResult`; empty state when `valid=false`.

**`CharCorrectionDisplay`**: two code-block spans side by side; changed characters highlighted with amber background diff.

**Done when:** All components render with mock OCR data; table sorts correctly.

---

### M1-TASK-15 · ANPR Lab page assembly `[FE]`

**Req IDs:** REQ-M1-01 – REQ-M1-21

Assemble `frontend/src/pages/AnprLab.tsx`:

1. `ImageUploader` + `CropBox` — file pick/drag-drop; preview; crop
2. Submit button → `useAnprUpload()` → get `job_id`
3. `OcrProgress` component tracks SSE → on complete, set result state
4. Render: `PreprocessingGrid`, `OcrCandidatesTable`, `ConfidenceGauge`, `PlateStructureBreakdown`, `CharCorrectionDisplay`, `StatusBadge` (db status), processing time `ProvenanceBadge(MEASURED)`
5. `LOW_CONFIDENCE` warning banner (distinct from `PlaceholderBanner`) when `low_confidence=true`
6. `AnprHistory` section: `useAnprHistory()` paginated table of past runs
7. Demo fallback: `useConfig().demo_mode` → load demo result from `DemoDataProvider`

**Acceptance test (manual):**
- Upload test plate image → crop → submit → progress bar fills → results appear
- Confidence < 0.70 → LOW_CONFIDENCE banner shown; no "validated" label
- History section shows previous run

**Done when:** Full page renders in both demo mode and real mode; no console errors.

---

### M1-TASK-16 · `SimulatorControls` + `FrameVoteTable` + `ComparisonChart` `[FE]`

**Req IDs:** REQ-M1-22 – REQ-M1-27

**`SimulatorControls`** (`src/components/validation/SimulatorControls.tsx`):
- shadcn `Slider` for window size, min conf, error prob; `Input` for n_tracks and seed
- Live display of current values; "Run Simulation" button

**`FrameVoteTable`** (`src/components/validation/FrameVoteTable.tsx`):
- One accordion/tab per track
- Columns: Frame, Plate Reading, Confidence, Accepted (✓/✗), Vote Counts, Current Winner
- Rejected rows: dimmed background + "REJECTED" badge (amber)
- `ProvenanceBadge(SIMULATED)` in table header

**`ComparisonChart`** (`src/components/validation/ComparisonChart.tsx`):
- Recharts `ComposedChart`: two `Line` traces (single-frame, N-frame) + `Area` for CI band
- Legend labelled "Single Frame" / "Multi-Frame (N-vote)"
- `ChartCard` wrapper with `provenance="SIMULATED"` and PNG export

**Done when:** All components render with mock data; chart shows two lines with shaded CI area.

---

### M1-TASK-17 · Validation Simulator page assembly `[FE]`

**Req IDs:** REQ-M1-22 – REQ-M1-30

Assemble `frontend/src/pages/ValidationSimulator.tsx`:

1. `SimulatorControls` → on submit call `useValidationRun()` mutation
2. Loading state: skeleton loaders for table and chart
3. Results: `FrameVoteTable` (per-track accordion), `TrackSummaryCards` (KpiCard per track), `ComparisonChart`
4. CSV export button → `GET /api/v1/validation/export/{run_id}` → download
5. `SimHistory` section: `useValidationHistory()` paginated list with "Reload" action

**Done when:** Full page renders; CSV export triggers download; history updates after run.

---

### M1-TASK-18 · Vitest tests for M1 frontend components `[FE]`

**Req IDs:** REQ-G-12

Write `frontend/src/__tests__/m1/`:

| File | Tests |
|------|-------|
| `CropBox.test.tsx` | Renders image; onChange fires; no hardcoded crop value |
| `OcrCandidatesTable.test.tsx` | Renders 12 rows; best row has accent class; sort by confidence works |
| `ConfidenceGauge.test.tsx` | Value rendered; correct colour class for high/mid/low |
| `FrameVoteTable.test.tsx` | Rejected rows have "REJECTED" badge; accepted rows do not |
| `ComparisonChart.test.tsx` | SIMULATED provenance badge present; chart container renders |

**Done when:** `npx vitest --run src/__tests__/m1/` all pass.

---

## M1 SMOKE TEST — TASK-M1-ST

**Req IDs:** REQ-M1-ST-01

**Steps:**
1. `npm run dev` — both servers start.
2. Navigate to ANPR Lab → upload a JPEG plate image.
3. Draw crop region (verify it's interactive, not fixed).
4. Submit → progress bar advances through variants.
5. Result appears: preprocessing grid, candidates table, confidence gauge.
6. If confidence ≥ 0.70: plate structure breakdown shows state/RTO/series/number; DB status badge shows `authorized` or `watchlist`.
7. Upload a low-quality image → `LOW_CONFIDENCE` banner shown; no validated label.
8. Navigate to Validation Simulator → set window=5, error_prob=0.30, tracks=3, seed=99 → Run.
9. Frame vote table shows 3 track tabs; at least one rejected row highlighted.
10. Comparison chart shows two lines with CI shading; `SIMULATED` badge present.
11. CSV export button → file downloads with correct headers.

**Done when:** All 11 steps pass without error.

---

# MILESTONE 2 — Detection & Tracking + Dataset Explorer

## Group M2-A — Dataset Service

### M2-TASK-01 · `DatasetService` `[BE]`

**Req IDs:** REQ-M2-01, REQ-M2-07, REQ-M2-15, REQ-M2-16, REQ-M2-17, REQ-M2-18, REQ-M2-19, REQ-G-10

Implement `backend/app/services/dataset_service.py`:
- `list_sequences(datasets_root) -> list[SequenceInfo]` — scan `ua_detrac/DETRAC-Images/DETRAC-Images/MVI_*/` for JPEG frames; return name + frame_count
- `ua_detrac_stats() -> DatasetStats` — count sequences, sum frames, detect resolution from first frame
- `indian_plates_stats() -> DatasetStats` — count JPEG/PNG files in `indian_plates/`
- `get_thumbnail(dataset, path, size) -> bytes` — read image, resize to `size` px longest side, return JPEG bytes
- `random_sample(dataset, n, seed) -> list[str]` — reproducible random file paths
- All methods must catch `FileNotFoundError` and return graceful fallback / raise `DatasetNotFoundError`
- Never write to datasets directory (assert path is under `DATASETS_ROOT`)

**Acceptance test:**
```bash
cd backend
python -c "
from app.services.dataset_service import DatasetService
from app.core.config import get_settings
svc = DatasetService(config=get_settings())
# Should not raise even if datasets missing (returns empty stats)
stats = svc.ua_detrac_stats()
print('UA-DETRAC stats:', stats)
assert stats.provenance in ('MEASURED', 'DEMO')
"
```

**Done when:** Service runs without error whether or not datasets exist; thumbnail endpoint returns valid JPEG bytes.

---

### M2-TASK-02 · Dataset Explorer API endpoints `[BE]`

**Req IDs:** REQ-M2-01, REQ-M2-15 – REQ-M2-19, REQ-M2-20

Implement `backend/app/api/v1/datasets.py`:
- `GET /ua-detrac/stats`, `/ua-detrac/sequences`, `/ua-detrac/gallery`
- `GET /indian-plates/stats`, `/indian-plates/gallery`
- `GET /{dataset}/thumbnail/{path}` — validate path is within `DATASETS_ROOT` (path traversal guard); return `Response(media_type="image/jpeg")`
- Gallery endpoints: `?page&page_size&sequence` (UA-DETRAC sequence filter)

**Acceptance test:**
```bash
curl -s http://localhost:8000/api/v1/datasets/ua-detrac/stats | python -m json.tool
# → { "dataset": "ua-detrac", "sequence_count": N, ... }
curl -s "http://localhost:8000/api/v1/datasets/ua-detrac/gallery?page=1&page_size=6" | python -m json.tool
# → { "items": [...], "total": N }
```

**Done when:** Stats and gallery endpoints return valid JSON; thumbnail returns `image/jpeg` bytes; path traversal attempt returns 400.

---

### M2-TASK-03 · pytest for DatasetService + API `[BE]`

**Req IDs:** REQ-G-12

Write `backend/tests/test_dataset_service.py` and `backend/tests/test_api_datasets.py`:

| Test | Checks |
|------|--------|
| `test_stats_missing_dataset` | Returns empty/DEMO stats without raising |
| `test_path_traversal_rejected` | `../../../etc/passwd` → 400 |
| `test_thumbnail_returns_jpeg` | Bytes are valid JPEG (`b'\xff\xd8'` header) |
| `test_gallery_pagination` | Page 2 returns different items than page 1 |
| `test_random_sample_reproducible` | Same seed → same file list |

**Done when:** All tests pass.

---

## Group M2-B — Detection Service

### M2-TASK-04 · `DetectionService` `[BE]`

**Req IDs:** REQ-M2-03, REQ-M2-04, REQ-M2-05, REQ-M2-07, REQ-M2-08, REQ-M2-11, REQ-G-04, REQ-G-05

Implement `backend/app/services/detection_service.py`.

**Requirements:**
- YOLO11n loaded once at startup; stored on `app.state.yolo_model`
- ByteTrack initialized per-run (no shared state between runs)
- COCO classes filter: `[2, 3, 5, 7]` → `["car","motorcycle","bus","truck"]`
- `async run_sequence(sequence_path, confidence, max_frames, seed, progress_cb, cancel_event)`
  - Read sorted JPEG frames; process up to `max_frames`
  - Per frame: `model.predict(frame, classes=[2,3,5,7], conf=confidence)` → ByteTrack update
  - Yield `progress_cb(frame_idx, total, len(detections))`
  - Check `cancel_event.is_set()` after each frame; break if set
  - Compute FPS = frames / wall_clock_seconds → tag MEASURED
- Return `DetectionRunResult` with all track rows

**Acceptance test (model may not be loaded; test with CPU + small sequence):**
```bash
cd backend
python -c "
import asyncio
from pathlib import Path
from app.services.detection_service import DetectionService
from app.core.config import get_settings
import asyncio

async def t():
    # Use a stub if no real model — test the frame-loop logic
    print('DetectionService import OK')
asyncio.run(t())
"
```

**Done when:** Service imports without error; frame loop respects cancel_event (verified in pytest with mock model).

---

### M2-TASK-05 · `DetectionRepository` + annotated frame serving `[BE]`

**Req IDs:** REQ-M2-08, REQ-M2-09, REQ-M2-13, REQ-M2-14

Implement `backend/app/repositories/detection_repo.py`:
- `insert_run(DetectionRunDetail)` + `insert_tracks(run_id, list[TrackRow])` (bulk insert)
- `list_runs(page, page_size)` → `Page[RunSummary]`
- `get_run(run_id)` → `DetectionRunDetail | None`
- `get_tracks(run_id, page, page_size)` → `Page[TrackRow]`
- `get_chart_data(run_id)` → `DetectionCharts` (aggregation queries)
- `get_frame_tracks(run_id, frame_idx)` → `list[TrackRow]` (for annotation overlay)

Frame annotation in API handler (`detection.py`):
- Read original JPEG from `sequence_path/imgNNNNN.jpg`
- Draw bounding boxes + track IDs using `cv2.rectangle` / `cv2.putText`
- Resize to thumbnail (256px) unless `?full=true`
- Return `Response(media_type="image/jpeg")`

**Done when:** Annotated frame endpoint returns valid JPEG; chart data returns correct class counts.

---

### M2-TASK-06 · Detection API endpoints `[BE]`

**Req IDs:** REQ-M2-03 – REQ-M2-09, REQ-M2-13, REQ-M2-14, REQ-M2-20

Implement `backend/app/api/v1/detection.py`:
- `POST /detection/start` → validate `DetectionRequest` → submit `DetectionService.run_sequence` to `JobManager` → return `{ job_id }`
- `GET /detection/job/{job_id}` → `DetectionJobStatus`
- `GET /detection/stream/{job_id}` → SSE from `JobManager.subscribe`
- `DELETE /detection/job/{job_id}` → `JobManager.cancel`
- `GET /detection/runs` → paginated from `DetectionRepository`
- `GET /detection/run/{run_id}` → detail
- `GET /detection/run/{run_id}/frame/{idx}` → annotated JPEG
- `GET /detection/run/{run_id}/tracks` → paginated tracks
- `GET /detection/run/{run_id}/charts` → `DetectionCharts`

**Acceptance test:**
```bash
# Start a detection job on the first available sequence (or demo mode)
curl -s -X POST http://localhost:8000/api/v1/detection/start \
  -H "Content-Type: application/json" \
  -d '{"sequence_name":"MVI_20011","confidence_threshold":0.5,"max_frames":5}' \
  | python -m json.tool
# → { "job_id": "..." }
```

**Done when:** Job created; SSE stream emits progress events; runs endpoint lists completed run; charts return valid data.

---

### M2-TASK-07 · pytest for DetectionService + API `[BE]`

**Req IDs:** REQ-G-12

Write `backend/tests/test_detection_service.py` and `backend/tests/test_api_detection.py`:

| Test | Checks |
|------|--------|
| `test_cancel_stops_loop` | cancel_event terminates frame loop before max_frames |
| `test_empty_sequence_error` | Empty directory → raises `EmptySequenceError` |
| `test_fps_measured` | `result.fps > 0`; provenance MEASURED |
| `test_job_cancel_endpoint` | DELETE returns 200; job status becomes cancelled |
| `test_run_history_pagination` | page=2 returns different items |
| `test_chart_class_distribution` | Returns counts for all detected classes |
| `test_annotated_frame_is_jpeg` | Frame endpoint content-type is image/jpeg |

**Done when:** All tests pass.

---

## Group M2-C — Frontend: Detection & Dataset Explorer

### M2-TASK-08 · `FrameViewer` + `JobProgress` shared components `[FE]`

**Req IDs:** REQ-M2-10

**`FrameViewer`** (`src/components/detection/FrameViewer.tsx`):
- Props: `runId: string`, `totalFrames: number`
- Range input scrubber (0 to `totalFrames-1`)
- Side-by-side panels: left = original JPEG (`GET /frame/{idx}`), right = annotated JPEG (`GET /frame/{idx}`)
- Lazy fetch: only request current frame ± 1 prefetch
- Keyboard: ← prev frame, → next frame
- Loading state: `<Skeleton>` while image loads

**`JobProgress`** (`src/components/detection/JobProgress.tsx`):
- Props: `jobId: string | null`, `type: "anpr" | "detection"`, `onComplete?: (runId: string) => void`
- Opens `EventSource` for correct stream URL
- Shows progress bar (`progress_pct`) + "Frame X / Y" counter for detection
- On `type:cancelled` → show "Cancelled" chip; on `type:error` → show error toast

**Done when:** FrameViewer keyboard navigation works; JobProgress bar advances with mock SSE events.

---

### M2-TASK-09 · Detection & Tracking page assembly `[FE]`

**Req IDs:** REQ-M2-01 – REQ-M2-14

Assemble `frontend/src/pages/Detection.tsx`:

1. `SequenceSelector` dropdown → `useUaDetracSequences()`; `EmptyState` if no sequences
2. `DetectionConfig` inputs (confidence, max frames)
3. "Start Run" button → `useDetectionStart()` → `job_id`
4. `JobProgress` component (SSE) → on complete, open `FrameViewer`
5. `FrameViewer` (scrubber + side-by-side)
6. Three `ChartCard` components: class distribution (BarChart), vehicles/frame (LineChart), track-length histogram (BarChart) — all `MEASURED`
7. `RunHistory` table: `useDetectionRuns()` paginated; click row → load run results without re-running
8. Demo fallback: demo run in history with `DEMO` badge

**Done when:** Page renders; selecting past run loads viewer; charts render with data.

---

### M2-TASK-10 · Dataset Explorer page assembly `[FE]`

**Req IDs:** REQ-M2-15 – REQ-M2-19

Assemble `frontend/src/pages/DatasetExplorer.tsx`:

1. Two `KpiCard` rows: UA-DETRAC stats (sequences, frames, resolution) + Indian plates (image count) — tagged `MEASURED` or `DEMO`
2. Tab or section selector: UA-DETRAC / Indian Plates
3. `DatasetGallery`: `useDatasetGallery(dataset, page)` → paginated grid; `<img loading="lazy">` for thumbnails
4. "Random Sample" button → `useDatasets().randomSample(n=24, seed)` → refresh gallery
5. `EmptyState` when dataset missing

**Done when:** Gallery loads thumbnails lazily; `EmptyState` shows when dataset missing in demo mode.

---

### M2-TASK-11 · Vitest tests for M2 frontend components `[FE]`

**Req IDs:** REQ-G-12

Write `frontend/src/__tests__/m2/`:

| File | Tests |
|------|-------|
| `FrameViewer.test.tsx` | Scrubber renders; keyboard nav fires frame change; skeleton on load |
| `JobProgress.test.tsx` | Progress bar at 50% renders correctly; cancelled state shows chip |
| `DatasetGallery.test.tsx` | Renders 6 thumbnails; EmptyState when items=[] |
| `DetectionCharts.test.tsx` | All 3 ChartCard titles present; MEASURED badge on each |

**Done when:** `npx vitest --run src/__tests__/m2/` all pass.

---

## M2 SMOKE TEST — TASK-M2-ST

**Req IDs:** REQ-M2-ST-01

**Steps:**
1. Navigate to Dataset Explorer → UA-DETRAC stats card shows sequence count > 0 (or DEMO fallback).
2. Gallery tab loads thumbnails (lazy); page 2 shows different images.
3. Navigate to Detection & Tracking → sequence dropdown lists sequences.
4. Select first sequence → max frames = 20 → confidence = 0.5 → Start Run.
5. Progress bar advances; frame counter updates.
6. Run completes → FrameViewer opens at frame 0.
7. Scrub to frame 10 → annotated + original images update.
8. All 3 charts render with data labelled `MEASURED`.
9. History list shows the completed run.
10. Click run in history list → FrameViewer + charts reload without re-running (no new SSE stream).
11. Cancel a second run mid-way → status shows "Cancelled" in history.

**Done when:** All 11 steps pass without error.

---

# MILESTONE 3 — Watchlist & Alerts + Overview

## Group M3-A — Watchlist Service & API

### M3-TASK-01 · Watchlist CRUD API `[BE]`

**Req IDs:** REQ-M3-01 – REQ-M3-08

Implement `backend/app/api/v1/watchlist.py`:

- `GET /watchlist` — `?page&page_size&q&status` → `Page[VehicleRecord]`
- `POST /watchlist` — validate plate with `IndianPlateParser`; 422 if invalid; 409 if duplicate; insert; return `VehicleRecord`
- `PUT /watchlist/{plate}` — update status/description; 404 if not found
- `DELETE /watchlist/{plate}` — 404 if not found; 204 on success
- `POST /watchlist/import` — parse CSV (`plate,status,description`); validate each row; bulk insert valid; return `ImportSummary`
- `GET /watchlist/export` — stream all vehicles as CSV (`text/csv`)

**Acceptance test:**
```bash
# Add a vehicle
curl -s -X POST http://localhost:8000/api/v1/watchlist \
  -H "Content-Type: application/json" \
  -d '{"plate":"MH12AB3456","status":"watchlist","description":"Test"}' | python -m json.tool
# → { "plate": "MH12AB3456", "status": "watchlist", ... }

# List
curl -s "http://localhost:8000/api/v1/watchlist?page=1" | python -c "
import sys,json; d=json.load(sys.stdin); assert d['total']>=4; print('Total:', d['total'])"

# Delete
curl -s -X DELETE http://localhost:8000/api/v1/watchlist/MH12AB3456 -o /dev/null -w "%{http_code}"
# → 204
```

**Done when:** All 6 operations work; invalid plate returns 422; duplicate returns 409.

---

### M3-TASK-02 · pytest for Watchlist `[BE]`

**Req IDs:** REQ-G-12

Write `backend/tests/test_api_watchlist.py`:

| Test | Checks |
|------|--------|
| `test_seeded_vehicles_present` | 3 seeded plates in list |
| `test_add_valid_plate` | Returns 201 with VehicleRecord |
| `test_add_invalid_plate_regex` | Returns 422 |
| `test_add_duplicate` | Returns 409 |
| `test_update_status` | Status changes reflected in GET |
| `test_delete_plate` | Returns 204; subsequent GET returns 404 |
| `test_csv_import_valid` | Imports 2 rows; ImportSummary.rows_imported==2 |
| `test_csv_import_invalid_row` | Skipped row reported in skipped_reasons |
| `test_csv_export_headers` | CSV starts with `plate,status,description` |

**Done when:** All tests pass.

---

## Group M3-B — Alert Engine & API

### M3-TASK-03 · `AlertEngine` + `AlertRepository` `[BE]`

**Req IDs:** REQ-M3-09, REQ-M3-10, REQ-M3-11, REQ-M3-13

Implement `backend/app/services/alert_engine.py` and `backend/app/repositories/alert_repo.py`.

**`AlertEngine`:**
- `process(plate, classification, track_id, frame_image, detection_timestamp)` → `AlertRecord | None`
- Returns `None` for `authorized`
- Generates `alert_id = uuid4()`
- `alert_latency_ms` = `(datetime.utcnow() - detection_timestamp).total_seconds() * 1000` if `detection_timestamp` else `0.0`
- If `frame_image` is not None: crop bounding box region, save to `OUTPUTS_ROOT/evidence/{alert_id}.jpg` using OpenCV
- Persists via `AlertRepository`
- **Never** makes any external network call

**`AlertRepository`:**
- `insert(AlertRecord)`, `list(page, page_size, status, from_dt, to_dt, plate)` → filtered `Page[AlertRecord]`, `get(alert_id)`, `count_by_status()`, `timeline_bins(interval)` → chart data

**Acceptance test:**
```bash
cd backend
python -c "
import asyncio
from datetime import datetime
from app.services.alert_engine import AlertEngine
from app.services.plate_classifier import PlateClassifier, ClassificationResult
from app.models.common import ProvenanceEnum

async def t():
    # Use an in-memory repo stub
    pc = PlateClassifier()
    clf = pc.classify('TN03EF9012')
    assert clf.status == 'watchlist'
    print('AlertEngine input OK; status:', clf.status)
asyncio.run(t())
"
```

**Done when:** `AlertEngine.process` persists an alert for watchlist plates; returns `None` for authorized; evidence saved to correct path.

---

### M3-TASK-04 · Alerts API endpoints `[BE]`

**Req IDs:** REQ-M3-14, REQ-M3-15, REQ-M3-18

Implement `backend/app/api/v1/alerts.py`:
- `GET /alerts` — filtered + paginated; query params: `status`, `from_dt`, `to_dt`, `plate` (partial match)
- `GET /alerts/export` — same filters, returns `text/csv` compatible with `outputs/alerts.csv`
- `GET /alerts/{alert_id}` — single alert
- `GET /alerts/{alert_id}/evidence` — serve evidence JPEG from `outputs/evidence/`; 404 if not present

**Done when:** All 4 endpoints return correct data; evidence endpoint returns JPEG or 404.

---

### M3-TASK-05 · Wire Alert Engine to ANPR Lab + Validation Simulator `[BE]`

**Req IDs:** REQ-M3-23

Update `anpr.py` and `validation.py` job handlers:
- After `OcrPipeline.run` completes: call `AlertEngine.process(best_plate, classification, ...)`
- After `MonteCarloSimulator` + `PlateValidator` produces a validated plate per track: call `AlertEngine.process(...)`
- Wrap in try/except so alert failure does not break the OCR/simulation result

**Acceptance test:**
```bash
# Run OCR on a plate known to be in watchlist (TN03EF9012)
# After job completes, check alerts list has a new entry
curl -s http://localhost:8000/api/v1/alerts | python -c "
import sys,json; d=json.load(sys.stdin); print('Alerts:', d['total'])"
```

**Done when:** After an ANPR run with a watchlist plate, a new alert appears in `GET /alerts`.

---

### M3-TASK-06 · pytest for AlertEngine + API `[BE]`

**Req IDs:** REQ-G-12

Write `backend/tests/test_alert_engine.py` and `backend/tests/test_api_alerts.py`:

| Test | Checks |
|------|--------|
| `test_watchlist_triggers_alert` | AlertEngine returns AlertRecord for watchlist plate |
| `test_authorized_no_alert` | AlertEngine returns None for authorized plate |
| `test_alert_provenance_simulated` | `alert.provenance == "SIMULATED"` |
| `test_latency_computed` | `alert_latency_ms >= 0` |
| `test_no_network_call` | Assert no socket opened (mock socket at module level) |
| `test_alert_filter_by_status` | Filter returns only matching status |
| `test_alert_filter_by_plate` | Partial plate match works |
| `test_csv_export_headers` | CSV headers match `outputs/alerts.csv` schema |

**Done when:** All tests pass.

---

## Group M3-C — Overview API

### M3-TASK-07 · Overview API endpoints `[BE]`

**Req IDs:** REQ-M3-19 – REQ-M3-25

Implement `backend/app/api/v1/overview.py`:

- `GET /overview/kpis` — aggregate across all repositories:
  - `vehicles_tracked` = sum of `total_tracks` across `detection_runs` where status=completed
  - `plates_validated` = count of `anpr_runs` + `validation_sim_runs`
  - `authorized_count`, `watchlist_hits`, `unknown_count` = from `alerts` + `anpr_runs`
  - `total_alerts` = count of `alerts`
  - `avg_ocr_confidence` = avg `confidence` from `anpr_runs`
  - `avg_processing_latency_ms` = avg `processing_time_ms` from `anpr_runs`
  - All values tagged `MEASURED`; fall back to `DemoDataProvider.overview_kpis()` tagged `DEMO` when all counts are zero
- `GET /overview/pipeline-status` — 9 stages; derive `active`/`idle`/`error` from most recent run timestamps and job states
- `GET /overview/recent-alerts` — last 10 alerts from `AlertRepository`
- `GET /overview/charts` — status donut counts + alert timeline bins

**Done when:** All 4 endpoints return valid JSON; KPIs show `MEASURED` when real data exists; `DEMO` when database is empty.

---

### M3-TASK-08 · Wire Detection totals to Overview `[BE]`

**Req IDs:** REQ-M3-24

The `overview/kpis` endpoint's `vehicles_tracked` reads from `detection_runs`. Verify this aggregation is correct after at least one detection run completes.

**Acceptance test:**
```bash
# After a completed detection run:
curl -s http://localhost:8000/api/v1/overview/kpis | python -c "
import sys,json; d=json.load(sys.stdin)
vt = d['vehicles_tracked']
assert vt['value'] >= 0
assert vt['provenance'] in ('MEASURED','DEMO')
print('vehicles_tracked:', vt['value'], vt['provenance'])
"
```

**Done when:** `vehicles_tracked.value` reflects real run total when runs exist.

---

## Group M3-D — Frontend: Watchlist, Alerts, Overview

### M3-TASK-09 · Watchlist page `[FE]`

**Req IDs:** REQ-M3-01 – REQ-M3-08

Assemble `frontend/src/pages/Watchlist.tsx`:

1. Search input + status filter → `useWatchlist(page, q, status)`
2. `VehicleTable`: sortable columns (plate, status, description, updated_at); inline Edit (opens modal) and Delete (confirms first) buttons
3. `AddVehicleForm` modal: plate input with live regex validation; status select; description textarea; submit → `useAddVehicle()` mutation; invalidates watchlist query
4. `CsvImportButton`: file picker → `POST /watchlist/import`; on complete, toast with "Imported N, Skipped M" + skipped details in modal if M > 0
5. `CsvExportButton`: `GET /watchlist/export` → triggers download

**Done when:** Full CRUD cycle works; invalid plate shows inline error before submit; CSV import/export functional.

---

### M3-TASK-10 · `SimulatedAlertBanner` + Alerts page `[FE]`

**Req IDs:** REQ-M3-12, REQ-M3-14 – REQ-M3-18

**`SimulatedAlertBanner`** (`src/components/shared/SimulatedAlertBanner.tsx`):
- Always visible on Alerts page (not context-driven like `PlaceholderBanner`)
- Text: "⚠ All alerts in this system are SIMULATED. No real SMS notifications are sent."
- Distinct styling from `PlaceholderBanner` (e.g. amber background vs orange)

Assemble `frontend/src/pages/Alerts.tsx`:

1. `SimulatedAlertBanner` at top (always rendered)
2. `AlertFilters`: status dropdown, date-range pickers, plate search input → debounced → `useAlerts(filters)`
3. `AlertFeedTable`: paginated; columns: timestamp, plate `StatusBadge`, track ID, message, latency, Evidence button (disabled + tooltip if no evidence)
4. Evidence button → opens modal with JPEG from `GET /alerts/{id}/evidence`
5. `AlertTimelineChart`: `ChartCard(AreaChart)` tagged `MEASURED`
6. `AlertStatusDonut`: `ChartCard(PieChart)` tagged `MEASURED`
7. CSV export button

**Done when:** Filters work; evidence modal opens; SimulatedAlertBanner always visible; charts render.

---

### M3-TASK-11 · Overview page `[FE]`

**Req IDs:** REQ-M3-19 – REQ-M3-25

Assemble `frontend/src/pages/Overview.tsx`:

1. `KpiGrid`: 8 × `KpiCard`; each receives `provenance` from API (`MEASURED` or `DEMO`); skeleton loaders while fetching
2. `PipelineDiagram` (`src/components/overview/PipelineDiagram.tsx`): SVG/CSS horizontal flow of 9 named stages; stage colour = `active` (accent cyan) / `idle` (muted) / `error` (watchlist red)
3. `RecentAlertsTable`: last 10 alerts; link "View all alerts →" navigates to `/alerts`
4. `StatusDonut`: `ChartCard(PieChart)` — authorized (green) / watchlist (red) / unknown (amber) from `useOverviewCharts()`
5. All charts fall back to `DEMO` data when no real runs exist; `DEMO` provenance badge shown

**Done when:** Page renders in both demo and real mode; pipeline diagram shows 9 stages with correct colours; KPI cards show provenance badges.

---

### M3-TASK-12 · Vitest tests for M3 frontend components `[FE]`

**Req IDs:** REQ-G-12

Write `frontend/src/__tests__/m3/`:

| File | Tests |
|------|-------|
| `SimulatedAlertBanner.test.tsx` | Always renders; text contains "SIMULATED" |
| `VehicleTable.test.tsx` | Edit button opens modal; Delete shows confirmation |
| `AlertFeedTable.test.tsx` | StatusBadge colours correct; Evidence button disabled when no evidence |
| `PipelineDiagram.test.tsx` | Renders 9 stage labels; active stage has correct class |
| `KpiGrid.test.tsx` | 8 KpiCards rendered; DEMO badge present in demo mode |

**Done when:** `npx vitest --run src/__tests__/m3/` all pass.

---

## M3 SMOKE TEST — TASK-M3-ST

**Req IDs:** REQ-M3-ST-01

**Steps:**
1. Navigate to Watchlist → 3 seeded plates visible.
2. Add plate `DL05CQ1234` with status `watchlist` → appears in table.
3. Navigate to ANPR Lab → upload image of any watchlist plate (or use `TN03EF9012` in demo mode) → run OCR.
4. If confidence ≥ 0.70 and plate is watchlist: navigate to Alerts → new alert row with `SIMULATED` banner present.
5. Navigate to Overview → watchlist KPI count ≥ 1; `MEASURED` badge on KPIs.
6. Pipeline diagram shows all 9 stages; latest run stage is `active` or `idle`.
7. Recent alerts table shows the triggered alert; "View all alerts →" navigates to Alerts page.
8. Edit `DL05CQ1234` → change description → save → confirm change in table.
9. Delete `DL05CQ1234` → confirm dialog → row removed.

**Done when:** All 9 steps pass without error.

---

# Full End-to-End Smoke Tests

## E2E SMOKE TEST A — Demo Mode

**Req IDs:** REQ-E2E-01

**Precondition:** `DEMO_MODE=true` in `.env`; `npm run dev`

| # | Check | Pass |
|---|-------|------|
| 1 | All 8 sidebar pages render | No blank/error screens |
| 2 | Overview: 8 KPI cards with `DEMO` badges | All cards visible |
| 3 | ANPR Lab: demo image pre-loaded, OCR candidates table shown | `DEMO` badge visible |
| 4 | Validation Simulator: comparison chart renders | `SIMULATED` badge present |
| 5 | Detection: demo run in history; FrameViewer opens | `DEMO` badge in run history |
| 6 | Dataset Explorer: stats cards show demo values | No crash |
| 7 | Watchlist: 3 seeded vehicles visible | Correct statuses |
| 8 | Alerts: demo alerts in feed; `SIMULATED` banner present | Always visible |
| 9 | `GET /api/v1/health` | `demo_mode: true` in response |
| 10 | `GET /api/v1/overview/kpis` | All KPIs have `provenance: "DEMO"` |

**Done when:** All 10 checks pass.

---

## E2E SMOKE TEST B — Real-Data Mode

**Req IDs:** REQ-E2E-02

**Precondition:** `DEMO_MODE=false` in `.env`; `npm run dev`

| # | Step | Pass |
|---|------|------|
| 1 | ANPR Lab: upload a real plate JPEG → OCR result returned | Result has `provenance: "MEASURED"` |
| 2 | Validation Simulator: run defaults (window=7, error=0.20, tracks=5) | CSV export downloads |
| 3 | Detection: select first UA-DETRAC sequence → run 20 frames | Run appears in history |
| 4 | Dataset Explorer: UA-DETRAC stats show correct sequence count | Count > 0 |
| 5 | Watchlist: all 3 seeded plates present | Correct status values |
| 6 | Alerts: watchlist plate from step 1 or 2 triggered alert | Alert row in feed |
| 7 | Overview KPIs: `vehicles_tracked` reflects step 3 run | `MEASURED` badge |
| 8 | Overview: pipeline diagram shows most recent run stage as `active`/`idle` | No `error` stages (unless model not loaded) |
| 9 | `pytest backend/tests/ -v` | All tests PASSED |
| 10 | `cd frontend && npx vitest --run` | All tests PASSED |

**Done when:** All 10 checks pass.

---

## Task Summary Table

### Milestone 1

| Task | Group | Type | Key Req IDs |
|------|-------|------|-------------|
| M1-TASK-01 | DB Foundation | BE | REQ-M3-27, REQ-G-08 |
| M1-TASK-02 | DB Foundation | BE | REQ-M3-05, REQ-M3-06 |
| M1-TASK-03 | OcrPipeline | BE | REQ-M1-04 – M1-10 |
| M1-TASK-04 | AnprRepository | BE | REQ-M1-20, M1-21 |
| M1-TASK-05 | Job Manager | BE | REQ-G-06, M1-11, M2-03 |
| M1-TASK-06 | ANPR API | BE | REQ-M1-01, M1-11, M1-21, G-09 |
| M1-TASK-07 | pytest ANPR | BE | REQ-G-12 |
| M1-TASK-08 | SimulationRepo | BE | REQ-M1-29, M1-30 |
| M1-TASK-09 | MonteCarlo extend | BE | REQ-M1-23, M1-27 |
| M1-TASK-10 | Validation API | BE | REQ-M1-22, M1-28, M1-30 |
| M1-TASK-11 | pytest Validation | BE | REQ-G-12 |
| M1-TASK-12 | CropBox | FE | REQ-M1-02 |
| M1-TASK-13 | OcrProgress, Grid, Gauge | FE | REQ-M1-12 – M1-14, M1-19 |
| M1-TASK-14 | Table, Structure, Correction | FE | REQ-M1-13, M1-15, M1-16 |
| M1-TASK-15 | ANPR Lab page | FE | REQ-M1-01 – M1-21 |
| M1-TASK-16 | Sim controls + chart | FE | REQ-M1-22 – M1-27 |
| M1-TASK-17 | Validation Sim page | FE | REQ-M1-22 – M1-30 |
| M1-TASK-18 | Vitest M1 | FE | REQ-G-12 |
| M1-ST | M1 Smoke Test | BOTH | REQ-M1-ST-01 |

### Milestone 2

| Task | Group | Type | Key Req IDs |
|------|-------|------|-------------|
| M2-TASK-01 | DatasetService | BE | REQ-M2-01, M2-15 – M2-19, G-10 |
| M2-TASK-02 | Dataset API | BE | REQ-M2-20 |
| M2-TASK-03 | pytest Datasets | BE | REQ-G-12 |
| M2-TASK-04 | DetectionService | BE | REQ-M2-03 – M2-08, G-04, G-05 |
| M2-TASK-05 | DetectionRepo + frames | BE | REQ-M2-08, M2-09, M2-13, M2-14 |
| M2-TASK-06 | Detection API | BE | REQ-M2-03 – M2-09, M2-20 |
| M2-TASK-07 | pytest Detection | BE | REQ-G-12 |
| M2-TASK-08 | FrameViewer, JobProgress | FE | REQ-M2-10 |
| M2-TASK-09 | Detection page | FE | REQ-M2-01 – M2-14 |
| M2-TASK-10 | Dataset Explorer page | FE | REQ-M2-15 – M2-19 |
| M2-TASK-11 | Vitest M2 | FE | REQ-G-12 |
| M2-ST | M2 Smoke Test | BOTH | REQ-M2-ST-01 |

### Milestone 3

| Task | Group | Type | Key Req IDs |
|------|-------|------|-------------|
| M3-TASK-01 | Watchlist API | BE | REQ-M3-01 – M3-08 |
| M3-TASK-02 | pytest Watchlist | BE | REQ-G-12 |
| M3-TASK-03 | AlertEngine + AlertRepo | BE | REQ-M3-09 – M3-11, M3-13 |
| M3-TASK-04 | Alerts API | BE | REQ-M3-14, M3-15, M3-18 |
| M3-TASK-05 | Wire alerts to ANPR/Sim | BE | REQ-M3-23 |
| M3-TASK-06 | pytest Alerts | BE | REQ-G-12 |
| M3-TASK-07 | Overview API | BE | REQ-M3-19 – M3-25 |
| M3-TASK-08 | Wire detection to Overview | BE | REQ-M3-24 |
| M3-TASK-09 | Watchlist page | FE | REQ-M3-01 – M3-08 |
| M3-TASK-10 | SimulatedAlertBanner + Alerts page | FE | REQ-M3-12, M3-14 – M3-18 |
| M3-TASK-11 | Overview page | FE | REQ-M3-19 – M3-25 |
| M3-TASK-12 | Vitest M3 | FE | REQ-G-12 |
| M3-ST | M3 Smoke Test | BOTH | REQ-M3-ST-01 |
| E2E-A | Demo-mode E2E | BOTH | REQ-E2E-01 |
| E2E-B | Real-data E2E | BOTH | REQ-E2E-02 |
