# Design — Phases 2, 3 & 4 (Combined)
## Deep Learning-Based Intelligent Vehicle Surveillance System

**Phase:** 2 (ANPR Lab + Validation Simulator) · 3 (Detection & Tracking + Dataset Explorer) · 4 (Watchlist & Alerts + Overview)
**Version:** 1.0
**Date:** 2026-10-25
**Requirements:** `requirements-p2p3p4.md`
**Builds on:** Phase 1 `design.md`

---

## 1. Updated System Architecture

### 1.1 Mermaid Architecture Diagram

```mermaid
graph TB
    subgraph Browser["Browser — React 18 + Vite (Port 5173)"]
        Router["React Router v6"]
        Shell["ShellLayout\nSidebar + TopBar"]
        TQ["TanStack Query v5"]

        subgraph Pages["Pages"]
            P1["Overview"]
            P2["ANPR Lab"]
            P3["Validation Simulator"]
            P4["Detection & Tracking"]
            P5["Dataset Explorer"]
            P6["Watchlist"]
            P7["Alerts"]
            P8["Evaluation (Ph 5)"]
        end

        subgraph Shared["Shared Components"]
            PB["ProvenanceBadge"]
            PLB["PlaceholderBanner"]
            SB["StatusBadge"]
            KC["KpiCard"]
            CC["ChartCard"]
            ES["EmptyState"]
            CropBox["CropBox"]
            FrameViewer["FrameViewer"]
            PipelineDiagram["PipelineDiagram"]
        end
    end

    subgraph Backend["Backend — FastAPI + Uvicorn (Port 8000)"]
        Factory["create_app() + Lifespan"]
        Middleware["CORS · Request-ID"]

        subgraph APIv1["Router /api/v1"]
            ANPRA["anpr.*"]
            ValA["validation.*"]
            DetA["detection.*"]
            DsA["datasets.*"]
            WlA["watchlist.*"]
            AlA["alerts.*"]
            OvA["overview.*"]
        end

        subgraph Services["Services"]
            OCRPipe["OcrPipeline\nCLAHE·Sharpen·Otsu·Adaptive\n3×5×7× upscale + EasyOCR"]
            PV["PlateValidator\ndeque window"]
            IPP["IndianPlateParser\nregex + char correction"]
            PC["PlateClassifier\nauthor·watch·unrec"]
            MC["MonteCarloSimulator\nseeded NumPy"]
            YB["DetectionService\nYOLO11n + ByteTrack"]
            AE["AlertEngine\nSimulated SMS log"]
            DD["DemoDataProvider"]
        end

        subgraph JobMgr["Job Manager"]
            JQ["In-process job queue\nasyncio.Queue / ThreadPoolExecutor"]
            SSE["SSE EventSource\n/stream/{job_id}"]
        end

        subgraph Repo["Repository Layer"]
            VehicleRepo["VehicleRepository"]
            AnprRepo["AnprRepository"]
            SimRepo["SimulationRepository"]
            DetRepo["DetectionRepository"]
            AlertRepo["AlertRepository"]
        end

        DB[("SQLite\nsurveillance.db")]
        Core["config.py · logging.py"]
    end

    subgraph DataLayer["Data (read-only)"]
        DS["datasets/ua_detrac · indian_plates"]
        OP["outputs/alerts.csv · evidence/ · photo_anpr_result.csv"]
    end

    Browser -->|HTTP + SSE| APIv1
    TQ -->|queries + mutations| APIv1
    APIv1 --> Services
    APIv1 --> JobMgr
    Services --> Repo
    JobMgr --> Services
    JobMgr --> SSE
    Repo --> DB
    Services --> DataLayer
    Core --> Services
```

### 1.2 Layer Summary

| Layer | Responsibility |
|-------|---------------|
| Pages | Route-level components; compose shared components + hooks |
| Shared Components | Reusable, stateless UI atoms (badges, cards, charts, viewers) |
| TanStack Query hooks | Data fetching, mutation, SSE subscription per feature |
| FastAPI routers | Thin: validate input → call service → return response model |
| Services | Business logic (OCR pipeline, detection, alert engine, validator) |
| Job Manager | Background task lifecycle: create, track, cancel, stream progress |
| Repository | SQLite CRUD; one class per domain entity |
| Data Layer | Read-only filesystem access (datasets + outputs) |

---

## 2. Job / SSE Flow — Sequence Diagram

This diagram applies to both the OCR pipeline (M1) and the Detection job (M2).

```mermaid
sequenceDiagram
    participant UI as Browser (React)
    participant API as FastAPI Router
    participant JM as Job Manager
    participant SVC as Service (OcrPipeline / DetectionService)
    participant DB as SQLite

    UI->>API: POST /api/v1/anpr/upload  (multipart)
    API->>API: Validate MIME + size
    API->>JM: create_job(payload)
    JM-->>API: job_id (UUID)
    API-->>UI: 202 Accepted { job_id }

    UI->>API: GET /api/v1/anpr/stream/{job_id}  (SSE)
    API-->>UI: event: status=queued

    JM->>SVC: run(payload)  [background thread/task]
    loop per preprocessing variant
        SVC-->>JM: progress { variant, upscale, pct }
        JM-->>UI: SSE event: { type:progress, pct, variant }
    end

    SVC-->>JM: result (OcrRunResult)
    JM->>DB: persist anpr_run
    JM-->>UI: SSE event: { type:done, result }

    UI->>API: GET /api/v1/anpr/job/{job_id}
    API-->>UI: 200 { status:completed, result:{...} }
```

**Cancel flow (Detection only):**
```mermaid
sequenceDiagram
    participant UI as Browser
    participant API as FastAPI
    participant JM as Job Manager

    UI->>API: DELETE /api/v1/detection/job/{job_id}
    API->>JM: cancel(job_id)
    JM->>JM: set cancel_event
    JM-->>UI: SSE event: { type:cancelled }
    API-->>UI: 200 { status: cancelled }
```

---

## 3. Full API Endpoint Table (Phases 2–4)

### 3.1 ANPR Lab (M1)

| Method | Path | Request | Response | Req ID |
|--------|------|---------|---------|--------|
| POST | `/api/v1/anpr/upload` | `multipart/form-data`: `file`, `crop_x`, `crop_y`, `crop_w`, `crop_h`, `denoise?` | `{ job_id }` | REQ-M1-11 |
| GET | `/api/v1/anpr/job/{job_id}` | — | `OcrJobStatus` | REQ-M1-11 |
| GET | `/api/v1/anpr/stream/{job_id}` | — | SSE stream | REQ-M1-11 |
| GET | `/api/v1/anpr/history` | `?page&page_size` | `Page[AnprRunSummary]` | REQ-M1-21 |

### 3.2 Validation Simulator (M1)

| Method | Path | Request | Response | Req ID |
|--------|------|---------|---------|--------|
| POST | `/api/v1/validation/run` | `SimulationRequest` | `SimulationResult` | REQ-M1-23 |
| GET | `/api/v1/validation/history` | `?page&page_size` | `Page[SimRunSummary]` | REQ-M1-30 |
| GET | `/api/v1/validation/export/{run_id}` | — | `text/csv` | REQ-M1-28 |

### 3.3 Dataset Explorer (M2)

| Method | Path | Request | Response | Req ID |
|--------|------|---------|---------|--------|
| GET | `/api/v1/datasets/ua-detrac/stats` | — | `DatasetStats` | REQ-M2-15 |
| GET | `/api/v1/datasets/ua-detrac/sequences` | — | `list[SequenceInfo]` | REQ-M2-01 |
| GET | `/api/v1/datasets/ua-detrac/gallery` | `?page&page_size&sequence?` | `Page[FrameThumb]` | REQ-M2-17 |
| GET | `/api/v1/datasets/indian-plates/stats` | — | `DatasetStats` | REQ-M2-16 |
| GET | `/api/v1/datasets/indian-plates/gallery` | `?page&page_size` | `Page[PlateThumb]` | REQ-M2-17 |
| GET | `/api/v1/datasets/{dataset}/thumbnail/{path}` | `?size=sm\|md` | `image/jpeg` | REQ-M2-17 |

### 3.4 Detection & Tracking (M2)

| Method | Path | Request | Response | Req ID |
|--------|------|---------|---------|--------|
| POST | `/api/v1/detection/start` | `DetectionRequest` | `{ job_id }` | REQ-M2-03 |
| GET | `/api/v1/detection/job/{job_id}` | — | `DetectionJobStatus` | REQ-M2-05 |
| GET | `/api/v1/detection/stream/{job_id}` | — | SSE stream | REQ-M2-05 |
| DELETE | `/api/v1/detection/job/{job_id}` | — | `{ status: cancelled }` | REQ-M2-06 |
| GET | `/api/v1/detection/runs` | `?page&page_size` | `Page[RunSummary]` | REQ-M2-13 |
| GET | `/api/v1/detection/run/{run_id}` | — | `DetectionRunDetail` | REQ-M2-14 |
| GET | `/api/v1/detection/run/{run_id}/frame/{idx}` | `?full=bool` | `image/jpeg` | REQ-M2-09 |
| GET | `/api/v1/detection/run/{run_id}/tracks` | `?page&page_size` | `Page[TrackRow]` | REQ-M2-08 |
| GET | `/api/v1/detection/run/{run_id}/charts` | — | `DetectionCharts` | REQ-M2-12 |

### 3.5 Watchlist (M3)

| Method | Path | Request | Response | Req ID |
|--------|------|---------|---------|--------|
| GET | `/api/v1/watchlist` | `?page&q&status` | `Page[VehicleRecord]` | REQ-M3-01 |
| POST | `/api/v1/watchlist` | `VehicleCreate` | `VehicleRecord` | REQ-M3-02 |
| PUT | `/api/v1/watchlist/{plate}` | `VehicleUpdate` | `VehicleRecord` | REQ-M3-03 |
| DELETE | `/api/v1/watchlist/{plate}` | — | `204` | REQ-M3-04 |
| POST | `/api/v1/watchlist/import` | `multipart/form-data`: `file` | `ImportSummary` | REQ-M3-07 |
| GET | `/api/v1/watchlist/export` | — | `text/csv` | REQ-M3-08 |

### 3.6 Alerts (M3)

| Method | Path | Request | Response | Req ID |
|--------|------|---------|---------|--------|
| GET | `/api/v1/alerts` | `?page&status&from_dt&to_dt&plate` | `Page[AlertRecord]` | REQ-M3-14 |
| GET | `/api/v1/alerts/export` | same filters | `text/csv` | REQ-M3-18 |
| GET | `/api/v1/alerts/{alert_id}` | — | `AlertRecord` | REQ-M3-15 |
| GET | `/api/v1/alerts/{alert_id}/evidence` | — | `image/jpeg` | REQ-M3-15 |

### 3.7 Overview (M3)

| Method | Path | Request | Response | Req ID |
|--------|------|---------|---------|--------|
| GET | `/api/v1/overview/kpis` | — | `OverviewKpis` | REQ-M3-19 |
| GET | `/api/v1/overview/pipeline-status` | — | `PipelineStatus` | REQ-M3-20 |
| GET | `/api/v1/overview/recent-alerts` | — | `list[AlertRecord]` | REQ-M3-21 |
| GET | `/api/v1/overview/charts` | — | `OverviewCharts` | REQ-M3-22 |

---

## 4. Pydantic Response Models

### 4.1 Common

```python
class ProvenanceEnum(str, Enum):
    MEASURED    = "MEASURED"
    SIMULATED   = "SIMULATED"
    PLACEHOLDER = "PLACEHOLDER"
    DEMO        = "DEMO"

class Page(BaseModel, Generic[T]):
    items: list[T]
    total: int
    page: int
    page_size: int
    pages: int
```

### 4.2 ANPR (M1)

```python
class OcrVariantResult(BaseModel):
    variant: str             # "clahe_3x", "otsu_5x", etc.
    upscale_factor: int
    raw_text: str
    cleaned_text: str
    confidence: float
    regex_match: bool

class CharCorrection(BaseModel):
    before: str
    after: str
    positions_corrected: list[int]

class OcrRunResult(ProvenanceMixin):
    run_id: str
    timestamp: datetime
    best_plate: Optional[str]
    best_confidence: float
    low_confidence: bool      # True if < 0.70
    correction: CharCorrection
    plate_parse: Optional[ParseResult]
    db_status: Optional[Literal["authorized","watchlist","unauthorized_unrecognized"]]
    variants: list[OcrVariantResult]
    processing_time_ms: float
    provenance: ProvenanceEnum  # always MEASURED (or DEMO in demo mode)

class OcrJobStatus(BaseModel):
    job_id: str
    status: Literal["queued","running","completed","error"]
    progress_pct: float
    result: Optional[OcrRunResult]
    error: Optional[str]

class AnprRunSummary(BaseModel):
    run_id: str
    timestamp: datetime
    best_plate: Optional[str]
    confidence: float
    validation_status: str
    db_status: str
    processing_time_ms: float
```

### 4.3 Validation Simulator (M1)

```python
class SimulationRequest(BaseModel):
    window_size: int = Field(7, ge=3, le=15)
    min_conf: float = Field(0.70, ge=0.50, le=0.95)
    error_probability: float = Field(0.20, ge=0.05, le=0.50)
    n_tracks: int = Field(5, ge=1, le=20)
    seed: int = 42

class FrameVote(BaseModel):
    frame_idx: int
    raw_plate: str
    confidence: float
    accepted: bool       # False if below min_conf
    vote_counts: dict[str, int]
    current_winner: Optional[str]

class TrackResult(BaseModel):
    track_id: int
    validated_plate: Optional[str]
    vote_count: int
    window_size: int
    db_status: str
    frames: list[FrameVote]

class ComparisonPoint(BaseModel):
    n_frames: int
    single_frame_error: float
    multi_frame_error: float
    ci_lower: float
    ci_upper: float

class SimulationResult(ProvenanceMixin):
    run_id: str
    timestamp: datetime
    params: SimulationRequest
    tracks: list[TrackResult]
    comparison_curve: list[ComparisonPoint]
    single_frame_error_rate: float
    multi_frame_error_rate: float
    improvement_factor: float
    provenance: ProvenanceEnum = ProvenanceEnum.SIMULATED
```

### 4.4 Detection & Tracking (M2)

```python
class DetectionRequest(BaseModel):
    sequence_name: str
    confidence_threshold: float = Field(0.5, ge=0.1, le=0.9)
    max_frames: int = Field(100, ge=10, le=500)
    seed: int = 42

class DetectionJobStatus(BaseModel):
    job_id: str
    status: Literal["queued","running","completed","cancelled","error"]
    frames_processed: int
    total_frames: int
    run_id: Optional[str]
    error: Optional[str]

class TrackRow(BaseModel):
    frame: int
    track_id: int
    vehicle_type: str
    confidence: float
    x1: float; y1: float; x2: float; y2: float

class RunSummary(BaseModel):
    run_id: str
    sequence_name: str
    timestamp: datetime
    frame_count: int
    total_tracks: int
    fps: float
    status: str

class DetectionRunDetail(RunSummary):
    config_json: str
    model_version: str
    seed: int

class ClassDistPoint(BaseModel):
    vehicle_type: str
    count: int

class DetectionCharts(ProvenanceMixin):
    class_distribution: list[ClassDistPoint]
    vehicles_per_frame: list[dict]   # [{frame, count}]
    track_length_histogram: list[dict]  # [{length, count}]
    provenance: ProvenanceEnum = ProvenanceEnum.MEASURED
```

### 4.5 Dataset Explorer (M2)

```python
class DatasetStats(ProvenanceMixin):
    dataset: str
    sequence_count: Optional[int]
    total_frames: int
    resolution: Optional[str]   # "WxH"
    total_images: Optional[int]

class SequenceInfo(BaseModel):
    name: str
    frame_count: int
    path: str

class FrameThumb(BaseModel):
    sequence: str
    frame_idx: int
    thumbnail_url: str

class PlateThumb(BaseModel):
    filename: str
    thumbnail_url: str
```

### 4.6 Watchlist (M3)

```python
class VehicleCreate(BaseModel):
    plate: str          # validated by IndianPlateParser
    status: Literal["authorized","watchlist"]
    description: str = ""

class VehicleUpdate(BaseModel):
    status: Optional[Literal["authorized","watchlist"]]
    description: Optional[str]

class VehicleRecord(VehicleCreate):
    created_at: datetime
    updated_at: datetime

class ImportSummary(BaseModel):
    rows_imported: int
    rows_skipped: int
    skipped_reasons: list[dict]   # [{row, reason}]
```

### 4.7 Alerts (M3)

```python
class AlertRecord(ProvenanceMixin):
    alert_id: str
    timestamp: datetime
    plate: str
    track_id: Optional[int]
    status: Literal["watchlist","unauthorized_unrecognized"]
    message: str
    evidence_image_path: Optional[str]
    alert_latency_ms: float
    provenance: ProvenanceEnum = ProvenanceEnum.SIMULATED
    has_evidence: bool
```

### 4.8 Overview (M3)

```python
class KpiValue(ProvenanceMixin):
    label: str
    value: float
    unit: Optional[str]
    delta: Optional[float]

class OverviewKpis(BaseModel):
    vehicles_tracked: KpiValue
    plates_validated: KpiValue
    authorized_count: KpiValue
    watchlist_hits: KpiValue
    unknown_count: KpiValue
    total_alerts: KpiValue
    avg_ocr_confidence: KpiValue
    avg_processing_latency_ms: KpiValue

class PipelineStage(BaseModel):
    name: str
    status: Literal["active","idle","error"]
    last_run: Optional[datetime]

class PipelineStatus(BaseModel):
    stages: list[PipelineStage]   # 9 stages in order

class OverviewCharts(BaseModel):
    status_donut: list[dict]      # [{label, value, colour}]
    alert_timeline: list[dict]    # [{bin_label, count}]
```

---

## 5. TypeScript Frontend Models

```typescript
// src/lib/types.ts

export type Provenance = "MEASURED" | "SIMULATED" | "PLACEHOLDER" | "DEMO";

// ── ANPR ──────────────────────────────────────────────────
export interface OcrVariantResult {
  variant: string;
  upscale_factor: number;
  raw_text: string;
  cleaned_text: string;
  confidence: number;
  regex_match: boolean;
}

export interface CharCorrection {
  before: string;
  after: string;
  positions_corrected: number[];
}

export interface OcrRunResult {
  run_id: string;
  timestamp: string;
  best_plate: string | null;
  best_confidence: number;
  low_confidence: boolean;
  correction: CharCorrection;
  plate_parse: ParseResult | null;
  db_status: VehicleStatus | null;
  variants: OcrVariantResult[];
  processing_time_ms: number;
  provenance: Provenance;
}

export interface OcrJobStatus {
  job_id: string;
  status: "queued" | "running" | "completed" | "error";
  progress_pct: number;
  result: OcrRunResult | null;
  error: string | null;
}

// ── Validation Simulator ───────────────────────────────────
export interface FrameVote {
  frame_idx: number;
  raw_plate: string;
  confidence: number;
  accepted: boolean;
  vote_counts: Record<string, number>;
  current_winner: string | null;
}

export interface TrackResult {
  track_id: number;
  validated_plate: string | null;
  vote_count: number;
  window_size: number;
  db_status: string;
  frames: FrameVote[];
}

export interface ComparisonPoint {
  n_frames: number;
  single_frame_error: number;
  multi_frame_error: number;
  ci_lower: number;
  ci_upper: number;
}

export interface SimulationResult {
  run_id: string;
  tracks: TrackResult[];
  comparison_curve: ComparisonPoint[];
  single_frame_error_rate: number;
  multi_frame_error_rate: number;
  improvement_factor: number;
  provenance: Provenance;
}

// ── Detection ─────────────────────────────────────────────
export interface DetectionJobStatus {
  job_id: string;
  status: "queued" | "running" | "completed" | "cancelled" | "error";
  frames_processed: number;
  total_frames: number;
  run_id: string | null;
  error: string | null;
}

export interface RunSummary {
  run_id: string;
  sequence_name: string;
  timestamp: string;
  frame_count: number;
  total_tracks: number;
  fps: number;
  status: string;
}

export interface DetectionCharts {
  class_distribution: { vehicle_type: string; count: number }[];
  vehicles_per_frame: { frame: number; count: number }[];
  track_length_histogram: { length: number; count: number }[];
  provenance: Provenance;
}

// ── Watchlist ─────────────────────────────────────────────
export type VehicleStatus = "authorized" | "watchlist";

export interface VehicleRecord {
  plate: string;
  status: VehicleStatus;
  description: string;
  created_at: string;
  updated_at: string;
}

// ── Alerts ────────────────────────────────────────────────
export type AlertStatus = "watchlist" | "unauthorized_unrecognized";

export interface AlertRecord {
  alert_id: string;
  timestamp: string;
  plate: string;
  track_id: number | null;
  status: AlertStatus;
  message: string;
  evidence_image_path: string | null;
  alert_latency_ms: number;
  provenance: Provenance;
  has_evidence: boolean;
}

// ── Overview ──────────────────────────────────────────────
export interface KpiValue {
  label: string;
  value: number;
  unit: string | null;
  delta: number | null;
  provenance: Provenance;
}

export interface OverviewKpis {
  vehicles_tracked: KpiValue;
  plates_validated: KpiValue;
  authorized_count: KpiValue;
  watchlist_hits: KpiValue;
  unknown_count: KpiValue;
  total_alerts: KpiValue;
  avg_ocr_confidence: KpiValue;
  avg_processing_latency_ms: KpiValue;
}

export interface PipelineStage {
  name: string;
  status: "active" | "idle" | "error";
  last_run: string | null;
}

// ── Shared ────────────────────────────────────────────────
export interface Page<T> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
  pages: number;
}
```

---

## 6. Database Schema (SQLite via SQLModel)

```sql
-- vehicles
CREATE TABLE vehicles (
    plate       TEXT PRIMARY KEY,
    status      TEXT NOT NULL CHECK(status IN ('authorized','watchlist')),
    description TEXT NOT NULL DEFAULT '',
    created_at  DATETIME NOT NULL,
    updated_at  DATETIME NOT NULL
);

-- anpr_runs
CREATE TABLE anpr_runs (
    run_id              TEXT PRIMARY KEY,
    timestamp           DATETIME NOT NULL,
    image_filename      TEXT,
    best_plate          TEXT,
    confidence          REAL,
    variant_used        TEXT,
    correction_applied  INTEGER NOT NULL DEFAULT 0,
    validation_status   TEXT,
    db_status           TEXT,
    processing_time_ms  REAL,
    provenance          TEXT NOT NULL DEFAULT 'MEASURED'
);

-- validation_sim_runs
CREATE TABLE validation_sim_runs (
    run_id                  TEXT PRIMARY KEY,
    timestamp               DATETIME NOT NULL,
    seed                    INTEGER,
    window_size             INTEGER,
    min_conf                REAL,
    error_prob              REAL,
    n_tracks                INTEGER,
    results_json            TEXT,
    single_frame_error_rate REAL,
    multi_frame_error_rate  REAL,
    improvement_factor      REAL,
    provenance              TEXT NOT NULL DEFAULT 'SIMULATED'
);

-- detection_runs
CREATE TABLE detection_runs (
    run_id          TEXT PRIMARY KEY,
    sequence_name   TEXT NOT NULL,
    timestamp       DATETIME NOT NULL,
    frame_count     INTEGER,
    total_tracks    INTEGER,
    fps             REAL,
    status          TEXT NOT NULL DEFAULT 'completed',
    config_json     TEXT,
    model_version   TEXT,
    seed            INTEGER
);

-- detection_tracks
CREATE TABLE detection_tracks (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id       TEXT NOT NULL REFERENCES detection_runs(run_id) ON DELETE CASCADE,
    frame        INTEGER NOT NULL,
    track_id     INTEGER NOT NULL,
    vehicle_type TEXT NOT NULL,
    confidence   REAL NOT NULL,
    x1 REAL, y1 REAL, x2 REAL, y2 REAL
);
CREATE INDEX idx_tracks_run ON detection_tracks(run_id);
CREATE INDEX idx_tracks_frame ON detection_tracks(run_id, frame);

-- alerts
CREATE TABLE alerts (
    alert_id            TEXT PRIMARY KEY,
    timestamp           DATETIME NOT NULL,
    plate               TEXT NOT NULL,
    track_id            INTEGER,
    status              TEXT NOT NULL,
    message             TEXT NOT NULL DEFAULT '',
    evidence_image_path TEXT,
    alert_latency_ms    REAL NOT NULL DEFAULT 0.0,
    provenance          TEXT NOT NULL DEFAULT 'SIMULATED'
);
CREATE INDEX idx_alerts_ts   ON alerts(timestamp);
CREATE INDEX idx_alerts_plate ON alerts(plate);
CREATE INDEX idx_alerts_status ON alerts(status);
```

**Repository pattern:** Each table has a corresponding repository class in `backend/app/repositories/`:
- `VehicleRepository` — CRUD + seeding + import/export
- `AnprRepository` — insert run, paginate history
- `SimulationRepository` — insert run, paginate history
- `DetectionRepository` — insert run + tracks, serve frame, paginate
- `AlertRepository` — insert alert, filter/paginate, export

All repositories receive an `AsyncSession` (SQLModel async) injected via FastAPI dependency.

---

## 7. Component Hierarchy Additions (Phases 2–4)

```
ShellLayout
└── <Outlet>
    │
    ├── AnprLab
    │   ├── ImageUploader          ← drag-drop + file picker
    │   ├── CropBox                ← interactive crop region (react-image-crop or custom canvas)
    │   ├── OcrProgress            ← SSE progress bar + variant count
    │   ├── PreprocessingGrid      ← thumbnail grid (variant × upscale)
    │   ├── OcrCandidatesTable     ← all variants sortable by confidence
    │   ├── ConfidenceGauge        ← radial gauge chart (Recharts RadialBar)
    │   ├── PlateStructureBreakdown← state/RTO/series/number tiles
    │   ├── CharCorrectionDisplay  ← before/after with diff highlighting
    │   ├── StatusBadge            ← db classification
    │   └── AnprHistory            ← paginated past runs table
    │
    ├── ValidationSimulator
    │   ├── SimulatorControls      ← sliders + seed input + run button
    │   ├── FrameVoteTable         ← per-track frame-by-frame votes
    │   ├── TrackSummaryCards      ← per-track final result KpiCard
    │   ├── ComparisonChart        ← Recharts LineChart + CI shading
    │   └── SimHistory             ← paginated past simulation runs
    │
    ├── Detection
    │   ├── SequenceSelector       ← dropdown of MVI_xxxxx folders
    │   ├── DetectionConfig        ← confidence + max frames inputs
    │   ├── JobProgress            ← SSE live progress bar + frame counter
    │   ├── FrameViewer            ← scrubber + side-by-side original/annotated
    │   ├── DetectionCharts        ← ChartCard × 3 (class dist, veh/frame, track hist)
    │   └── RunHistory             ← past runs table + reopen
    │
    ├── DatasetExplorer
    │   ├── DatasetStatCards       ← KpiCard × 2 (UA-DETRAC, Indian plates)
    │   ├── DatasetGallery         ← paginated lazy-loaded thumbnail grid
    │   └── RandomSampleButton
    │
    ├── Watchlist
    │   ├── VehicleTable           ← searchable + sortable + edit/delete inline
    │   ├── AddVehicleForm         ← modal/drawer with plate validation
    │   ├── CsvImportButton        ← file picker + import summary toast
    │   └── CsvExportButton
    │
    ├── Alerts
    │   ├── SimulatedAlertBanner   ← persistent; always visible on this page
    │   ├── AlertFilters           ← status · date range · plate search
    │   ├── AlertFeedTable         ← paginated; evidence image modal
    │   ├── AlertTimelineChart     ← ChartCard (Recharts AreaChart)
    │   └── AlertStatusDonut       ← ChartCard (Recharts PieChart)
    │
    └── Overview
        ├── KpiGrid                ← 8 × KpiCard with provenance tags
        ├── PipelineDiagram        ← 9-stage SVG/CSS flow diagram
        ├── RecentAlertsTable      ← last 10 alerts + link to full feed
        └── StatusDonut            ← ChartCard (Recharts PieChart)
```

### New Shared Components

| Component | Props | Notes |
|-----------|-------|-------|
| `CropBox` | `src`, `onChange(crop)` | Wraps `react-image-crop`; no hardcoded region |
| `OcrProgress` | `jobId`, `onComplete(result)` | Opens SSE via `useAnprStream(jobId)` |
| `FrameViewer` | `runId`, `totalFrames` | Scrubber + lazy fetch; keyboard ←/→ |
| `JobProgress` | `jobId`, `type: "anpr"\|"detection"` | Generic SSE progress bar |
| `PipelineDiagram` | `stages: PipelineStage[]` | SVG flow with status colours |
| `ConfidenceGauge` | `value`, `threshold` | Recharts `RadialBarChart`; red below threshold |
| `SimulatedAlertBanner` | — | Always visible on Alerts page; distinct from `PlaceholderBanner` |

---

## 8. New TanStack Query Hooks

```typescript
// M1 — ANPR
useAnprUpload()          // mutation: POST /anpr/upload → job_id
useAnprJob(jobId)        // query: GET /anpr/job/{job_id} (enabled when jobId set)
useAnprStream(jobId)     // custom hook: EventSource → updates query cache
useAnprHistory(page)     // query: GET /anpr/history

// M1 — Validation
useValidationRun()       // mutation: POST /validation/run
useValidationHistory(page) // query: GET /validation/history

// M2 — Datasets
useUaDetracStats()
useUaDetracSequences()
useDatasetGallery(dataset, page)

// M2 — Detection
useDetectionStart()      // mutation: POST /detection/start
useDetectionJob(jobId)   // query: GET /detection/job/{job_id}
useDetectionStream(jobId)// custom hook: EventSource
useDetectionRuns(page)   // query: GET /detection/runs
useDetectionRun(runId)   // query: GET /detection/run/{run_id}
useDetectionCharts(runId)// query: GET /detection/run/{run_id}/charts

// M3 — Watchlist
useWatchlist(page, q, status)
useAddVehicle()          // mutation: POST /watchlist
useUpdateVehicle()       // mutation: PUT /watchlist/{plate}
useDeleteVehicle()       // mutation: DELETE /watchlist/{plate}

// M3 — Alerts
useAlerts(filters)
useAlert(alertId)

// M3 — Overview
useOverviewKpis()
usePipelineStatus()
useRecentAlerts()
useOverviewCharts()
```

All SSE hooks follow this pattern:
```typescript
function useAnprStream(jobId: string | null) {
  const queryClient = useQueryClient();
  useEffect(() => {
    if (!jobId) return;
    const es = new EventSource(`/api/v1/anpr/stream/${jobId}`);
    es.onmessage = (e) => {
      const data = JSON.parse(e.data);
      queryClient.setQueryData(["anpr-job", jobId], (old) => ({ ...old, ...data }));
      if (data.status === "completed" || data.status === "error") es.close();
    };
    return () => es.close();
  }, [jobId, queryClient]);
}
```

---

## 9. Backend Services Design

### 9.1 OcrPipeline (`backend/app/services/ocr_pipeline.py`)

```python
VARIANTS = ["clahe", "sharpen", "otsu", "adaptive"]
UPSCALES  = [3, 5, 7]

class OcrVariantResult(BaseModel): ...

class OcrPipeline:
    """
    Port of notebook multi-preprocessing OCR pipeline.
    EasyOCR reader injected at construction (loaded once at startup).
    """
    def __init__(self, reader: easyocr.Reader, config: Settings): ...

    def preprocess(self, img: np.ndarray, variant: str, upscale: int,
                   denoise: bool = False) -> np.ndarray: ...

    def run(self, img: np.ndarray, crop: CropRegion | None,
            denoise: bool = False) -> OcrRunResult:
        """
        Runs all VARIANTS × UPSCALES combinations.
        Selects best candidate by confidence + regex.
        Applies character correction.
        Returns OcrRunResult with provenance=MEASURED.
        """
        ...
```

**Character correction table** (digit positions per Indian plate format: pos 2–3 = digits, pos 4–6 = letters, pos 7–10 = digits):

| Position type | Substitutions |
|--------------|--------------|
| Digit position | O→0, I→1, S→5, B→8 |
| Letter position | 0→O, 1→I, 5→S, 8→B |

### 9.2 DetectionService (`backend/app/services/detection_service.py`)

```python
class DetectionService:
    """
    YOLO11n + ByteTrack runner.
    Model injected at startup; never reloaded.
    cancel_events: dict[job_id, asyncio.Event] for cancellation.
    """
    def __init__(self, model: YOLO, config: Settings): ...

    async def run_sequence(
        self,
        sequence_path: Path,
        confidence: float,
        max_frames: int,
        seed: int,
        progress_cb: Callable[[int, int, int], Awaitable[None]],
        cancel_event: asyncio.Event,
    ) -> DetectionRunResult:
        """
        Frame-by-frame: read jpg → YOLO detect (classes 2,3,5,7)
        → ByteTrack update → yield progress → persist track rows.
        Checks cancel_event after each frame.
        """
        ...
```

**FPS computation:** wall-clock time over all frames processed / frame_count. Tagged `MEASURED`.

### 9.3 AlertEngine (`backend/app/services/alert_engine.py`)

```python
class AlertEngine:
    """
    Fires a simulated alert for watchlist or unauthorized_unrecognized plates.
    Never makes external network calls.
    """
    def __init__(self, alert_repo: AlertRepository, config: Settings): ...

    async def process(
        self,
        plate: str,
        classification: ClassificationResult,
        track_id: int | None = None,
        frame_image: np.ndarray | None = None,
        detection_timestamp: datetime | None = None,
    ) -> AlertRecord | None:
        """
        Returns None if status is 'authorized'.
        Saves evidence image to outputs/evidence/{alert_id}.jpg if frame_image provided.
        Computes alert_latency_ms = now - detection_timestamp.
        provenance always SIMULATED.
        """
        ...
```

### 9.4 Job Manager (`backend/app/core/job_manager.py`)

```python
class JobStatus(str, Enum):
    QUEUED    = "queued"
    RUNNING   = "running"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    ERROR     = "error"

class Job(BaseModel):
    job_id: str
    status: JobStatus
    progress_pct: float = 0.0
    result: Any = None
    error: str | None = None
    cancel_event: Any  # asyncio.Event (excluded from serialisation)

class JobManager:
    """
    Singleton. Holds in-process job dict.
    Uses asyncio background tasks (or ThreadPoolExecutor for CPU-bound work).
    SSE subscribers stored as asyncio.Queue per job_id.
    """
    async def submit(self, coro: Coroutine) -> str: ...   # returns job_id
    async def cancel(self, job_id: str) -> bool: ...
    def get(self, job_id: str) -> Job | None: ...
    async def subscribe(self, job_id: str) -> AsyncGenerator[str, None]: ...
    # subscribe yields SSE-formatted strings
```

---

## 10. Error-Handling Strategy by Page

### 10.1 ANPR Lab

| Error | Backend response | Frontend behaviour |
|-------|-----------------|-------------------|
| File > 10 MB | HTTP 413 | Inline file-picker error; no job created |
| Wrong MIME type | HTTP 415 | Inline error |
| Corrupt/unreadable image | HTTP 422 `error: invalid_image` | Toast + reset uploader |
| EasyOCR not loaded | HTTP 503 `error: model_unavailable` | Toast "OCR model not ready" |
| Job not found | HTTP 404 | Toast; clear SSE listener |
| All variants < 0.70 confidence | HTTP 200, `low_confidence: true` | `LOW_CONFIDENCE` flag in UI; no validated label |

### 10.2 Validation Simulator

| Error | Response | Frontend |
|-------|---------|---------|
| Invalid params (out of range) | HTTP 422 | Inline slider validation before submit |
| Simulation error | HTTP 500 + `error` | Toast with detail |

### 10.3 Detection & Tracking

| Error | Response | Frontend |
|-------|---------|---------|
| Dataset directory missing | HTTP 404 `error: dataset_not_found` | `EmptyState` in sequence dropdown |
| Empty sequence (no frames) | HTTP 422 | Toast before job starts |
| YOLO not loaded | HTTP 503 | Toast "Detection model not ready" |
| Job cancelled | SSE `{type:cancelled}` | Progress bar → "Cancelled" state; run saved as cancelled |
| Frame fetch fails | HTTP 404 | FrameViewer shows placeholder image with error icon |

### 10.4 Dataset Explorer

| Error | Response | Frontend |
|-------|---------|---------|
| Dataset missing | HTTP 404 | `EmptyState` per dataset section; page stays up |
| Thumbnail path traversal | HTTP 400 | — |
| Zero frames | HTTP 200, `total_frames: 0` | Gallery shows EmptyState |

### 10.5 Watchlist

| Error | Response | Frontend |
|-------|---------|---------|
| Invalid plate regex | HTTP 422 | Inline form validation before submit |
| Duplicate plate | HTTP 409 | Toast "Plate already exists" |
| CSV import partial failure | HTTP 200 + `ImportSummary` | Toast with counts; skipped rows shown in modal |

### 10.6 Alerts

| Error | Response | Frontend |
|-------|---------|---------|
| Evidence image missing | HTTP 404 | Evidence button disabled; tooltip "Image not available" |
| Empty filter result | HTTP 200, `items: []` | `EmptyState` in feed |

### 10.7 Overview

| Error | Response | Frontend |
|-------|---------|---------|
| No data yet | HTTP 200, KPIs with `provenance: DEMO` | Demo fallback visible; PlaceholderBanner if any PLACEHOLDER |
| Pipeline status fetch fails | HTTP 503 | Pipeline diagram shows all stages as `idle`; toast |

---

## 11. Folder Structure Additions (Phases 2–4)

```
backend/app/
├── api/v1/
│   ├── anpr.py                  # POST upload, GET job, GET stream, GET history
│   ├── validation.py            # POST run, GET history, GET export
│   ├── detection.py             # POST start, GET job/stream/cancel, runs, frame, charts
│   ├── datasets.py              # stats, sequences, gallery, thumbnail
│   ├── watchlist.py             # CRUD, import, export
│   ├── alerts.py                # list, detail, evidence, export
│   └── overview.py              # kpis, pipeline-status, recent-alerts, charts
├── services/
│   ├── ocr_pipeline.py          # OcrPipeline (port from notebook)
│   ├── detection_service.py     # DetectionService (YOLO11n + ByteTrack)
│   └── alert_engine.py          # AlertEngine (simulated)
├── repositories/
│   ├── base.py                  # Base async repository
│   ├── vehicle_repo.py
│   ├── anpr_repo.py
│   ├── simulation_repo.py
│   ├── detection_repo.py
│   └── alert_repo.py
├── core/
│   └── job_manager.py           # JobManager singleton
├── models/
│   ├── anpr.py                  # OcrRunResult, OcrJobStatus, AnprRunSummary
│   ├── validation.py            # SimulationRequest/Result
│   ├── detection.py             # DetectionRequest/Status/Charts
│   ├── dataset.py               # DatasetStats, SequenceInfo
│   ├── watchlist.py             # VehicleCreate/Update/Record, ImportSummary
│   ├── alerts.py                # AlertRecord
│   └── overview.py              # OverviewKpis, PipelineStatus, OverviewCharts
└── db/
    ├── database.py              # async engine + session factory
    └── migrations/
        └── 001_initial.sql

backend/tests/
├── test_ocr_pipeline.py
├── test_detection_service.py
├── test_alert_engine.py
├── test_watchlist_repo.py
├── test_alert_repo.py
├── test_api_anpr.py
├── test_api_detection.py
└── test_api_watchlist.py

frontend/src/
├── pages/
│   ├── Overview.tsx             # now built
│   ├── AnprLab.tsx              # now built
│   ├── ValidationSimulator.tsx  # now built
│   ├── Detection.tsx            # now built
│   ├── DatasetExplorer.tsx      # now built
│   ├── Watchlist.tsx            # now built
│   └── Alerts.tsx               # now built
├── components/
│   ├── anpr/
│   │   ├── CropBox.tsx
│   │   ├── OcrProgress.tsx
│   │   ├── PreprocessingGrid.tsx
│   │   ├── OcrCandidatesTable.tsx
│   │   ├── ConfidenceGauge.tsx
│   │   ├── PlateStructureBreakdown.tsx
│   │   └── CharCorrectionDisplay.tsx
│   ├── detection/
│   │   ├── SequenceSelector.tsx
│   │   ├── JobProgress.tsx
│   │   ├── FrameViewer.tsx
│   │   └── RunHistory.tsx
│   ├── overview/
│   │   ├── PipelineDiagram.tsx
│   │   └── KpiGrid.tsx
│   └── shared/
│       └── SimulatedAlertBanner.tsx
├── hooks/
│   ├── useAnprUpload.ts
│   ├── useAnprJob.ts
│   ├── useAnprStream.ts
│   ├── useValidationRun.ts
│   ├── useDetectionStart.ts
│   ├── useDetectionStream.ts
│   ├── useDetectionRuns.ts
│   ├── useDatasets.ts
│   ├── useWatchlist.ts
│   ├── useAlerts.ts
│   └── useOverview.ts
└── lib/
    └── types.ts                 # all TypeScript interfaces
```

---

## 12. Demo Mode Extensions

Each new `DemoDataProvider` method produces data for every new page:

```python
class DemoDataProvider:
    # existing: health, alert_log, detection_summary, watchlist_summary

    # M1 additions
    def anpr_run(self) -> dict: ...              # single OcrRunResult-shaped dict
    def anpr_history(self, n=5) -> list[dict]: ...
    def simulation_result(self) -> dict: ...     # SimulationResult-shaped
    def simulation_history(self, n=3) -> list[dict]: ...

    # M2 additions
    def ua_detrac_stats(self) -> dict: ...
    def ua_detrac_sequences(self) -> list[dict]: ...
    def detection_run(self) -> dict: ...         # DetectionRunDetail-shaped
    def detection_runs(self, n=3) -> list[dict]: ...
    def detection_charts(self) -> dict: ...
    def dataset_gallery(self, n=24) -> list[dict]: ...

    # M3 additions
    def watchlist(self) -> list[dict]: ...       # seeded 3 vehicles
    def alerts(self, n=10) -> list[dict]: ...
    def overview_kpis(self) -> dict: ...
    def pipeline_status(self) -> dict: ...
    def overview_charts(self) -> dict: ...
```

---

## 13. Security Additions (Phases 2–4)

| Concern | Mitigation |
|---------|-----------|
| Path traversal in thumbnail endpoint | Resolve path against `DATASETS_ROOT`; reject if result is outside root |
| Evidence image path traversal | Save only to `outputs/evidence/`; never trust client-provided path |
| CSV import injection | Parse with `csv.DictReader`; validate every cell; no shell execution |
| Job cancellation race | `cancel_event.set()` is atomic; job checks flag before each frame |
| SSE connection leak | Server closes SSE stream on job completion/cancel/error |
| Large frame response | Thumbnail served by default (max 256×256); full-res requires explicit `?full=true` |
