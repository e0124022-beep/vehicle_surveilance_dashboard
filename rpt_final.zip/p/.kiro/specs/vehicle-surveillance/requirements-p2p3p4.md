# Requirements — Phases 2, 3 & 4 (Combined)
## Deep Learning-Based Intelligent Vehicle Surveillance System

**Format:** EARS (Easy Approach to Requirements Syntax)
**Phases:** 2 (ANPR Lab + Validation Simulator) · 3 (Detection & Tracking + Dataset Explorer) · 4 (Watchlist & Alerts + Overview)
**Version:** 1.0
**Date:** 2026-10-25
**Builds on:** Phase 1 Foundation (`requirements.md`, `design.md`, `tasks.md`)

---

## Notation

- `WHEN <trigger> THE SYSTEM SHALL <response>` — event-driven
- `WHILE <state> THE SYSTEM SHALL <response>` — state-driven
- `THE SYSTEM SHALL <response>` — ubiquitous
- `IF <precondition> THEN THE SYSTEM SHALL <response>` — conditional

---

## Global Rules (apply to every milestone)

**REQ-G-01**
THE SYSTEM SHALL attach a `provenance` tag (`MEASURED`, `SIMULATED`, `PLACEHOLDER`, or `DEMO`) to every metric, KPI, chart value, and OCR result displayed in the UI.

**REQ-G-02**
WHILE any `PLACEHOLDER`-tagged value is visible on the current page, THE SYSTEM SHALL display the persistent `PlaceholderBanner` component. The banner must not be dismissible.

**REQ-G-03**
THE SYSTEM SHALL never integrate a real SMS messaging provider. All alert notifications are simulated and labelled `SIMULATED`.

**REQ-G-04**
THE SYSTEM SHALL load EasyOCR and YOLO11n exactly once during the application lifespan startup. Models must not be reloaded per request.

**REQ-G-05**
IF CUDA is not available, THEN THE SYSTEM SHALL silently fall back to CPU processing and log a warning. No manual configuration shall be required.

**REQ-G-06**
THE SYSTEM SHALL execute all heavy computations (OCR pipelines, detection runs) as background jobs and expose progress to the frontend via Server-Sent Events (SSE) or status-polling endpoints. No heavy work shall block a request handler.

**REQ-G-07**
THE SYSTEM SHALL handle the following failure conditions gracefully with structured error responses and clear UI messages: corrupt or unreadable uploaded images, missing model weights, missing dataset directories, no GPU available, dataset sequences with zero frames.

**REQ-G-08**
THE SYSTEM SHALL persist the following metadata with every run: application config snapshot, random seed, model name and version, ISO 8601 timestamp.

**REQ-G-09**
THE SYSTEM SHALL enforce upload size limits (default 10 MB, configurable) and MIME-type validation (`image/jpeg`, `image/png`) before processing any uploaded file.

**REQ-G-10**
THE SYSTEM SHALL never modify any file under `vehicle_surveillance_project/datasets/`.

**REQ-G-11**
WHEN `DEMO_MODE` is `true`, THE SYSTEM SHALL serve labelled `DEMO` data for every page. No page shall be blank or raise an error in demo mode.

**REQ-G-12**
THE SYSTEM SHALL provide pytest unit and integration tests for every backend service and API endpoint introduced in these phases. THE SYSTEM SHALL provide Vitest tests for every new shared component.

---

## MILESTONE 1 — ANPR Lab + Multi-Frame Validation Simulator

### 1. ANPR Lab Page

#### 1.1 Image Upload & Crop

**REQ-M1-01**
WHEN a user navigates to the ANPR Lab page, THE SYSTEM SHALL present an image-upload control that accepts JPEG and PNG files up to the configured maximum size.

**REQ-M1-02**
WHEN a valid image is uploaded, THE SYSTEM SHALL display it in an interactive crop-box control that allows the user to draw, resize, and reposition a crop region before submitting to OCR. The crop region must not be hardcoded.

**REQ-M1-03**
IF the uploaded file exceeds the size limit or is not an accepted MIME type, THEN THE SYSTEM SHALL display a clear inline error and reject the file before any processing occurs.

#### 1.2 Multi-Preprocessing OCR Pipeline

**REQ-M1-04**
THE SYSTEM SHALL implement an `OcrPipeline` service in `backend/app/services/ocr_pipeline.py` that applies the following preprocessing variants to the (optionally cropped) input image:
1. CLAHE (Contrast Limited Adaptive Histogram Equalisation)
2. Unsharp-mask sharpening
3. Otsu global threshold
4. Adaptive threshold (Gaussian)

For each variant, the pipeline SHALL apply upscaling at factors of 3×, 5×, and 7× before OCR, yielding up to 12 preprocessed sub-images per input.

**REQ-M1-05**
THE SYSTEM SHALL apply bilateral denoising and Gaussian denoising as optional pre-filter steps before upscaling, configurable via the API request body.

**REQ-M1-06**
WHEN the OCR pipeline runs, THE SYSTEM SHALL call EasyOCR once per preprocessed sub-image and return, for each variant: variant name, upscale factor, raw detected text, cleaned text (digits and uppercase letters only), and EasyOCR confidence score.

**REQ-M1-07**
THE SYSTEM SHALL select the best OCR candidate as the variant with the highest confidence score that also passes the Indian plate regex `^([A-Z]{2})(\d{1,2})([A-Z]{1,3})(\d{1,4})$`. IF no variant passes the regex, THE SYSTEM SHALL return the highest-confidence raw result and tag it `LOW_CONFIDENCE`.

**REQ-M1-08**
THE SYSTEM SHALL apply positional character correction to the best candidate before regex validation: position-aware substitutions O↔0, I↔1, S↔5, B↔8 applied only in digit positions of the Indian plate format.

**REQ-M1-09**
THE SYSTEM SHALL return the before-correction and after-correction strings so the UI can display both.

**REQ-M1-10**
IF the best candidate confidence is below `0.70`, THEN THE SYSTEM SHALL flag the result `LOW_CONFIDENCE`. A `LOW_CONFIDENCE` result must never be classified as `validated` in any downstream component.

**REQ-M1-11**
THE SYSTEM SHALL execute the OCR pipeline as a background job. WHEN a job is submitted, THE SYSTEM SHALL return a `job_id` immediately. The frontend SHALL poll `GET /api/v1/anpr/job/{job_id}` or receive SSE events for progress and final results.

#### 1.3 ANPR Lab UI

**REQ-M1-12**
THE SYSTEM SHALL display an OCR preprocessing grid showing the preprocessed sub-image thumbnails, each labelled with its variant name and upscale factor.

**REQ-M1-13**
THE SYSTEM SHALL display an OCR candidates table listing all variants with columns: variant, upscale, raw text, cleaned text, confidence, regex match (yes/no).

**REQ-M1-14**
THE SYSTEM SHALL display a confidence gauge showing the best-candidate confidence value.

**REQ-M1-15**
THE SYSTEM SHALL display a plate-structure breakdown of the best candidate showing: state code, RTO code, series, number — derived from `IndianPlateParser`.

**REQ-M1-16**
THE SYSTEM SHALL display the positional character correction before/after strings side by side.

**REQ-M1-17**
THE SYSTEM SHALL display a `StatusBadge` showing the database classification (authorized / watchlist / unauthorized_unrecognized) of the best validated plate.

**REQ-M1-18**
THE SYSTEM SHALL display the total processing time for the OCR pipeline run, tagged `MEASURED`.

**REQ-M1-19**
WHILE the OCR job is in progress, THE SYSTEM SHALL show a progress indicator. WHEN the job completes, THE SYSTEM SHALL update the UI without a full page reload.

#### 1.4 ANPR Persistence

**REQ-M1-20**
THE SYSTEM SHALL persist each completed ANPR Lab run to the SQLite database with fields compatible with `outputs/photo_anpr_result.csv`: timestamp, image filename, best plate, confidence, variant used, correction applied (bool), validation status, database status, processing time ms.

**REQ-M1-21**
THE SYSTEM SHALL provide a `GET /api/v1/anpr/history` endpoint returning paginated past ANPR runs.

---

### 2. Multi-Frame Validation Simulator Page

#### 2.1 Simulator Controls

**REQ-M1-22**
THE SYSTEM SHALL provide a Validation Simulator page with the following configurable parameters exposed as UI sliders or inputs:
- Window size (3–15, default 7)
- Minimum confidence threshold (0.50–0.95, default 0.70)
- Per-frame OCR error probability (0.05–0.50, default 0.20)
- Number of simulated tracks (1–20, default 5)
- Random seed (integer, default from config)

**REQ-M1-23**
WHEN the user submits the simulator, THE SYSTEM SHALL run the `MonteCarloSimulator` and `PlateValidator` services with the supplied parameters and return results tagged `SIMULATED`.

#### 2.2 Simulator Results

**REQ-M1-24**
THE SYSTEM SHALL display a frame-by-frame vote table showing, per track and per frame: frame index, simulated raw plate reading, confidence, accepted/rejected (confidence filter), running vote counts, and current validated plate.

**REQ-M1-25**
Rows where a reading was rejected due to low confidence SHALL be visually highlighted (e.g., dimmed row with a "REJECTED" label).

**REQ-M1-26**
THE SYSTEM SHALL display per-track final results: validated plate string, vote count, window size, and database classification status.

**REQ-M1-27**
THE SYSTEM SHALL display a single-frame vs N-frame comparison chart using Recharts, showing false-decision rate on the Y axis and number of frames on the X axis, with 95% confidence intervals derived from the Monte Carlo simulation, tagged `SIMULATED`.

**REQ-M1-28**
THE SYSTEM SHALL allow the user to export the simulation results as a CSV file with columns compatible with `outputs/ocr_validation_simulation.csv`.

#### 2.3 Simulator Persistence

**REQ-M1-29**
THE SYSTEM SHALL persist each simulation run to the database with: timestamp, seed, window_size, min_conf, error_probability, n_tracks, validated plates list, single_frame_error_rate, multi_frame_error_rate, improvement_factor.

**REQ-M1-30**
THE SYSTEM SHALL provide a `GET /api/v1/validation/history` endpoint returning paginated past simulation runs.

---

### 3. Milestone 1 API Endpoints

**REQ-M1-31**
THE SYSTEM SHALL expose the following new API endpoints for Milestone 1:

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/anpr/upload` | Upload image, start OCR job, return `job_id` |
| GET | `/api/v1/anpr/job/{job_id}` | Poll OCR job status and result |
| GET | `/api/v1/anpr/stream/{job_id}` | SSE stream for OCR job progress |
| GET | `/api/v1/anpr/history` | Paginated past ANPR runs |
| POST | `/api/v1/validation/run` | Run the validation simulator |
| GET | `/api/v1/validation/history` | Paginated past simulation runs |
| GET | `/api/v1/validation/export/{run_id}` | CSV export of a simulation run |

---

### 4. Milestone 1 Smoke Test Criteria

**REQ-M1-ST-01**
THE SYSTEM SHALL pass the following Milestone 1 smoke test:
1. Upload a JPEG plate image in the ANPR Lab → crop region interactive → OCR job starts.
2. OCR pipeline returns results with at least one variant, a best candidate, and a confidence value.
3. If confidence ≥ 0.70: plate structure breakdown shown, database status badge shown.
4. If confidence < 0.70: `LOW_CONFIDENCE` flag displayed; no "validated" label shown.
5. Navigate to Validation Simulator → adjust window size slider → run → frame table appears.
6. Comparison chart renders with two lines and confidence intervals.
7. CSV export produces a downloadable file matching the expected column schema.

---

## MILESTONE 2 — Detection & Tracking + Dataset Explorer

### 5. Detection & Tracking Page

#### 5.1 Sequence Selection

**REQ-M2-01**
THE SYSTEM SHALL provide a dropdown on the Detection & Tracking page listing all UA-DETRAC sequence folders (`MVI_xxxxx`) found under the configured `DATASETS_ROOT`. IF the dataset directory is missing, THE SYSTEM SHALL show the `EmptyState` component with a descriptive message and a `DEMO` fallback.

**REQ-M2-02**
THE SYSTEM SHALL provide configurable detection parameters via the UI: confidence threshold (0.1–0.9, default 0.5) and maximum frames to process (10–500, default 100).

#### 5.2 Background Detection Job

**REQ-M2-03**
WHEN the user starts a detection run, THE SYSTEM SHALL create a background job that runs YOLO11n + ByteTrack over the selected sequence. The job must not block the request handler.

**REQ-M2-04**
THE SYSTEM SHALL detect only COCO classes: 2 (car), 3 (motorcycle), 5 (bus), 7 (truck).

**REQ-M2-05**
THE SYSTEM SHALL stream live progress to the frontend via Server-Sent Events on `GET /api/v1/detection/stream/{job_id}`, emitting at minimum: `{ "frame": N, "total": T, "detections_this_frame": D, "status": "running"|"done"|"error" }`.

**REQ-M2-06**
THE SYSTEM SHALL provide a cancel endpoint `DELETE /api/v1/detection/job/{job_id}` that terminates the background job and marks it `cancelled`.

**REQ-M2-07**
IF the selected sequence directory is empty or contains no readable JPEG frames, THEN THE SYSTEM SHALL return an error before starting the job.

#### 5.3 Detection Results & Frame Viewer

**REQ-M2-08**
THE SYSTEM SHALL persist each completed detection run as a tracks table in the database with columns: `run_id`, `frame`, `track_id`, `vehicle_type`, `confidence`, `x1`, `y1`, `x2`, `y2`, plus a run metadata row: config snapshot, seed, model name/version, timestamp, FPS (tagged `MEASURED`).

**REQ-M2-09**
THE SYSTEM SHALL serve annotated frame images (bounding boxes + track IDs overlaid) via `GET /api/v1/detection/run/{run_id}/frame/{frame_idx}`. Frames must be served as thumbnails by default with a `?full=true` parameter for full resolution.

**REQ-M2-10**
THE SYSTEM SHALL provide an annotated frame viewer in the UI with a scrubber (range input) to navigate frames, side-by-side original vs annotated view, and lazy loading (only fetch visible frames).

**REQ-M2-11**
THE SYSTEM SHALL label the computed FPS value `MEASURED`. Any metric not computed from ground-truth data must not carry the `MEASURED` tag.

#### 5.4 Detection Charts

**REQ-M2-12**
THE SYSTEM SHALL display the following charts for a completed detection run:
1. Vehicle class distribution bar chart (count per class).
2. Vehicles per frame over time (line chart, X = frame index, Y = detection count).
3. Track-length histogram (X = track length in frames, Y = count of tracks).

All charts tagged `MEASURED`.

#### 5.5 Run History & Reopen

**REQ-M2-13**
THE SYSTEM SHALL provide a run history list on the Detection page showing all past runs with: sequence name, timestamp, frame count, total tracks, FPS, status (completed/cancelled/error).

**REQ-M2-14**
WHEN the user selects a past run from the history list, THE SYSTEM SHALL load and display its results in the frame viewer and charts without re-running the detection.

---

### 6. Dataset Explorer Page

#### 6.1 Dataset Stats

**REQ-M2-15**
THE SYSTEM SHALL display summary statistics for the UA-DETRAC dataset: total sequence count, total frame count, and image resolution (width × height), tagged `MEASURED`. IF the dataset is missing, display `DEMO` fallback stats.

**REQ-M2-16**
THE SYSTEM SHALL display summary statistics for the Indian plates dataset: total image count and any available metadata, tagged `MEASURED` where computable.

#### 6.2 Gallery

**REQ-M2-17**
THE SYSTEM SHALL provide a paginated image gallery for each dataset (default 24 images per page) with lazy-loaded thumbnails served via `GET /api/v1/datasets/{dataset}/thumbnail/{path}`.

**REQ-M2-18**
THE SYSTEM SHALL provide a "Random Sample" button that fetches a randomly selected set of images from the dataset using the configured seed, tagged `DEMO` if in demo mode, `MEASURED` otherwise.

**REQ-M2-19**
IF a dataset directory is missing or empty, THE SYSTEM SHALL display the `EmptyState` component with a clear message. The page must not crash.

#### 6.3 Dataset Explorer API

**REQ-M2-20**
THE SYSTEM SHALL expose the following endpoints for Milestone 2:

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/v1/datasets/ua-detrac/stats` | UA-DETRAC summary stats |
| GET | `/api/v1/datasets/ua-detrac/sequences` | List all MVI_xxxxx sequence folders |
| GET | `/api/v1/datasets/ua-detrac/gallery` | Paginated frame thumbnails |
| GET | `/api/v1/datasets/indian-plates/stats` | Indian plates dataset stats |
| GET | `/api/v1/datasets/indian-plates/gallery` | Paginated plate thumbnails |
| GET | `/api/v1/datasets/{dataset}/thumbnail/{path}` | Serve resized thumbnail |
| POST | `/api/v1/detection/start` | Start detection job, return `job_id` |
| GET | `/api/v1/detection/job/{job_id}` | Poll job status |
| GET | `/api/v1/detection/stream/{job_id}` | SSE progress stream |
| DELETE | `/api/v1/detection/job/{job_id}` | Cancel job |
| GET | `/api/v1/detection/runs` | List past runs |
| GET | `/api/v1/detection/run/{run_id}` | Run metadata + summary |
| GET | `/api/v1/detection/run/{run_id}/frame/{idx}` | Annotated frame image |
| GET | `/api/v1/detection/run/{run_id}/tracks` | Paginated tracks table |
| GET | `/api/v1/detection/run/{run_id}/charts` | Aggregated chart data |

---

### 7. Milestone 2 Smoke Test Criteria

**REQ-M2-ST-01**
THE SYSTEM SHALL pass the following Milestone 2 smoke test:
1. Dataset Explorer shows UA-DETRAC sequence count and frames; gallery loads thumbnails.
2. Detection page: select a sequence → set max frames = 20 → start run.
3. SSE stream emits frame-progress events visible in browser network tab.
4. Run completes → frame viewer opens at frame 0, scrubber navigates to frame 10.
5. All three charts render with data.
6. History list shows the completed run.
7. Click the run in history → results reload without re-running.

---

## MILESTONE 3 — Watchlist & Alerts + Overview

### 8. Watchlist Management

#### 8.1 Vehicle Database CRUD

**REQ-M3-01**
THE SYSTEM SHALL provide a Watchlist page with a searchable, sortable table of all vehicles in the database, showing: plate, status (authorized/watchlist), description, created_at, updated_at.

**REQ-M3-02**
THE SYSTEM SHALL allow users to add a new vehicle record with: plate (validated by `IndianPlateParser` before saving), status, and description. Duplicates SHALL be rejected with a clear error message.

**REQ-M3-03**
THE SYSTEM SHALL allow users to edit the status and description of an existing vehicle record.

**REQ-M3-04**
THE SYSTEM SHALL allow users to delete a vehicle record with a confirmation dialog.

**REQ-M3-05**
THE SYSTEM SHALL seed the vehicle database on first run with: `TN01AB1234` authorized, `TN02CD5678` authorized, `TN03EF9012` watchlist.

**REQ-M3-06**
THE SYSTEM SHALL validate all plate strings against the Indian plate regex before any database write. IF validation fails, THE SYSTEM SHALL return HTTP 422 with a descriptive error.

#### 8.2 CSV Import / Export

**REQ-M3-07**
THE SYSTEM SHALL provide a CSV import endpoint `POST /api/v1/watchlist/import` that accepts a CSV file with columns `plate,status,description`, validates each row, imports valid rows, and returns a summary: rows imported, rows skipped (with reasons).

**REQ-M3-08**
THE SYSTEM SHALL provide a CSV export endpoint `GET /api/v1/watchlist/export` that returns all vehicle records as a CSV file.

---

### 9. Alert Engine

**REQ-M3-09**
THE SYSTEM SHALL implement an `AlertEngine` service that fires a simulated alert whenever a validated plate is classified as `watchlist` or `unauthorized_unrecognized`.

**REQ-M3-10**
WHEN an alert fires, THE SYSTEM SHALL persist an alert record to the database with fields: `alert_id`, `timestamp`, `plate`, `track_id` (nullable), `status` (watchlist/unauthorized_unrecognized), `message`, `evidence_image_path` (nullable), `alert_latency_ms` (time from detection to alert), `provenance` ("SIMULATED").

**REQ-M3-11**
THE SYSTEM SHALL save an evidence image crop (the bounding-box region of the detected plate or vehicle) to `outputs/evidence/{alert_id}.jpg` when a `track_id` and frame image are available.

**REQ-M3-12**
THE SYSTEM SHALL display a persistent `SIMULATED` banner on the alert feed page. This banner is distinct from the `PlaceholderBanner` and must always be visible on the alerts page.

**REQ-M3-13**
THE SYSTEM SHALL never make any network call to an external SMS or notification provider.

---

### 10. Alert Feed Page

**REQ-M3-14**
THE SYSTEM SHALL provide a filterable alert feed with filter controls: status (all/watchlist/unauthorized_unrecognized), date range (from/to), and plate search (partial match).

**REQ-M3-15**
THE SYSTEM SHALL display each alert row with: timestamp, plate, status badge, track ID, message, alert latency, and an "Evidence" button that opens the evidence image if available.

**REQ-M3-16**
THE SYSTEM SHALL display an alert timeline chart (alerts over time, binned by hour or day) tagged `MEASURED`.

**REQ-M3-17**
THE SYSTEM SHALL display a status breakdown donut chart (watchlist vs unauthorized_unrecognized counts) tagged `MEASURED`.

**REQ-M3-18**
THE SYSTEM SHALL provide a CSV export of the filtered alert feed, compatible with `outputs/alerts.csv`.

---

### 11. Overview Page

#### 11.1 KPI Cards

**REQ-M3-19**
THE SYSTEM SHALL display the following KPI cards on the Overview page, each with a provenance tag:

| KPI | Provenance |
|-----|-----------|
| Total vehicles tracked (from detection runs) | MEASURED |
| Total plates validated (ANPR + simulator) | MEASURED / SIMULATED |
| Authorized count | MEASURED |
| Watchlist hits | MEASURED |
| Unknown / unrecognized count | MEASURED |
| Total alerts fired | MEASURED |
| Average OCR confidence | MEASURED |
| Average processing latency ms | MEASURED |

If data from M1/M2 is not yet present, THE SYSTEM SHALL fall back to `DEMO` data tagged accordingly.

#### 11.2 Pipeline Diagram

**REQ-M3-20**
THE SYSTEM SHALL render a pipeline stage diagram on the Overview page showing the following stages in order: Camera → YOLO11n Detection → ByteTrack Tracking → Plate Localisation → Preprocessing → EasyOCR → Multi-Frame Validation → Database Check → Alert. Each stage must show its status (active/idle/error) based on the latest run data.

#### 11.3 Recent Alerts & Charts

**REQ-M3-21**
THE SYSTEM SHALL display a recent alerts table on the Overview page (last 10 alerts) with plate, status, timestamp, and a link to the full alert feed.

**REQ-M3-22**
THE SYSTEM SHALL display a status donut chart (authorized / watchlist / unknown proportions) on the Overview page, driven by live database counts, tagged `MEASURED`. IF no data exists, use `DEMO` fallback.

---

### 12. End-to-End Pipeline Wiring

**REQ-M3-23**
THE SYSTEM SHALL wire the ANPR Lab and Validation Simulator to the Alert Engine: WHEN a validated plate from either source is classified by `PlateClassifier` as `watchlist` or `unauthorized_unrecognized`, THE SYSTEM SHALL create an alert record via the `AlertEngine`.

**REQ-M3-24**
THE SYSTEM SHALL wire the Detection & Tracking pipeline to the Overview: vehicle and track counts from completed detection runs SHALL update the Overview KPI totals.

**REQ-M3-25**
WHEN `DEMO_MODE` is `true`, THE SYSTEM SHALL populate Overview KPIs, the recent alerts table, and all charts from `DemoDataProvider`, labelled `DEMO`.

---

### 13. Watchlist & Alerts API Endpoints

**REQ-M3-26**
THE SYSTEM SHALL expose the following endpoints for Milestone 3:

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/v1/watchlist` | List all vehicles (paginated, filterable) |
| POST | `/api/v1/watchlist` | Add vehicle record |
| PUT | `/api/v1/watchlist/{plate}` | Update vehicle record |
| DELETE | `/api/v1/watchlist/{plate}` | Delete vehicle record |
| POST | `/api/v1/watchlist/import` | CSV bulk import |
| GET | `/api/v1/watchlist/export` | CSV export |
| GET | `/api/v1/alerts` | List alerts (paginated, filterable) |
| GET | `/api/v1/alerts/export` | CSV export |
| GET | `/api/v1/alerts/{alert_id}` | Single alert detail |
| GET | `/api/v1/alerts/{alert_id}/evidence` | Evidence image |
| GET | `/api/v1/overview/kpis` | All KPI values |
| GET | `/api/v1/overview/pipeline-status` | Pipeline stage statuses |
| GET | `/api/v1/overview/recent-alerts` | Last 10 alerts |
| GET | `/api/v1/overview/charts` | Donut + timeline chart data |

---

### 14. Database Schema

**REQ-M3-27**
THE SYSTEM SHALL implement the following SQLite tables (via SQLModel or raw SQLite) as a repository layer. Data must not be stored in memory only.

**`vehicles`**
```
plate         TEXT PRIMARY KEY   -- validated Indian plate string
status        TEXT               -- "authorized" | "watchlist"
description   TEXT
created_at    DATETIME
updated_at    DATETIME
```

**`anpr_runs`**
```
run_id        TEXT PRIMARY KEY
timestamp     DATETIME
image_filename TEXT
best_plate    TEXT
confidence    REAL
variant_used  TEXT
correction_applied INTEGER      -- bool
validation_status  TEXT
db_status          TEXT
processing_time_ms REAL
provenance         TEXT
```

**`validation_sim_runs`**
```
run_id        TEXT PRIMARY KEY
timestamp     DATETIME
seed          INTEGER
window_size   INTEGER
min_conf      REAL
error_prob    REAL
n_tracks      INTEGER
results_json  TEXT              -- JSON blob of per-track results
single_frame_error_rate REAL
multi_frame_error_rate  REAL
improvement_factor      REAL
provenance    TEXT
```

**`detection_runs`**
```
run_id        TEXT PRIMARY KEY
sequence_name TEXT
timestamp     DATETIME
frame_count   INTEGER
total_tracks  INTEGER
fps           REAL
status        TEXT              -- "completed"|"cancelled"|"error"
config_json   TEXT
model_version TEXT
seed          INTEGER
```

**`detection_tracks`**
```
id            INTEGER PRIMARY KEY AUTOINCREMENT
run_id        TEXT REFERENCES detection_runs(run_id)
frame         INTEGER
track_id      INTEGER
vehicle_type  TEXT
confidence    REAL
x1            REAL
y1            REAL
x2            REAL
y2            REAL
```

**`alerts`**
```
alert_id      TEXT PRIMARY KEY
timestamp     DATETIME
plate         TEXT
track_id      INTEGER          -- nullable
status        TEXT             -- "watchlist"|"unauthorized_unrecognized"
message       TEXT
evidence_image_path TEXT       -- nullable
alert_latency_ms    REAL
provenance    TEXT             -- always "SIMULATED"
```

---

### 15. Milestone 3 Smoke Test Criteria

**REQ-M3-ST-01**
THE SYSTEM SHALL pass the following Milestone 3 smoke test:
1. Add a new watchlist plate via the Watchlist UI → record appears in table.
2. Navigate to ANPR Lab → upload image of that plate → run OCR → alert fires if confidence ≥ 0.70 and plate is classified watchlist.
3. Navigate to Alerts page → new simulated alert appears with `SIMULATED` banner.
4. Navigate to Overview → watchlist KPI count has incremented.
5. Overview pipeline diagram renders all 9 stages.
6. Recent alerts table shows the triggered alert.

---

### 16. Full End-to-End Smoke Test

**REQ-E2E-01**
THE SYSTEM SHALL pass a full end-to-end smoke test in **demo mode** (`DEMO_MODE=true`):
1. All 8 sidebar pages render without error (no blank screens, no 404s).
2. Overview KPIs show labelled `DEMO` data.
3. ANPR Lab shows a pre-loaded demo image and demo OCR results.
4. Validation Simulator renders comparison chart with `SIMULATED` tag.
5. Detection page shows a demo run in history with frame viewer functional.
6. Dataset Explorer shows demo stats and gallery thumbnails.
7. Watchlist shows seeded vehicles.
8. Alerts page shows demo alerts with `SIMULATED` banner.

**REQ-E2E-02**
THE SYSTEM SHALL pass a full end-to-end smoke test in **real-data mode** (`DEMO_MODE=false`):
1. ANPR Lab: upload a real plate image → OCR result returned.
2. Validation Simulator: run with default params → CSV export downloads.
3. Detection: select first available UA-DETRAC sequence → run 20 frames → run appears in history.
4. Dataset Explorer: UA-DETRAC stats show correct sequence count.
5. Watchlist: all three seeded plates present.
6. Alerts: any watchlist plate processed in steps 1–2 appears in feed.
7. Overview: KPI counts reflect at least one real completed run.

---

## Appendix — Requirement ID Registry (Phases 2–4)

| Range | Area |
|-------|------|
| REQ-G-01 – REQ-G-12 | Global rules |
| REQ-M1-01 – REQ-M1-30 | M1: ANPR Lab |
| REQ-M1-31 | M1: API endpoints |
| REQ-M1-ST-01 | M1: Smoke test |
| REQ-M2-01 – REQ-M2-19 | M2: Detection & Tracking + Dataset Explorer |
| REQ-M2-20 | M2: API endpoints |
| REQ-M2-ST-01 | M2: Smoke test |
| REQ-M3-01 – REQ-M3-25 | M3: Watchlist, Alerts, Overview, Wiring |
| REQ-M3-26 | M3: API endpoints |
| REQ-M3-27 | M3: Database schema |
| REQ-M3-ST-01 | M3: Smoke test |
| REQ-E2E-01 – REQ-E2E-02 | Full end-to-end smoke tests |
