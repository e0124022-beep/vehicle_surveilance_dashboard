# Run for review (Windows PowerShell, from this folder)

Frontend only (enough to view the full dashboard, all pages work in demo mode):
    cd frontend
    npm install
    npm run dev          ->  open http://localhost:5173

Optional backend (health/config API; ML pages use demo data):
    cd backend
    python -m venv .venv
    .venv\Scripts\activate
    pip install -r requirements.txt     (Python 3.10-3.12)
    python -m uvicorn app.main:app --reload --port 8000

Both together after `npm install` in root, frontend and a backend venv:  npm run dev

# Real plate OCR (ANPR Lab)
In the backend venv, additionally run (large download, ~2 GB, first OCR call also downloads model weights):
    pip install easyocr opencv-python-headless
Then restart the backend. ANPR Lab will read your uploaded image with EasyOCR.

# Dataset (Indian number plates)
Extract the dataset so these folders exist:
    vehicle_surveillance_project/datasets/indian_plates/{State-wise_OLX,google_images,video_images}
Backend extra for thumbnails/crops:   pip install opencv-python-headless
Measure real OCR accuracy (needs easyocr), from the backend folder with the venv active:
    python -m scripts.evaluate_ocr --n 50       (try 5 first, then 200)
Results are saved to vehicle_surveillance_project/outputs/ocr_eval.json and appear on the Evaluation page.
