"""Real plate OCR: multi-preprocessing EasyOCR with Indian-plate validation (ported from the notebook)."""
from __future__ import annotations

import re
from typing import Any


PLATE_RE = re.compile(r"^([A-Z]{2})(\d{1,2})([A-Z]{1,3})(\d{1,4})$")
TO_DIGIT = {"O": "0", "I": "1", "S": "5", "B": "8", "Z": "2", "G": "6", "Q": "0"}
TO_LETTER = {v: k for k, v in TO_DIGIT.items() if k not in ("Q",)}
_reader: Any = None


def get_reader() -> Any:
    """Load EasyOCR once (first call downloads model weights)."""
    global _reader
    if _reader is None:
        import easyocr  # raises ImportError if not installed

        try:
            import torch

            gpu = torch.cuda.is_available()
        except Exception:
            gpu = False
        _reader = easyocr.Reader(["en"], gpu=gpu, verbose=False)
    return _reader


def correct(text: str) -> str:
    """Positional correction for the standard 10-char layout LL DD LL DDDD."""
    if len(text) != 10:
        return text
    out = []
    for i, ch in enumerate(text):
        letter_pos = i in (0, 1, 4, 5)
        out.append(TO_LETTER.get(ch, ch) if letter_pos else TO_DIGIT.get(ch, ch))
    return "".join(out)


def variants(img: "np.ndarray") -> dict[str, "np.ndarray"]:
    import cv2
    import numpy as np

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
    h, w = gray.shape[:2]
    scale = 3 if max(h, w) < 400 else 1
    gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    gray = cv2.bilateralFilter(gray, 9, 75, 75)
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8)).apply(gray)
    sharp = cv2.filter2D(clahe, -1, np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]]))
    otsu = cv2.threshold(clahe, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
    adapt = cv2.adaptiveThreshold(clahe, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 10)
    return {"Enhanced (CLAHE)": clahe, "Sharpened": sharp, "Otsu threshold": otsu, "Adaptive threshold": adapt}


def read_plate(data: bytes, reader: Any | None = None) -> dict[str, Any]:
    import cv2
    import numpy as np

    if not data:
        raise ValueError("Empty file")
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Could not decode image")
    if img.shape[1] > 1600:
        img = cv2.resize(img, None, fx=1600 / img.shape[1], fy=1600 / img.shape[1])
    reader = reader or get_reader()
    rows = []
    for name, im in variants(img).items():
        res = reader.readtext(im, allowlist="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", detail=1)
        res = sorted(res, key=lambda d: float(np.mean([pt[0] for pt in d[0]])) if len(d[0]) > 1 else 0.0)
        # Candidates: every single box, runs of adjacent boxes (plates are often split), and all boxes joined.
        cands = []
        for a in range(len(res)):
            for b in range(a, min(a + 3, len(res))):
                seg = res[a: b + 1]
                cands.append(("".join(t for _, t, _ in seg).upper().replace(" ", ""), float(np.mean([c for _, _, c in seg]))))
        if len(res) > 3:
            cands.append(("".join(t for _, t, _ in res).upper().replace(" ", ""), float(np.mean([c for _, _, c in res]))))
        scored = [(raw, correct(raw), conf) for raw, conf in cands if len(raw) >= 4]
        scored.sort(key=lambda c: (bool(PLATE_RE.match(c[1])), c[2]), reverse=True)
        raw, clean, conf = scored[0] if scored else ("", "", 0.0)
        rows.append({"variant": name, "raw": raw, "clean": clean, "conf": round(conf, 3), "valid": bool(PLATE_RE.match(clean))})
    ranked = sorted(rows, key=lambda r: (r["valid"], r["conf"]), reverse=True)
    best = ranked[0]
    m = PLATE_RE.match(best["clean"])
    return {"variants": rows, "best": {"plate": best["clean"], "conf": best["conf"], "valid": best["valid"],
            "parts": dict(zip(("state", "rto", "series", "number"), m.groups())) if m else None}}
