"""Index of the Indian number-plate dataset (images + Pascal-VOC XML with plate text as <name>)."""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
from typing import Any

from app.core.config import get_settings

PLATE_RE = re.compile(r"^([A-Z]{2})(\d{1,2})([A-Z]{1,3})(\d{1,4})$")
IMG_EXT = (".jpg", ".jpeg", ".png", ".JPG")
_cache: dict[str, Any] = {}


def root() -> Path:
    return (Path(get_settings().datasets_root) / "indian_plates").resolve()


def _find_image(xml: Path, filename: str) -> Path | None:
    for cand in [xml.parent / filename, *[xml.with_suffix(e) for e in IMG_EXT]]:
        if cand.exists():
            return cand
    return None


def index(refresh: bool = False) -> list[dict[str, Any]]:
    if "items" in _cache and not refresh:
        return _cache["items"]
    base, items = root(), []
    if base.exists():
        for x in sorted(base.rglob("*.xml")):
            try:
                tree = ET.parse(x).getroot()
            except ET.ParseError:
                continue
            img = _find_image(x, tree.findtext("filename", ""))
            obj = tree.find("object")
            if img is None or obj is None:
                continue
            bb = obj.find("bndbox")
            rel = img.relative_to(base).as_posix()
            parts = rel.split("/")
            items.append({
                "id": rel, "source": parts[0], "state": parts[1] if len(parts) > 2 else None,
                "plate": (obj.findtext("name") or "").strip().upper().replace(" ", ""),
                "bbox": [int(float(bb.findtext(k, "0"))) for k in ("xmin", "ymin", "xmax", "ymax")] if bb is not None else None,
            })
    _cache["items"] = items
    return items


def stats() -> dict[str, Any]:
    base, items = root(), index()
    n_img = sum(1 for p in base.rglob("*") if p.suffix in IMG_EXT) if base.exists() else 0
    plates = [i["plate"] for i in items]
    return {
        "found": base.exists(), "root": str(base), "images": n_img, "annotated": len(items),
        "unique_plates": len(set(plates)),
        "valid_format_pct": round(100 * sum(bool(PLATE_RE.match(p)) for p in plates) / max(len(plates), 1), 1),
        "by_source": dict(Counter(i["source"] for i in items)),
        "by_state_code": dict(Counter(p[:2] for p in plates if len(p) >= 2).most_common(12)),
    }


def query(page: int, size: int, source: str | None, q: str | None) -> dict[str, Any]:
    rows = [i for i in index() if (not source or i["source"] == source) and (not q or q.upper() in i["plate"])]
    return {"total": len(rows), "page": page, "items": rows[(page - 1) * size: page * size]}


def safe_path(rel: str) -> Path:
    p = (root() / rel).resolve()
    if root() not in p.parents or not p.is_file():
        raise FileNotFoundError(rel)
    return p
