"""FastAPI application factory with lifespan startup/shutdown.

Usage:
    uvicorn backend.app.main:app --reload --port 8000
    # or from inside backend/:
    uvicorn app.main:app --reload --port 8000
"""

from __future__ import annotations

import time
import uuid
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware

from app.api.v1.router import router as v1_router
from app.core.config import get_settings
from app.core.logging import get_logger, setup_logging
from app.models.health import ModelStatus

logger = get_logger(__name__)


# ── Lifespan ──────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Run startup tasks, yield (app is live), then run shutdown tasks."""
    settings = get_settings()
    setup_logging(settings.log_level)

    app.state.start_time = time.time()
    app.state.models_loaded = ModelStatus()
    app.state.startup_errors: list[str] = []

    # ── Model loading (skipped in demo mode or when unavailable) ──
    if not settings.demo_mode:
        _load_models(app, settings)
    else:
        logger.info(
            "Demo mode active — skipping ML model load",
            extra={"context": {"demo_mode": True}},
        )

    logger.info(
        "Application started",
        extra={
            "context": {
                "version": settings.app_version,
                "demo_mode": settings.demo_mode,
                "device": settings.device,
                "seed": settings.demo_seed,
                "models_loaded": app.state.models_loaded.model_dump(),
                "startup_errors": app.state.startup_errors,
            }
        },
    )

    yield  # ── Application is live ──────────────────────────────

    logger.info("Application shutting down")


def _load_models(app: FastAPI, settings) -> None:  # type: ignore[no-untyped-def]
    """Attempt to load ML models; mark degraded on failure."""
    # YOLO11n
    try:
        from ultralytics import YOLO  # type: ignore[import-untyped]

        app.state.yolo_model = YOLO(settings.yolo_model_path)
        app.state.models_loaded.yolo = True
        logger.info("YOLO model loaded", extra={"context": {"path": settings.yolo_model_path}})
    except Exception as exc:
        msg = f"YOLO load failed: {exc}"
        app.state.startup_errors.append(msg)
        logger.warning(msg)

    # EasyOCR
    try:
        import torch  # type: ignore[import-untyped]
        import easyocr  # type: ignore[import-untyped]

        gpu = torch.cuda.is_available()
        if not gpu:
            logger.warning("CUDA unavailable — EasyOCR will use CPU")
        app.state.easyocr_reader = easyocr.Reader(["en"], gpu=gpu, verbose=False)
        app.state.models_loaded.easyocr = True
        logger.info("EasyOCR reader loaded", extra={"context": {"gpu": gpu}})
    except Exception as exc:
        msg = f"EasyOCR load failed: {exc}"
        app.state.startup_errors.append(msg)
        logger.warning(msg)


# ── App factory ───────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    settings = get_settings()

    app = FastAPI(
        title="Vehicle Surveillance Dashboard API",
        version=settings.app_version,
        docs_url="/docs" if settings.debug else None,
        redoc_url="/redoc" if settings.debug else None,
        lifespan=lifespan,
    )

    # ── CORS ──────────────────────────────────────────────────────
    origins = [settings.frontend_url]
    if settings.app_env == "development":
        origins += [
            "http://localhost:5173",
            "http://127.0.0.1:5173",
        ]

    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["X-Request-ID"],
    )

    # ── Request-ID middleware ─────────────────────────────────────
    @app.middleware("http")
    async def attach_request_id(request: Request, call_next) -> Response:  # type: ignore[no-untyped-def]
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id
        response: Response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response

    # ── Routers ───────────────────────────────────────────────────
    app.include_router(v1_router)

    return app


# Module-level app instance for uvicorn
app = create_app()
