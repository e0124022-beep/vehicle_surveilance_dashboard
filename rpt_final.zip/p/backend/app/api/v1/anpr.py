"""POST /api/v1/anpr — run real EasyOCR on an uploaded plate/vehicle image."""
from __future__ import annotations

from fastapi import APIRouter, File, HTTPException, UploadFile

from app.core.config import get_settings
from app.services import ocr

router = APIRouter(tags=["anpr"])


@router.post("/anpr")
def anpr(file: UploadFile = File(...)) -> dict:
    # Plain `def` so FastAPI runs this heavy OCR call in a worker thread
    # and the rest of the API (health check) stays responsive.
    data = file.file.read()
    if len(data) > get_settings().max_upload_bytes:
        raise HTTPException(413, "Image too large")
    try:
        return ocr.read_plate(data)
    except ImportError:
        raise HTTPException(503, "EasyOCR is not installed on the backend (pip install easyocr)")
    except ValueError as e:
        raise HTTPException(422, str(e))
