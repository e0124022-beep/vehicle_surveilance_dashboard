"""GET /api/v1/health and GET /api/v1/config endpoints."""

from __future__ import annotations

import time
from datetime import datetime, timezone

from fastapi import APIRouter, Request

from app.core.config import get_settings
from app.models.health import ConfigResponse, HealthResponse, ModelStatus

router = APIRouter(tags=["system"])


@router.get("/health", response_model=HealthResponse)
async def health_check(request: Request) -> HealthResponse:
    """Return system health status. Must respond within 200 ms."""
    settings = get_settings()
    start_time: float = getattr(request.app.state, "start_time", time.time())
    models_loaded: ModelStatus = getattr(
        request.app.state, "models_loaded", ModelStatus()
    )
    errors: list[str] = getattr(request.app.state, "startup_errors", [])

    status = "degraded" if errors or not (models_loaded.yolo or models_loaded.easyocr) else "ok"
    # In demo mode degraded models are acceptable — report ok
    if settings.demo_mode:
        status = "ok"

    return HealthResponse(
        status=status,
        version=settings.app_version,
        demo_mode=settings.demo_mode,
        uptime_seconds=round(time.time() - start_time, 2),
        models_loaded=models_loaded,
        errors=errors,
        timestamp=datetime.now(timezone.utc),
    )


@router.get("/config", response_model=ConfigResponse)
async def get_config() -> ConfigResponse:
    """Return non-sensitive runtime configuration. Secrets are never exposed."""
    s = get_settings()
    return ConfigResponse(
        demo_mode=s.demo_mode,
        app_env=s.app_env,
        app_version=s.app_version,
        backend_port=s.backend_port,
        frontend_port=s.frontend_port,
        yolo_model_path=s.yolo_model_path,
        yolo_confidence=s.yolo_confidence,
        device=s.device,
        validator_window=s.validator_window,
        validator_min_conf=s.validator_min_conf,
        datasets_root=str(s.datasets_root),
        outputs_root=str(s.outputs_root),
        max_upload_size_mb=s.max_upload_size_mb,
    )
