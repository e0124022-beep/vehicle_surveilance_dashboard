"""Dataset endpoints: stats, paged items, image/crop thumbnails, OCR evaluation results."""
from __future__ import annotations

import json
from pathlib import Path

from fastapi import APIRouter, HTTPException, Query, Response
from fastapi.responses import FileResponse

from app.core.config import get_settings
from app.services import plates

router = APIRouter(tags=["datasets"])


@router.get("/datasets/plates/stats")
def plate_stats() -> dict:
    return plates.stats()


@router.get("/datasets/plates/items")
def plate_items(page: int = Query(1, ge=1), size: int = Query(24, ge=1, le=100), source: str | None = None, q: str | None = None) -> dict:
    return plates.query(page, size, source, q)


@router.get("/datasets/plates/image")
def plate_image(rel: str, w: int = Query(360, ge=64, le=1600), crop: bool = False):
    try:
        path = plates.safe_path(rel)
    except FileNotFoundError:
        raise HTTPException(404, "Image not found")
    try:
        import cv2
    except ImportError:
        return FileResponse(path)
    img = cv2.imread(str(path))
    if img is None:
        raise HTTPException(422, "Unreadable image")
    if crop:
        it = next((i for i in plates.index() if i["id"] == rel and i["bbox"]), None)
        if it:
            x1, y1, x2, y2 = it["bbox"]
            img = img[max(y1 - 6, 0): y2 + 6, max(x1 - 6, 0): x2 + 6]
    if img.shape[1] > w:
        img = cv2.resize(img, (w, max(int(img.shape[0] * w / img.shape[1]), 1)))
    return Response(cv2.imencode(".jpg", img)[1].tobytes(), media_type="image/jpeg")


@router.get("/eval/ocr")
def ocr_eval() -> dict:
    f = Path(get_settings().outputs_root) / "ocr_eval.json"
    if not f.exists():
        raise HTTPException(404, "No evaluation run yet")
    return json.loads(f.read_text())
