"""Application configuration — loaded once from environment / .env file.

All paths and settings are sourced here; no hardcoded values anywhere else.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Central application settings backed by environment variables and .env."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Application ───────────────────────────────────────────────
    app_env: Literal["development", "production", "test"] = "development"
    app_version: str = "0.1.0"
    debug: bool = True
    demo_mode: bool = True
    demo_seed: int = 42
    log_level: str = "INFO"

    # ── Server ────────────────────────────────────────────────────
    backend_host: str = "0.0.0.0"
    backend_port: int = 8000
    frontend_port: int = 5173
    frontend_url: str = "http://localhost:5173"

    # ── Paths (relative to project root or absolute) ──────────────
    datasets_root: Path = Path("../vehicle_surveillance_project/datasets")
    outputs_root: Path = Path("../vehicle_surveillance_project/outputs")
    db_path: Path = Path("surveillance.db")

    # ── Model ─────────────────────────────────────────────────────
    yolo_model_path: str = "yolo11n.pt"
    yolo_confidence: float = Field(default=0.5, ge=0.1, le=0.9)
    device: Literal["auto", "cpu", "cuda"] = "auto"

    # ── Plate Validator ───────────────────────────────────────────
    validator_window: int = Field(default=7, ge=1, le=20)
    validator_min_conf: float = Field(default=0.70, ge=0.0, le=1.0)

    # ── Upload limits ─────────────────────────────────────────────
    max_upload_size_mb: int = 10

    @field_validator("datasets_root", "outputs_root", mode="before")
    @classmethod
    def resolve_path(cls, v: str | Path) -> Path:
        return Path(v)

    @property
    def max_upload_bytes(self) -> int:
        return self.max_upload_size_mb * 1024 * 1024


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return a cached singleton Settings instance."""
    return Settings()
