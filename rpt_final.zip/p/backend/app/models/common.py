"""Shared Pydantic base models and enumerations used across all phases."""

from __future__ import annotations

from enum import Enum
from typing import Generic, TypeVar

from pydantic import BaseModel

T = TypeVar("T")


class ProvenanceEnum(str, Enum):
    """Tag that every metric-bearing response must carry."""

    MEASURED = "MEASURED"
    SIMULATED = "SIMULATED"
    PLACEHOLDER = "PLACEHOLDER"
    DEMO = "DEMO"


class ProvenanceMixin(BaseModel):
    """Mixin that adds a required provenance field."""

    provenance: ProvenanceEnum


class ErrorResponse(BaseModel):
    """Structured error body returned for all non-2xx responses."""

    error: str  # machine-readable code, e.g. "invalid_image"
    detail: str  # human-readable explanation
    request_id: str


class Page(BaseModel, Generic[T]):
    """Generic paginated response wrapper."""

    items: list[T]
    total: int
    page: int
    page_size: int
    pages: int
