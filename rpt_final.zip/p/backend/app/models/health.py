"""Response models for /health and /config endpoints."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel


class ModelStatus(BaseModel):
    """Tracks which ML models loaded successfully at startup."""

    yolo: bool = False
    easyocr: bool = False


class HealthResponse(BaseModel):
    """Response body for GET /api/v1/health."""

    status: Literal["ok", "degraded"]
    version: str
    demo_mode: bool
    uptime_seconds: float
    models_loaded: ModelStatus
    errors: list[str] = []
    timestamp: datetime


class ConfigResponse(BaseModel):
    """Non-sensitive runtime configuration values."""

    demo_mode: bool
    app_env: str
    app_version: str
    backend_port: int
    frontend_port: int
    yolo_model_path: str
    yolo_confidence: float
    device: str
    validator_window: int
    validator_min_conf: float
    datasets_root: str
    outputs_root: str
    max_upload_size_mb: int
