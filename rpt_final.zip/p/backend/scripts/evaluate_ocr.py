"""Measure real OCR accuracy on the annotated Indian plate dataset.

Usage (from backend/, venv active, easyocr installed):
    python -m scripts.evaluate_ocr --n 200
Crops each annotated plate using its XML bounding box, runs the dashboard's OCR pipeline,
compares with the ground-truth plate text, and writes OUTPUTS_ROOT/ocr_eval.json.
"""
from __future__ import annotations

import argparse
import json
import random
import time
from pathlib import Path

import cv2

from app.core.config import get_settings
from app.services import ocr, plates


def lev(a: str, b: str) -> int:
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=200)
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()
    items = [i for i in plates.index() if i["bbox"] and len(i["plate"]) >= 6]
    random.Random(a.seed).shuffle(items)
    items = items[: a.n]
    reader, rows = ocr.get_reader(), []
    for k, it in enumerate(items, 1):
        img = cv2.imread(str(plates.safe_path(it["id"])))
        if img is None:
            continue
        x1, y1, x2, y2 = it["bbox"]
        crop = img[max(y1 - 6, 0): y2 + 6, max(x1 - 6, 0): x2 + 6]
        t = time.time()
        try:
            res = ocr.read_plate(cv2.imencode(".jpg", crop)[1].tobytes(), reader)["best"]
        except Exception:
            continue
        gt, pred = it["plate"], res["plate"]
        rows.append({"id": it["id"], "gt": gt, "pred": pred, "conf": res["conf"], "ms": round((time.time() - t) * 1000),
                     "exact": gt == pred, "char_acc": max(0.0, 1 - lev(gt, pred) / max(len(gt), 1))})
        if k % 20 == 0:
            print(f"{k}/{len(items)}")
    n = max(len(rows), 1)
    out = {"n": len(rows), "seed": a.seed, "exact_match": round(sum(r["exact"] for r in rows) / n, 4),
           "char_accuracy": round(sum(r["char_acc"] for r in rows) / n, 4),
           "avg_latency_ms": round(sum(r["ms"] for r in rows) / n), "failures": [r for r in rows if not r["exact"]][:40]}
    dst = Path(get_settings().outputs_root) / "ocr_eval.json"
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(json.dumps(out, indent=2))
    print(json.dumps({k: v for k, v in out.items() if k != "failures"}, indent=2), "\nSaved", dst)


if __name__ == "__main__":
    main()
