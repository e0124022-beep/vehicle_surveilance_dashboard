"""Shared pytest fixtures."""

from __future__ import annotations

import pytest
from starlette.testclient import TestClient

from app.main import create_app


@pytest.fixture()
def app():
    """Return a fresh application instance for each test."""
    return create_app()


@pytest.fixture()
def client(app):
    """Synchronous ASGI test client (Starlette TestClient)."""
    with TestClient(app, raise_server_exceptions=True) as c:
        yield c
