"""Tests for /api/v1/health and /api/v1/config endpoints."""

from __future__ import annotations


def test_health_returns_200(client):
    response = client.get("/api/v1/health")
    assert response.status_code == 200


def test_health_schema(client):
    data = client.get("/api/v1/health").json()
    assert "status" in data
    assert data["status"] in ("ok", "degraded")
    assert "version" in data
    assert "demo_mode" in data
    assert "uptime_seconds" in data
    assert "models_loaded" in data
    assert "timestamp" in data


def test_health_demo_mode_ok(client):
    """In demo mode health should always report 'ok'."""
    data = client.get("/api/v1/health").json()
    assert data["demo_mode"] is True
    assert data["status"] == "ok"


def test_health_has_request_id_header(client):
    response = client.get("/api/v1/health")
    assert "x-request-id" in response.headers


def test_config_returns_200(client):
    response = client.get("/api/v1/config")
    assert response.status_code == 200


def test_config_no_secrets(client):
    data = client.get("/api/v1/config").json()
    for key in data:
        assert "password" not in key.lower()
        assert "secret" not in key.lower()
        assert "token" not in key.lower()
    assert "demo_mode" in data
    assert "datasets_root" in data
