import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        navy: "var(--color-navy)",
        surface: "var(--color-surface)",
        "surface-2": "var(--color-surface-2)",
        border: "var(--color-border)",
        accent: "var(--color-accent)",
        "accent-dim": "var(--color-accent-dim)",
        authorized: "var(--color-authorized)",
        unknown: "var(--color-unknown)",
        watchlist: "var(--color-watchlist)",
        text: "var(--color-text)",
        muted: "var(--color-muted)",
        "prov-measured": "var(--color-prov-measured)",
        "prov-simulated": "var(--color-prov-simulated)",
        "prov-placeholder": "var(--color-prov-placeholder)",
        "prov-demo": "var(--color-prov-demo)",
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
      },
      borderRadius: {
        card: "8px",
        input: "6px",
      },
    },
  },
  plugins: [],
};

export default config;
