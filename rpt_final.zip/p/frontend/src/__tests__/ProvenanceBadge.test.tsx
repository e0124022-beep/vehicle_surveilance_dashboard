import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { ProvenanceBadge } from "@/components/shared/ProvenanceBadge";

describe("ProvenanceBadge", () => {
  it("renders MEASURED badge", () => {
    render(<ProvenanceBadge provenance="MEASURED" />);
    expect(screen.getByText("MEASURED")).toBeInTheDocument();
  });

  it("renders SIMULATED badge with italic class", () => {
    const { container } = render(<ProvenanceBadge provenance="SIMULATED" />);
    expect(screen.getByText("SIMULATED")).toBeInTheDocument();
    expect(container.firstChild).toHaveClass("italic");
  });

  it("renders PLACEHOLDER badge with dashed border", () => {
    const { container } = render(<ProvenanceBadge provenance="PLACEHOLDER" />);
    expect(screen.getByText("PLACEHOLDER")).toBeInTheDocument();
    expect(container.firstChild).toHaveClass("border-dashed");
  });

  it("renders DEMO badge", () => {
    render(<ProvenanceBadge provenance="DEMO" />);
    expect(screen.getByText("DEMO")).toBeInTheDocument();
  });

  it("has accessible aria-label", () => {
    render(<ProvenanceBadge provenance="MEASURED" />);
    expect(
      screen.getByRole("status", { name: /data provenance: measured/i })
    ).toBeInTheDocument();
  });
});
