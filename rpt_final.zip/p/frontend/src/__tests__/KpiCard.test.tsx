import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { KpiCard } from "@/components/shared/KpiCard";

describe("KpiCard", () => {
  it("renders value", () => {
    render(<KpiCard title="Vehicles" value={42} provenance="MEASURED" />);
    expect(screen.getByText("42")).toBeInTheDocument();
  });

  it("renders unit", () => {
    render(
      <KpiCard title="FPS" value={30} unit="fps" provenance="MEASURED" />
    );
    expect(screen.getByText("fps")).toBeInTheDocument();
  });

  it("renders skeleton when loading", () => {
    const { container } = render(
      <KpiCard title="X" value={0} provenance="PLACEHOLDER" loading />
    );
    // Value should NOT be in DOM during loading
    expect(container.querySelector(".animate-pulse")).toBeTruthy();
    expect(screen.queryByText("0")).not.toBeInTheDocument();
  });

  it("positive delta renders green arrow", () => {
    const { container } = render(
      <KpiCard title="X" value={5} provenance="MEASURED" delta={3} />
    );
    // ArrowUp SVG should be present
    expect(container.querySelector("svg")).toBeTruthy();
    expect(screen.getByText("3")).toBeInTheDocument();
  });
});
