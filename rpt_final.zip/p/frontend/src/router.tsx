import { createBrowserRouter } from "react-router-dom";
import { ShellLayout } from "@/components/layout/ShellLayout";
import Overview from "@/pages/Overview";
import AnprLab from "@/pages/AnprLab";
import ValidationSimulator from "@/pages/ValidationSimulator";
import DatasetExplorer from "@/pages/DatasetExplorer";
import Watchlist from "@/pages/Watchlist";
import Alerts from "@/pages/Alerts";
import Evaluation from "@/pages/Evaluation";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <ShellLayout />,
    children: [
      { index: true, element: <Overview /> },
      { path: "anpr", element: <AnprLab /> },
      { path: "validation", element: <ValidationSimulator /> },
      { path: "datasets", element: <DatasetExplorer /> },
      { path: "watchlist", element: <Watchlist /> },
      { path: "alerts", element: <Alerts /> },
      { path: "evaluation", element: <Evaluation /> },
    ],
  },
]);
