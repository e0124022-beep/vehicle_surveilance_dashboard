import axios from "axios";

const API_BASE = import.meta.env.VITE_API_URL ?? "http://localhost:8000";

export const api = axios.create({
  baseURL: API_BASE,
  headers: { "Content-Type": "application/json" },
  timeout: 30_000,
});

// Attach request-ID echo for debugging
api.interceptors.response.use(
  (res) => res,
  (err) => {
    const requestId = err.response?.headers?.["x-request-id"] ?? "unknown";
    const detail =
      err.response?.data?.detail ?? err.response?.data?.error ?? err.message;
    const enhanced = new Error(`[${requestId}] ${detail}`);
    return Promise.reject(enhanced);
  }
);
