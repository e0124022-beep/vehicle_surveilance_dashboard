export type Status = "authorized" | "unknown" | "watchlist";
export const card = "rounded-xl border border-white/10 bg-surface p-4";
export const ACCENT = "#22D3EE";
export const COLORS: Record<Status, string> = { authorized: "#22C55E", unknown: "#F59E0B", watchlist: "#EF4444" };
export function rng(seed: number) {
  return () => {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export const PLATE_RE = /^([A-Z]{2})(\d{1,2})([A-Z]{1,3})(\d{1,4})$/;
const STATES: Record<string, string> = { TN: "Tamil Nadu", KA: "Karnataka", MH: "Maharashtra", DL: "Delhi", KL: "Kerala", AP: "Andhra Pradesh" };
export function parsePlate(p: string) {
  const m = PLATE_RE.exec(p);
  return m ? { state: STATES[m[1]] ?? m[1], rto: m[2], series: m[3], number: m[4] } : null;
}
export type Vehicle = { plate: string; status: Status; desc: string };
export const SEED_VEHICLES: Vehicle[] = [
  { plate: "TN01AB1234", status: "authorized", desc: "Staff vehicle" },
  { plate: "TN02CD5678", status: "authorized", desc: "Visitor pass" },
  { plate: "TN03EF9012", status: "watchlist", desc: "Reported suspicious" },
];
export const classify = (p: string, db: Vehicle[] = SEED_VEHICLES): Status => db.find((v) => v.plate === p)?.status ?? "unknown";

export type Alert = { id: number; time: string; plate: string; track: number; status: Status; latency: number; sms: string };
export const ALERTS: Alert[] = (() => {
  const r = rng(42), pool = ["TN03EF9012", "TN09XY4521", "KA05MN7788", "TN03EF9012", "MH12GH3344", "TN22PQ1010"];
  return Array.from({ length: 24 }, (_, i) => {
    const plate = pool[Math.floor(r() * pool.length)], status = classify(plate);
    const d = new Date(2026, 9, 25, 8 + Math.floor(i / 3), Math.floor(r() * 60));
    return { id: i + 1, time: d.toISOString().slice(0, 16).replace("T", " "), plate, track: 100 + i, status, latency: Math.round(180 + r() * 420),
      sms: `[SIMULATED] ALERT: ${status.toUpperCase()} vehicle ${plate} seen on cam-01 (track ${100 + i}).` };
  }).filter((a) => a.status !== "authorized");
})();

export function simulate(window: number, minConf: number, pErr: number, tracks: number, seed: number) {
  const r = rng(seed), alpha = "ABCDEFGHJKLMNPRSTUVWXYZ";
  const truth = ["TN01AB1234", "TN02CD5678", "TN03EF9012"];
  const out = [] as { track: number; truth: string; final: string; ok: boolean; rows: { frame: number; read: string; conf: number; accepted: boolean; leader: string; votes: number }[] }[];
  for (let t = 0; t < tracks; t++) {
    const tp = truth[t % truth.length], buf: string[] = [], rows = [];
    for (let f = 1; f <= window + 3; f++) {
      const bad = r() < pErr;
      const chars = tp.split(""); if (bad) chars[Math.floor(r() * chars.length)] = alpha[Math.floor(r() * alpha.length)];
      const read = chars.join(""), conf = bad ? 0.3 + r() * 0.6 : 0.72 + r() * 0.26, accepted = conf >= minConf;
      if (accepted) { buf.push(read); if (buf.length > window) buf.shift(); }
      const cnt: Record<string, number> = {}; buf.forEach((b) => (cnt[b] = (cnt[b] ?? 0) + 1));
      const [leader, votes] = Object.entries(cnt).sort((a, b) => b[1] - a[1])[0] ?? ["—", 0];
      rows.push({ frame: f, read, conf, accepted, leader, votes });
    }
    const last = rows[rows.length - 1], final = last.votes > window / 2 ? last.leader : "NO CONSENSUS";
    out.push({ track: t + 1, truth: tp, final, ok: final === tp, rows });
  }
  return out;
}
export function monteCarlo(pErr: number, seed: number, trials = 4000) {
  const r = rng(seed);
  return [1, 3, 5, 7, 9].map((n) => {
    let wrong = 0;
    for (let i = 0; i < trials; i++) { let e = 0; for (let k = 0; k < n; k++) if (r() < pErr) e++; if (e > n / 2) wrong++; }
    const p = wrong / trials, ci = 1.96 * Math.sqrt((p * (1 - p)) / trials);
    return { window: `${n}-frame`, rate: +(p * 100).toFixed(2), ci: +(ci * 100).toFixed(2) };
  });
}
