import { NavLink } from "react-router-dom";
import { LayoutDashboard, ScanLine, GitCompare, Database, Shield, Bell, BarChart2, Lock } from "lucide-react";
import { cn } from "@/lib/utils";

interface NavItem {
  to: string;
  label: string;
  icon: React.ReactNode;
}

const NAV_ITEMS: NavItem[] = [
  { to: "/", label: "Overview", icon: <LayoutDashboard size={18} /> },
  { to: "/anpr", label: "ANPR Lab", icon: <ScanLine size={18} /> },
  { to: "/validation", label: "Validation Simulator", icon: <GitCompare size={18} /> },
  { to: "/datasets", label: "Dataset Explorer", icon: <Database size={18} /> },
  { to: "/watchlist", label: "Watchlist", icon: <Shield size={18} /> },
  { to: "/alerts", label: "Alerts", icon: <Bell size={18} /> },
  { to: "/evaluation", label: "Evaluation", icon: <BarChart2 size={18} /> },
];

export function Sidebar() {
  return (
    <aside className="flex h-screen w-56 shrink-0 flex-col border-r border-border bg-surface">
      <div className="flex h-14 items-center gap-2 px-4 border-b border-border">
        <Lock size={18} className="text-accent" />
        <span className="text-sm font-semibold text-text tracking-wide">VehicleSurv</span>
      </div>
      <nav className="flex-1 overflow-y-auto py-3" aria-label="Main navigation">
        <ul className="flex flex-col gap-0.5 px-2">
          {NAV_ITEMS.map((item) => (
            <li key={item.to}>
              <NavLink
                to={item.to}
                end={item.to === "/"}
                className={({ isActive }) =>
                  cn(
                    "group flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
                    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent",
                    isActive ? "bg-accent/10 text-accent" : "text-muted hover:bg-surface-2 hover:text-text"
                  )
                }
              >
                {item.icon}
                <span className="flex-1 min-w-0 truncate">{item.label}</span>
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
}
