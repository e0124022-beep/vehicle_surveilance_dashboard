import { useEffect, useState } from "react";
import { Moon, Sun, Wifi, WifiOff } from "lucide-react";
import { cn } from "@/lib/utils";
import { useHealth } from "@/hooks/useHealth";
import { useToast } from "@/components/ui/toast";

export function TopBar() {
  const { data: health, isError } = useHealth();
  const { toast } = useToast();
  const [isDark, setIsDark] = useState(true);

  // Initialise theme from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("theme");
    if (saved === "light") {
      document.documentElement.classList.add("light");
      setIsDark(false);
    }
  }, []);

  // Toast on backend error
  useEffect(() => {
    if (isError) {
      /* frontend-only demo: no toast when backend is offline */
    }
  }, [isError, toast]);

  // Toast on degraded
  useEffect(() => {
    if (health?.status === "degraded") {
      toast({
        title: "System degraded",
        description: health.errors?.join(", ") ?? "Some models failed to load.",
        variant: "warning",
      });
    }
  }, [health?.status, health?.errors, toast]);

  const toggleTheme = () => {
    const next = !isDark;
    setIsDark(next);
    if (next) {
      document.documentElement.classList.remove("light");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.add("light");
      localStorage.setItem("theme", "light");
    }
  };

  // Status badge
  const statusOk = !isError && health?.status === "ok";
  const statusDegraded = !isError && health?.status === "degraded";

  return (
    <header className="flex h-14 shrink-0 items-center justify-between border-b border-border bg-surface px-4">
      {/* Left: app name */}
      <h1 className="text-sm font-semibold text-text">
        Deep Learning Vehicle Surveillance
      </h1>

      {/* Right: badges + toggle */}
      <div className="flex items-center gap-3">

        {/* System status badge */}
        <span
          className={cn(
            "flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium",
            statusOk
              ? "bg-authorized/10 text-authorized"
              : statusDegraded
              ? "bg-unknown/10 text-unknown"
              : "bg-unknown/10 text-unknown"
          )}
          aria-label={`System status: ${statusOk ? "OK" : statusDegraded ? "Degraded" : "Unreachable"}`}
        >
          {statusOk ? (
            <Wifi size={12} aria-hidden />
          ) : (
            <WifiOff size={12} aria-hidden />
          )}
          {statusOk ? "OK" : statusDegraded ? "Degraded" : "Offline"}
        </span>

        {/* Light/dark toggle */}
        <button
          onClick={toggleTheme}
          className="rounded-md p-1.5 text-muted hover:text-text hover:bg-surface-2 transition-colors focus-visible:outline-accent"
          aria-label={isDark ? "Switch to light theme" : "Switch to dark theme"}
        >
          {isDark ? <Sun size={16} /> : <Moon size={16} />}
        </button>
      </div>
    </header>
  );
}
