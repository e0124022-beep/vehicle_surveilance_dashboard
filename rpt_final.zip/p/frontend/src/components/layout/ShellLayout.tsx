import { Outlet } from "react-router-dom";
import { Sidebar } from "./Sidebar";
import { TopBar } from "./TopBar";
import { ErrorBoundary } from "./ErrorBoundary";
import { PlaceholderProvider } from "@/components/shared/PlaceholderBanner";

export function ShellLayout() {
  return (
    <PlaceholderProvider>
      <div className="flex h-screen overflow-hidden bg-navy text-text">
        <Sidebar />
        <div className="flex flex-1 flex-col overflow-hidden">
          <TopBar />
          <main
            className="flex-1 overflow-y-auto"
            id="main-content"
            tabIndex={-1}
          >
            <ErrorBoundary>
              <Outlet />
            </ErrorBoundary>
          </main>
        </div>
      </div>
    </PlaceholderProvider>
  );
}
