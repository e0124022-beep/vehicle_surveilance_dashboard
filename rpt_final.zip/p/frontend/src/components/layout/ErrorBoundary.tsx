import React from "react";
import { AlertTriangle } from "lucide-react";

interface Props {
  children: React.ReactNode;
}

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, message: "" };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error("[ErrorBoundary]", error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center h-full gap-6 py-24 text-center px-8">
          <AlertTriangle
            size={48}
            className="text-watchlist opacity-70"
            aria-hidden
          />
          <div className="space-y-2 max-w-md">
            <h2 className="text-xl font-semibold text-text">
              Something went wrong
            </h2>
            <p className="text-sm text-muted">
              An unexpected error occurred in this panel.
            </p>
            {this.state.message && (
              <pre className="mt-2 text-xs text-watchlist bg-watchlist/10 rounded-card p-3 text-left overflow-auto">
                {this.state.message}
              </pre>
            )}
          </div>
          <button
            onClick={() => window.location.reload()}
            className="rounded-input border border-accent px-5 py-2 text-sm font-medium text-accent hover:bg-accent/10 transition-colors focus-visible:outline-accent"
          >
            Reload page
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
