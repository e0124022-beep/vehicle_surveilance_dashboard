/**
 * Minimal toast system using React context + a fixed overlay.
 * Usage:
 *   const { toast } = useToast();
 *   toast({ title: "Saved!", description: "Changes persisted." });
 */

import React, {
  createContext,
  useCallback,
  useContext,
  useState,
} from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

type ToastVariant = "default" | "success" | "error" | "warning";

interface ToastItem {
  id: string;
  title: string;
  description?: string;
  variant?: ToastVariant;
}

interface ToastContextValue {
  toast: (opts: Omit<ToastItem, "id">) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const toast = useCallback((opts: Omit<ToastItem, "id">) => {
    const id = Math.random().toString(36).slice(2);
    setToasts((prev) => [...prev, { id, ...opts }]);
    setTimeout(
      () => setToasts((prev) => prev.filter((t) => t.id !== id)),
      4000
    );
  }, []);

  const dismiss = (id: string) =>
    setToasts((prev) => prev.filter((t) => t.id !== id));

  const variantClass: Record<ToastVariant, string> = {
    default: "border-border bg-surface",
    success: "border-authorized bg-surface text-authorized",
    error: "border-watchlist bg-surface text-watchlist",
    warning: "border-unknown bg-surface text-unknown",
  };

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      {/* Toast overlay */}
      <div
        className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 w-80"
        aria-live="polite"
      >
        {toasts.map((t) => (
          <div
            key={t.id}
            role="alert"
            className={cn(
              "flex items-start justify-between gap-3 rounded-card border p-4 shadow-lg",
              variantClass[t.variant ?? "default"]
            )}
          >
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-text">{t.title}</p>
              {t.description && (
                <p className="text-xs text-muted mt-0.5">{t.description}</p>
              )}
            </div>
            <button
              onClick={() => dismiss(t.id)}
              className="text-muted hover:text-text transition-colors"
              aria-label="Dismiss"
            >
              <X size={14} />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast(): ToastContextValue {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used within ToastProvider");
  return ctx;
}
