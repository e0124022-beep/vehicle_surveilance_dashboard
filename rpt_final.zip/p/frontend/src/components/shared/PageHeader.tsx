import { ProvenanceBadge, type Provenance } from "./ProvenanceBadge";
export function PageHeader({ title, subtitle, provenance = "DEMO" }: { title: string; subtitle: string; provenance?: Provenance }) {
  return (
    <div className="mb-6 flex items-start justify-between gap-4">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
        <p className="mt-1 max-w-3xl text-sm text-muted">{subtitle}</p>
      </div>
      <ProvenanceBadge provenance={provenance} />
    </div>
  );
}
