import React, { useRef } from "react";
import { Download } from "lucide-react";
import { cn } from "@/lib/utils";
import { ProvenanceBadge, type Provenance } from "./ProvenanceBadge";
import { slugify } from "@/lib/utils";

interface ChartCardProps {
  title: string;
  provenance: Provenance;
  description?: string;
  exportFileName?: string;
  className?: string;
  children: React.ReactNode;
}

export function ChartCard({
  title,
  provenance,
  description,
  exportFileName,
  className,
  children,
}: ChartCardProps) {
  const chartRef = useRef<HTMLDivElement>(null);

  const handleExport = async () => {
    if (!chartRef.current) return;
    try {
      // Use html2canvas if available; fall back to a graceful no-op
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const html2canvas = (await import("html2canvas" as any).catch(() => null)) as any;
      if (!html2canvas) {
        alert("Export requires html2canvas. Install it with: npm install html2canvas");
        return;
      }
      const canvas = await html2canvas.default(chartRef.current, {
        backgroundColor: "#111A2E",
      });
      const link = document.createElement("a");
      link.download = exportFileName
        ? exportFileName
        : `${slugify(title)}-${Date.now()}.png`;
      link.href = canvas.toDataURL("image/png");
      link.click();
    } catch {
      // Silent — export is a non-critical feature
    }
  };

  return (
    <div
      className={cn(
        "rounded-card bg-surface border border-border p-4 flex flex-col gap-3",
        className
      )}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-2">
        <div>
          <h3 className="text-sm font-medium uppercase tracking-wide text-muted">
            {title}
          </h3>
          {description && (
            <p className="text-xs text-muted mt-0.5">{description}</p>
          )}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <ProvenanceBadge provenance={provenance} size="sm" />
          <button
            onClick={handleExport}
            className="text-muted hover:text-accent transition-colors rounded p-1 focus-visible:outline-accent"
            aria-label={`Export ${title} as PNG`}
            title="Export as PNG"
          >
            <Download size={14} />
          </button>
        </div>
      </div>

      {/* Chart area */}
      <div ref={chartRef} className="w-full">
        {children}
      </div>
    </div>
  );
}
