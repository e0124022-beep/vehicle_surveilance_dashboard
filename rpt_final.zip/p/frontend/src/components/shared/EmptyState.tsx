import React from "react";
import { cn } from "@/lib/utils";

interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description: string;
  action?: {
    label: string;
    onClick: () => void;
  };
  className?: string;
}

export function EmptyState({
  icon,
  title,
  description,
  action,
  className,
}: EmptyStateProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center gap-4 py-16 px-8 text-center",
        className
      )}
    >
      {icon && (
        <div className="text-muted opacity-50 [&>svg]:h-12 [&>svg]:w-12">
          {icon}
        </div>
      )}
      <div className="space-y-1.5 max-w-sm">
        <h3 className="text-lg font-medium text-text">{title}</h3>
        <p className="text-sm text-muted">{description}</p>
      </div>
      {action && (
        <button
          onClick={action.onClick}
          className="mt-2 rounded-input border border-accent px-4 py-2 text-sm font-medium text-accent hover:bg-accent/10 transition-colors focus-visible:outline-accent"
        >
          {action.label}
        </button>
      )}
    </div>
  );
}
