import React from "react";
import { ArrowDown, ArrowUp, Minus } from "lucide-react";
import { cn } from "@/lib/utils";
import { ProvenanceBadge, type Provenance } from "./ProvenanceBadge";
import { Skeleton } from "@/components/ui/skeleton";

interface KpiCardProps {
  title: string;
  value: string | number;
  unit?: string;
  delta?: number;
  provenance: Provenance;
  loading?: boolean;
  icon?: React.ReactNode;
  className?: string;
}

export function KpiCard({
  title,
  value,
  unit,
  delta,
  provenance,
  loading = false,
  icon,
  className,
}: KpiCardProps) {
  if (loading) {
    return (
      <div
        className={cn(
          "rounded-card bg-surface border border-border p-4 flex flex-col gap-3",
          className
        )}
        aria-busy="true"
      >
        <Skeleton className="h-3 w-24" />
        <Skeleton className="h-8 w-32" />
        <Skeleton className="h-4 w-16" />
      </div>
    );
  }

  const deltaIcon =
    delta == null ? null : delta > 0 ? (
      <ArrowUp size={12} className="text-authorized" />
    ) : delta < 0 ? (
      <ArrowDown size={12} className="text-watchlist" />
    ) : (
      <Minus size={12} className="text-muted" />
    );

  const deltaClass =
    delta == null
      ? ""
      : delta > 0
      ? "text-authorized"
      : delta < 0
      ? "text-watchlist"
      : "text-muted";

  return (
    <div
      className={cn(
        "rounded-card bg-surface border border-border p-4 flex flex-col gap-2",
        className
      )}
    >
      {/* Header row */}
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-medium uppercase tracking-wide text-muted">
          {title}
        </span>
        {icon && <span className="text-muted">{icon}</span>}
      </div>

      {/* Value */}
      <div className="flex items-end gap-1.5">
        <span className="text-3xl font-bold tabular-nums text-text">
          {value}
        </span>
        {unit && <span className="text-sm text-muted mb-0.5">{unit}</span>}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between">
        <ProvenanceBadge provenance={provenance} size="sm" />
        {delta != null && (
          <span
            className={cn("flex items-center gap-0.5 text-xs", deltaClass)}
          >
            {deltaIcon}
            {Math.abs(delta)}
          </span>
        )}
      </div>
    </div>
  );
}
