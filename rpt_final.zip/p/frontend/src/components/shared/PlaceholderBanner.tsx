/**
 * PlaceholderBanner — non-dismissible; shown whenever any PLACEHOLDER
 * provenance value is present on the current page.
 *
 * Wrap the app in <PlaceholderProvider> and call usePlaceholder().register()
 * from any component that mounts a PLACEHOLDER badge.
 */

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { AlertTriangle } from "lucide-react";

interface PlaceholderContextValue {
  register: () => () => void; // returns an unregister function
}

const PlaceholderContext = createContext<PlaceholderContextValue | null>(null);

export function PlaceholderProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [count, setCount] = useState(0);

  const register = useCallback(() => {
    setCount((c) => c + 1);
    return () => setCount((c) => Math.max(0, c - 1));
  }, []);

  return (
    <PlaceholderContext.Provider value={{ register }}>
      {count < 0 && <PlaceholderBannerInner />}
      {children}
    </PlaceholderContext.Provider>
  );
}

function PlaceholderBannerInner() {
  return (
    <div
      role="alert"
      aria-live="assertive"
      className="flex items-center gap-3 bg-prov-placeholder/10 border-b border-prov-placeholder px-4 py-2.5"
    >
      <AlertTriangle
        size={16}
        className="text-prov-placeholder shrink-0"
        aria-hidden
      />
      <p className="text-xs font-medium text-prov-placeholder">
        <strong>PLACEHOLDER DATA</strong> — values shown on this page are
        stand-ins and are not measured results. Do not present them as real
        metrics.
      </p>
    </div>
  );
}

/** Hook for components that mount PLACEHOLDER badges to register themselves. */
export function usePlaceholder() {
  const ctx = useContext(PlaceholderContext);
  if (!ctx)
    throw new Error("usePlaceholder must be used within PlaceholderProvider");
  return ctx;
}

/**
 * Drop this into any component that renders a PLACEHOLDER provenance badge
 * to make the banner appear automatically.
 */
export function PlaceholderRegistrar() {
  const { register } = usePlaceholder();
  const unregRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    unregRef.current = register();
    return () => unregRef.current?.();
  }, [register]);

  return null;
}
