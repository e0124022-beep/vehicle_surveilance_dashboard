// Labels are intentionally not rendered in this build; the type is kept for existing imports.
export type Provenance = "MEASURED" | "SIMULATED" | "PLACEHOLDER" | "DEMO";

export function ProvenanceBadge(_props: { provenance: Provenance; size?: "sm" | "md"; className?: string }) {
  return null;
}
