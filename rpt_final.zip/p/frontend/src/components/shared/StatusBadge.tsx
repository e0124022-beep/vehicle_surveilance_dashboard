import { cn } from "@/lib/utils";

export type VehicleStatus = "authorized" | "unknown" | "watchlist";

interface StatusBadgeProps {
  status: VehicleStatus;
  showLabel?: boolean;
  size?: "sm" | "md";
  className?: string;
}

const CONFIG: Record<VehicleStatus, { label: string; dot: string; text: string }> = {
  authorized: {
    label: "Authorized",
    dot: "bg-authorized",
    text: "text-authorized",
  },
  unknown: {
    label: "Unknown",
    dot: "bg-unknown",
    text: "text-unknown",
  },
  watchlist: {
    label: "Watchlist",
    dot: "bg-watchlist animate-pulse",
    text: "text-watchlist",
  },
};

export function StatusBadge({
  status,
  showLabel = true,
  size = "sm",
  className,
}: StatusBadgeProps) {
  const { label, dot, text } = CONFIG[status];

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border font-medium",
        size === "sm"
          ? "px-2 py-0.5 text-xs border-border"
          : "px-3 py-1 text-sm border-border",
        className
      )}
      aria-label={`Status: ${label}`}
    >
      <span className={cn("rounded-full shrink-0", dot, size === "sm" ? "h-1.5 w-1.5" : "h-2 w-2")} />
      {showLabel && <span className={cn(text)}>{label}</span>}
    </span>
  );
}
