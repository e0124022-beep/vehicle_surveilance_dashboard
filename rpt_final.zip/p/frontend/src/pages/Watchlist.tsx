import { useState } from "react";
import { Trash2 } from "lucide-react";
import { PageHeader } from "@/components/shared/PageHeader";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { PLATE_RE, SEED_VEHICLES, Status, Vehicle, card } from "@/lib/demo";

export default function Watchlist() {
  const [rows, setRows] = useState<Vehicle[]>(SEED_VEHICLES), [plate, setPlate] = useState(""), [status, setStatus] = useState<Status>("authorized"), [desc, setDesc] = useState(""), [err, setErr] = useState("");
  const add = () => {
    const p = plate.trim().toUpperCase();
    if (!PLATE_RE.test(p)) return setErr("Invalid Indian plate format (e.g. TN01AB1234)");
    if (rows.some((r) => r.plate === p)) return setErr("Plate already exists");
    setRows([...rows, { plate: p, status, desc }]); setPlate(""); setDesc(""); setErr("");
  };
  const csv = () => { const b = new Blob(["plate,status,description\n" + rows.map((r) => `${r.plate},${r.status},${r.desc}`).join("\n")], { type: "text/csv" }); const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = "vehicles.csv"; a.click(); };
  const inp = "rounded bg-white/10 px-3 py-1.5 text-sm outline-none focus:ring-1 focus:ring-[#22D3EE]";
  return (
    <div>
      <PageHeader title="Watchlist" subtitle="Vehicle database used to classify validated plates as authorized, unknown or watchlist. Changes are kept in the browser session and can be exported as CSV." />
      <div className={`${card} mb-4 flex flex-wrap items-center gap-2`}>
        <input className={inp} placeholder="TN01AB1234" value={plate} onChange={(e) => setPlate(e.target.value)} />
        <select className={inp} value={status} onChange={(e) => setStatus(e.target.value as Status)}><option value="authorized">authorized</option><option value="watchlist">watchlist</option></select>
        <input className={`${inp} flex-1`} placeholder="Description" value={desc} onChange={(e) => setDesc(e.target.value)} />
        <button onClick={add} className="rounded-lg bg-[#22D3EE] px-4 py-1.5 text-sm font-medium text-black">Add</button>
        <button onClick={csv} className="rounded-lg bg-white/10 px-4 py-1.5 text-sm">Export CSV</button>
        {err && <div className="w-full text-xs text-red-400">{err}</div>}
      </div>
      <div className={card}><table className="w-full text-sm"><thead className="text-left text-xs text-muted"><tr><th className="pb-2">Plate</th><th>Status</th><th>Description</th><th /></tr></thead><tbody>
        {rows.map((r) => <tr key={r.plate} className="border-t border-white/5"><td className="py-2 font-mono">{r.plate}</td><td><StatusBadge status={r.status} /></td><td>{r.desc}</td>
          <td className="text-right"><button aria-label="delete" onClick={() => setRows(rows.filter((x) => x.plate !== r.plate))}><Trash2 size={15} className="text-muted hover:text-red-400" /></button></td></tr>)}
      </tbody></table></div>
    </div>
  );
}
