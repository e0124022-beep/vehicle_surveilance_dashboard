import { useState } from "react";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ChartCard } from "@/components/shared/ChartCard";
import { PageHeader } from "@/components/shared/PageHeader";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { ALERTS, card } from "@/lib/demo";

export default function Alerts() {
  const [f, setF] = useState("all"), [q, setQ] = useState("");
  const rows = ALERTS.filter((a) => (f === "all" || a.status === f) && a.plate.includes(q.toUpperCase()));
  const byHour = Object.entries(ALERTS.reduce<Record<string, number>>((m, a) => ((m[a.time.slice(11, 13) + ":00"] = (m[a.time.slice(11, 13) + ":00"] ?? 0) + 1), m), {})).map(([hour, count]) => ({ hour, count })).sort((a, b) => a.hour.localeCompare(b.hour));
  return (
    <div>
      <PageHeader title="Alerts" subtitle="Alerts raised for watchlist and unrecognised plates. SMS notifications are logged only; no message is ever sent." provenance="SIMULATED" />
      <ChartCard title="Alerts per hour" provenance="SIMULATED"><div className="h-48"><ResponsiveContainer><AreaChart data={byHour}><CartesianGrid stroke="#ffffff14" /><XAxis dataKey="hour" stroke="#94a3b8" /><YAxis stroke="#94a3b8" allowDecimals={false} />
        <Tooltip contentStyle={{ background: "#111A2E", border: "1px solid #ffffff22" }} /><Area dataKey="count" stroke="#22D3EE" fill="#22D3EE33" /></AreaChart></ResponsiveContainer></div></ChartCard>
      <div className={`${card} mt-4`}>
        <div className="mb-3 flex gap-2 text-sm">
          <select className="rounded bg-white/10 px-2 py-1" value={f} onChange={(e) => setF(e.target.value)}><option value="all">All statuses</option><option value="watchlist">Watchlist</option><option value="unknown">Unknown</option></select>
          <input className="rounded bg-white/10 px-3 py-1" placeholder="Search plate" value={q} onChange={(e) => setQ(e.target.value)} />
          <span className="ml-auto text-xs text-muted">{rows.length} alerts</span>
        </div>
        <table className="w-full text-sm"><thead className="text-left text-xs text-muted"><tr><th className="pb-2">Time</th><th>Plate</th><th>Track</th><th>Status</th><th>Latency</th><th>SMS message (logged)</th></tr></thead><tbody>
          {rows.map((a) => <tr key={a.id} className="border-t border-white/5"><td className="py-2">{a.time}</td><td className="font-mono">{a.plate}</td><td>#{a.track}</td><td><StatusBadge status={a.status} /></td><td>{a.latency} ms</td><td className="max-w-xs truncate text-xs text-muted">{a.sms}</td></tr>)}
        </tbody></table>
      </div>
    </div>
  );
}
