import { useMemo, useState } from "react";
import { Bar, BarChart, CartesianGrid, ErrorBar, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ChartCard } from "@/components/shared/ChartCard";
import { PageHeader } from "@/components/shared/PageHeader";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { card, classify, monteCarlo, simulate } from "@/lib/demo";

function Slider({ label, v, set, min, max, step }: { label: string; v: number; set: (n: number) => void; min: number; max: number; step: number }) {
  return (<label className="block text-xs text-muted">{label}: <b className="text-white">{v}</b>
    <input type="range" className="mt-1 w-full accent-[#22D3EE]" min={min} max={max} step={step} value={v} onChange={(e) => set(+e.target.value)} /></label>);
}
export default function ValidationSimulator() {
  const [w, setW] = useState(7), [mc, setMc] = useState(0.7), [pe, setPe] = useState(0.12), [n, setN] = useState(6), [seed, setSeed] = useState(42);
  const sim = useMemo(() => simulate(w, mc, pe, n, seed), [w, mc, pe, n, seed]);
  const mcs = useMemo(() => monteCarlo(pe, seed), [pe, seed]);
  const [sel, setSel] = useState(0), t = sim[Math.min(sel, sim.length - 1)];
  return (
    <div>
      <PageHeader provenance="SIMULATED" title="Multi-Frame Validation Simulator" subtitle="Majority-vote plate validation over a sliding window. Low-confidence readings are rejected before voting; a plate is validated only when its votes exceed half the window." />
      <div className={`${card} grid gap-4 sm:grid-cols-2 lg:grid-cols-5`}>
        <Slider label="Window size" v={w} set={setW} min={3} max={15} step={2} />
        <Slider label="Min confidence" v={mc} set={setMc} min={0.3} max={0.95} step={0.05} />
        <Slider label="OCR error probability" v={pe} set={setPe} min={0} max={0.6} step={0.02} />
        <Slider label="Tracks" v={n} set={setN} min={1} max={12} step={1} />
        <Slider label="Seed" v={seed} set={setSeed} min={1} max={99} step={1} />
      </div>
      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <ChartCard title="False-decision rate: single vs N-frame majority (%, 95% CI)" provenance="SIMULATED" exportFileName="validation.png">
          <div className="h-72"><ResponsiveContainer><BarChart data={mcs}>
            <CartesianGrid stroke="#ffffff14" /><XAxis dataKey="window" stroke="#94a3b8" /><YAxis stroke="#94a3b8" unit="%" />
            <Tooltip contentStyle={{ background: "#111A2E", border: "1px solid #ffffff22" }} />
            <Bar dataKey="rate" fill="#22D3EE" radius={[4, 4, 0, 0]}><ErrorBar dataKey="ci" stroke="#fff" /></Bar>
          </BarChart></ResponsiveContainer></div>
        </ChartCard>
        <div className={card}>
          <div className="mb-2 text-sm font-medium">Per-track result</div>
          <table className="w-full text-sm"><thead className="text-left text-xs text-muted"><tr><th>Track</th><th>True</th><th>Validated</th><th>DB</th><th /></tr></thead><tbody>
            {sim.map((s, i) => <tr key={s.track} onClick={() => setSel(i)} className={`cursor-pointer border-t border-white/5 ${i === sel ? "bg-white/5" : ""}`}>
              <td className="py-1.5">#{s.track}</td><td className="font-mono">{s.truth}</td><td className="font-mono">{s.final}</td>
              <td>{s.ok ? <StatusBadge status={classify(s.final)} /> : <span className="text-xs text-red-400">—</span>}</td><td>{s.ok ? "✓" : "✗"}</td></tr>)}
          </tbody></table>
        </div>
      </div>
      <div className={`${card} mt-4`}>
        <div className="mb-2 text-sm font-medium">Frame-by-frame votes — track #{t.track}</div>
        <table className="w-full text-sm"><thead className="text-left text-xs text-muted"><tr><th>Frame</th><th>OCR reading</th><th>Conf.</th><th>Accepted</th><th>Leader</th><th>Votes</th></tr></thead><tbody>
          {t.rows.map((r) => <tr key={r.frame} className={`border-t border-white/5 ${r.accepted ? "" : "bg-red-500/10 text-red-300"}`}>
            <td className="py-1.5">{r.frame}</td><td className="font-mono">{r.read}</td><td>{r.conf.toFixed(2)}</td><td>{r.accepted ? "yes" : "rejected"}</td><td className="font-mono">{r.leader}</td><td>{r.votes}/{w}</td></tr>)}
        </tbody></table>
      </div>
    </div>
  );
}
