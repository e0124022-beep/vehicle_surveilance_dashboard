import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ChartCard } from "@/components/shared/ChartCard";
import { KpiCard } from "@/components/shared/KpiCard";
import { PageHeader } from "@/components/shared/PageHeader";
import { card, rng } from "@/lib/demo";

const r = rng(7);
const perFrame = Array.from({ length: 60 }, (_, i) => ({ frame: i + 1, vehicles: Math.round(8 + 4 * Math.sin(i / 6) + r() * 3) }));
const classes = [{ name: "car", count: 412 }, { name: "motorcycle", count: 96 }, { name: "bus", count: 38 }, { name: "truck", count: 61 }];
const tracks = ["1-10", "11-20", "21-30", "31-40", "41-50", "51+"].map((b, i) => ({ len: b, tracks: [14, 22, 17, 9, 6, 4][i] }));
const tt = { contentStyle: { background: "#111A2E", border: "1px solid #ffffff22" } };
export default function Detection() {
  return (
    <div>
      <PageHeader title="Detection & Tracking" subtitle="YOLO11n + ByteTrack over UA-DETRAC image sequences (cars, motorcycles, buses, trucks). Charts show demonstration output for sequence MVI_20011; live inference jobs are not yet connected." />
      <div className={`${card} mb-4 flex flex-wrap items-center gap-4 text-sm`}>
        <span className="text-muted">Sequence</span><select className="rounded bg-white/10 px-2 py-1"><option>MVI_20011</option><option>MVI_20012</option></select>
        <span className="text-muted">Confidence</span><input type="range" min={0.1} max={0.9} step={0.05} defaultValue={0.5} className="accent-[#22D3EE]" />
        <button className="ml-auto rounded-lg bg-[#22D3EE]/20 px-4 py-1.5 text-[#22D3EE]">Run detection (demo)</button>
      </div>
      <div className="mb-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard title="Unique tracks" value={72} provenance="DEMO" /><KpiCard title="Detections" value={607} provenance="DEMO" />
        <KpiCard title="Frames processed" value={60} provenance="DEMO" /><KpiCard title="Throughput" value="24.1" unit="FPS" provenance="DEMO" />
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <ChartCard title="Class distribution" provenance="DEMO"><div className="h-60"><ResponsiveContainer><BarChart data={classes}><CartesianGrid stroke="#ffffff14" /><XAxis dataKey="name" stroke="#94a3b8" /><YAxis stroke="#94a3b8" /><Tooltip {...tt} /><Bar dataKey="count" fill="#22D3EE" radius={[4, 4, 0, 0]} /></BarChart></ResponsiveContainer></div></ChartCard>
        <ChartCard title="Vehicles per frame" provenance="DEMO"><div className="h-60"><ResponsiveContainer><LineChart data={perFrame}><CartesianGrid stroke="#ffffff14" /><XAxis dataKey="frame" stroke="#94a3b8" /><YAxis stroke="#94a3b8" /><Tooltip {...tt} /><Line dataKey="vehicles" stroke="#22D3EE" dot={false} strokeWidth={2} /></LineChart></ResponsiveContainer></div></ChartCard>
        <ChartCard title="Track length (frames)" provenance="DEMO"><div className="h-60"><ResponsiveContainer><BarChart data={tracks}><CartesianGrid stroke="#ffffff14" /><XAxis dataKey="len" stroke="#94a3b8" /><YAxis stroke="#94a3b8" /><Tooltip {...tt} /><Bar dataKey="tracks" fill="#8B5CF6" radius={[4, 4, 0, 0]} /></BarChart></ResponsiveContainer></div></ChartCard>
      </div>
    </div>
  );
}
