import { Clock } from "lucide-react";
import { EmptyState } from "@/components/shared/EmptyState";

interface ComingSoonProps {
  title: string;
  phase: number;
  description: string;
}

export function ComingSoon({ title, phase, description }: ComingSoonProps) {
  return (
    <div className="flex flex-col h-full">
      {/* Page header */}
      <div className="px-6 pt-6 pb-4 border-b border-border">
        <div className="flex items-center gap-3">
          <h2 className="text-2xl font-semibold text-text">{title}</h2>
          <span className="rounded-full border border-border px-2.5 py-0.5 text-xs font-mono text-muted">
            Phase {phase}
          </span>
        </div>
      </div>

      {/* Empty state */}
      <div className="flex-1 flex items-center justify-center">
        <EmptyState
          icon={<Clock />}
          title={`Coming in Phase ${phase}`}
          description={description}
        />
      </div>
    </div>
  );
}
