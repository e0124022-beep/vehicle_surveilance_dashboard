import { useEffect, useMemo, useState } from "react";
import { Bar, BarChart, CartesianGrid, ErrorBar, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ChartCard } from "@/components/shared/ChartCard";
import { PageHeader } from "@/components/shared/PageHeader";
import { card, monteCarlo } from "@/lib/demo";

const API = import.meta.env.VITE_API_URL ?? "http://localhost:8000";
type Ev = { n: number; seed: number; exact_match: number; char_accuracy: number; avg_latency_ms: number; failures: { id: string; gt: string; pred: string; conf: number }[] };
export default function Evaluation() {
  const [ev, setEv] = useState<Ev | null>(null);
  useEffect(() => { fetch(`${API}/api/v1/eval/ocr`).then((r) => (r.ok ? r.json() : null)).then(setEv).catch(() => null); }, []);
  const mc = useMemo(() => monteCarlo(0.12, 42), []);
  const tt = { contentStyle: { background: "#111A2E", border: "1px solid #ffffff22" } };
  const rows: [string, string][] = ev ? [["Plates evaluated", String(ev.n)], ["Exact-match accuracy", `${(ev.exact_match * 100).toFixed(1)}%`], ["Character accuracy", `${(ev.char_accuracy * 100).toFixed(1)}%`], ["Average time per plate", `${ev.avg_latency_ms} ms`]] : [];
  return (
    <div>
      <PageHeader provenance="MEASURED" title="Evaluation" subtitle="OCR accuracy on the annotated Indian plate dataset (plate crops from the XML bounding boxes) and the multi-frame validation experiment (error probability 0.12, seed 42)." />
      <div className="grid gap-4 lg:grid-cols-2">
        <div className={card}>
          <div className="mb-2 text-sm font-medium">OCR accuracy</div>
          {ev ? <table className="w-full text-sm"><tbody>{rows.map(([k, v]) => <tr key={k} className="border-t border-white/5"><td className="py-2">{k}</td><td className="text-right font-mono">{v}</td></tr>)}</tbody></table>
            : <div className="py-6 text-sm text-muted">No evaluation has been run yet. In the backend folder run <code className="text-[#22D3EE]">python -m scripts.evaluate_ocr --n 100</code> and refresh this page.</div>}
        </div>
        <ChartCard title="False-decision rate: single frame vs N-frame majority (%, 95% CI)" provenance="MEASURED" exportFileName="validation.png">
          <div className="h-64"><ResponsiveContainer><BarChart data={mc}><CartesianGrid stroke="#ffffff14" /><XAxis dataKey="window" stroke="#94a3b8" /><YAxis stroke="#94a3b8" unit="%" /><Tooltip {...tt} />
            <Bar dataKey="rate" fill="#22D3EE" radius={[4, 4, 0, 0]}><ErrorBar dataKey="ci" stroke="#fff" /></Bar></BarChart></ResponsiveContainer></div>
        </ChartCard>
      </div>
      {ev && ev.failures.length > 0 && <div className={`${card} mt-4`}>
        <div className="mb-2 text-sm font-medium">Sample misreads</div>
        <table className="w-full text-sm"><thead className="text-left text-xs text-muted"><tr><th>Ground truth</th><th>Predicted</th><th>Confidence</th></tr></thead><tbody>
          {ev.failures.slice(0, 10).map((f) => <tr key={f.id} className="border-t border-white/5"><td className="py-1.5 font-mono">{f.gt}</td><td className="font-mono">{f.pred || "—"}</td><td>{f.conf.toFixed(2)}</td></tr>)}</tbody></table></div>}
    </div>
  );
}
