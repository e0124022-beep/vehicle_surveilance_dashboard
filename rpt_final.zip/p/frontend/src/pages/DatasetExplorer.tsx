import { useEffect, useState } from "react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ChartCard } from "@/components/shared/ChartCard";
import { KpiCard } from "@/components/shared/KpiCard";
import { PageHeader } from "@/components/shared/PageHeader";
import { card } from "@/lib/demo";

const API = import.meta.env.VITE_API_URL ?? "http://localhost:8000";
type Stats = { found: boolean; root: string; images: number; annotated: number; unique_plates: number; valid_format_pct: number; by_source: Record<string, number>; by_state_code: Record<string, number> };
type Item = { id: string; source: string; state: string | null; plate: string };
export default function DatasetExplorer() {
  const [s, setS] = useState<Stats | null>(null), [err, setErr] = useState("");
  const [items, setItems] = useState<Item[]>([]), [total, setTotal] = useState(0), [page, setPage] = useState(1);
  const [source, setSource] = useState(""), [q, setQ] = useState(""), [crop, setCrop] = useState(true);
  useEffect(() => { fetch(`${API}/api/v1/datasets/plates/stats`).then((r) => r.json()).then(setS).catch(() => setErr("Backend not reachable. Start it on port 8000.")); }, []);
  useEffect(() => {
    const u = new URLSearchParams({ page: String(page), size: "24", ...(source && { source }), ...(q && { q }) });
    fetch(`${API}/api/v1/datasets/plates/items?${u}`).then((r) => r.json()).then((j) => { setItems(j.items); setTotal(j.total); }).catch(() => undefined);
  }, [page, source, q, s?.found]);
  const pages = Math.max(Math.ceil(total / 24), 1), tt = { contentStyle: { background: "#111A2E", border: "1px solid #ffffff22" } };
  return (
    <div>
      <PageHeader provenance={s?.found ? "MEASURED" : "DEMO"} title="Dataset Explorer" subtitle="Indian vehicle number-plate dataset (images with XML ground-truth plate text and bounding boxes). Counts below are computed directly from the files on disk." />
      {err && <div className={`${card} text-sm text-red-300`}>{err}</div>}
      {s && !s.found && <div className={`${card} text-sm`}>Dataset folder not found at <code className="text-[#22D3EE]">{s.root}</code>. Put the extracted dataset (folders <code>State-wise_OLX</code>, <code>google_images</code>, <code>video_images</code>) in <code>vehicle_surveillance_project/datasets/indian_plates</code> and restart the backend.</div>}
      {s?.found && <>
        <div className="mb-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
          <KpiCard title="Images" value={s.images.toLocaleString()} provenance="MEASURED" /><KpiCard title="Annotated plates" value={s.annotated.toLocaleString()} provenance="MEASURED" />
          <KpiCard title="Unique plate numbers" value={s.unique_plates.toLocaleString()} provenance="MEASURED" /><KpiCard title="Valid Indian format" value={s.valid_format_pct} unit="%" provenance="MEASURED" />
        </div>
        <div className="mb-4 grid gap-4 lg:grid-cols-2">
          <ChartCard title="Images by source" provenance="MEASURED"><div className="h-56"><ResponsiveContainer><BarChart data={Object.entries(s.by_source).map(([name, count]) => ({ name, count }))}><CartesianGrid stroke="#ffffff14" /><XAxis dataKey="name" stroke="#94a3b8" /><YAxis stroke="#94a3b8" /><Tooltip {...tt} /><Bar dataKey="count" fill="#22D3EE" radius={[4, 4, 0, 0]} /></BarChart></ResponsiveContainer></div></ChartCard>
          <ChartCard title="Top state codes (from plate text)" provenance="MEASURED"><div className="h-56"><ResponsiveContainer><BarChart data={Object.entries(s.by_state_code).map(([name, count]) => ({ name, count }))}><CartesianGrid stroke="#ffffff14" /><XAxis dataKey="name" stroke="#94a3b8" /><YAxis stroke="#94a3b8" /><Tooltip {...tt} /><Bar dataKey="count" fill="#8B5CF6" radius={[4, 4, 0, 0]} /></BarChart></ResponsiveContainer></div></ChartCard>
        </div>
        <div className={card}>
          <div className="mb-3 flex flex-wrap items-center gap-2 text-sm">
            <select className="rounded bg-white/10 px-2 py-1" value={source} onChange={(e) => { setSource(e.target.value); setPage(1); }}><option value="">All sources</option>{Object.keys(s.by_source).map((k) => <option key={k}>{k}</option>)}</select>
            <input className="rounded bg-white/10 px-3 py-1" placeholder="Search plate e.g. MH02" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
            <label className="flex items-center gap-1 text-xs text-muted"><input type="checkbox" checked={crop} onChange={(e) => setCrop(e.target.checked)} />Show plate crop</label>
            <span className="ml-auto text-xs text-muted">{total.toLocaleString()} results</span>
          </div>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-6">
            {items.map((i) => <div key={i.id} className="overflow-hidden rounded-lg border border-white/10 bg-white/5">
              <img loading="lazy" className="h-24 w-full object-cover" alt={i.plate} src={`${API}/api/v1/datasets/plates/image?rel=${encodeURIComponent(i.id)}&w=320&crop=${crop}`} />
              <div className="p-2"><div className="font-mono text-xs">{i.plate}</div><div className="truncate text-[10px] text-muted">{i.source}{i.state ? ` / ${i.state}` : ""}</div></div></div>)}
          </div>
          <div className="mt-4 flex items-center justify-center gap-3 text-sm">
            <button disabled={page <= 1} onClick={() => setPage(page - 1)} className="rounded bg-white/10 px-3 py-1 disabled:opacity-40">Prev</button>
            <span>Page {page} / {pages}</span>
            <button disabled={page >= pages} onClick={() => setPage(page + 1)} className="rounded bg-white/10 px-3 py-1 disabled:opacity-40">Next</button>
          </div>
          <p className="mt-3 text-xs text-muted">Licence note: the Indian vehicle dataset is CC BY-NC-ND 4.0 (non-commercial, no derivatives).</p>
        </div>
      </>}
    </div>
  );
}
