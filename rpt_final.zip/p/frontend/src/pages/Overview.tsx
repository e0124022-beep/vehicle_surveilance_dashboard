import { useEffect, useState } from "react";
import { Database, Fingerprint, Gauge, ScanLine, ShieldCheck, Timer } from "lucide-react";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { KpiCard } from "@/components/shared/KpiCard";
import { ChartCard } from "@/components/shared/ChartCard";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { PageHeader } from "@/components/shared/PageHeader";
import { ALERTS, SEED_VEHICLES, card } from "@/lib/demo";

const API = import.meta.env.VITE_API_URL ?? "http://localhost:8000";
const STAGES = ["Camera", "YOLO11 Detection", "ByteTrack", "Plate Localization", "Preprocessing", "EasyOCR", "Multi-frame Validation", "Database Check", "Alert"];
const PALETTE = ["#22D3EE", "#8B5CF6", "#22C55E", "#F59E0B", "#EF4444", "#3B82F6", "#EC4899", "#14B8A6"];
type Stats = { found: boolean; annotated: number; unique_plates: number; valid_format_pct: number; by_state_code: Record<string, number> };
type Ev = { exact_match: number; avg_latency_ms: number };
export default function Overview() {
  const [s, setS] = useState<Stats | null>(null), [ev, setEv] = useState<Ev | null>(null);
  useEffect(() => {
    fetch(`${API}/api/v1/datasets/plates/stats`).then((r) => r.json()).then(setS).catch(() => null);
    fetch(`${API}/api/v1/eval/ocr`).then((r) => (r.ok ? r.json() : null)).then(setEv).catch(() => null);
  }, []);
  const d = s?.found ? s : null, dash = "—";
  const donut = Object.entries(d?.by_state_code ?? {}).slice(0, 8).map(([name, value]) => ({ name, value }));
  const k = [
    ["Annotated plates", d ? d.annotated.toLocaleString() : dash, Database], ["Unique plate numbers", d ? d.unique_plates.toLocaleString() : dash, Fingerprint],
    ["Valid Indian format", d ? `${d.valid_format_pct}%` : dash, ScanLine], ["Watchlist entries", SEED_VEHICLES.length, ShieldCheck],
    ["OCR exact-match", ev ? `${(ev.exact_match * 100).toFixed(1)}%` : dash, Gauge], ["Avg OCR time", ev ? `${ev.avg_latency_ms} ms` : dash, Timer],
  ] as const;
  return (
    <div>
      <PageHeader provenance="MEASURED" title="Overview" subtitle="Summary of the plate dataset, OCR accuracy and the alerting pipeline. Dataset figures are computed from the files on disk; OCR figures appear after the evaluation script has been run." />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-3 xl:grid-cols-6">
        {k.map(([t, v, I]) => <KpiCard key={t} title={t} value={v} provenance="MEASURED" icon={<I size={16} />} />)}
      </div>
      <div className={`${card} mt-4`}>
        <div className="mb-3 text-sm font-medium">Processing pipeline</div>
        <div className="flex flex-wrap items-center gap-2">
          {STAGES.map((st, i) => (
            <div key={st} className="flex items-center gap-2">
              <span className="rounded-lg border border-[#22D3EE]/30 bg-[#22D3EE]/10 px-3 py-1.5 text-xs text-[#22D3EE]">{i + 1}. {st}</span>
              {i < STAGES.length - 1 && <span className="text-muted">→</span>}
            </div>
          ))}
        </div>
      </div>
      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <ChartCard title="Plates by state code" provenance="MEASURED" exportFileName="state-codes.png">
          <div className="h-64">{donut.length ? <ResponsiveContainer><PieChart>
            <Pie data={donut} dataKey="value" nameKey="name" innerRadius={55} outerRadius={95} paddingAngle={2}>{donut.map((x, i) => <Cell key={x.name} fill={PALETTE[i % PALETTE.length]} />)}</Pie>
            <Tooltip contentStyle={{ background: "#111A2E", border: "1px solid #ffffff22" }} />
          </PieChart></ResponsiveContainer> : <div className="flex h-full items-center justify-center text-sm text-muted">Start the backend to load dataset statistics.</div>}</div>
        </ChartCard>
        <div className={`${card} lg:col-span-2`}>
          <div className="mb-3 text-sm font-medium">Recent alerts <span className="text-xs text-muted">(SMS notifications are logged, never sent)</span></div>
          <table className="w-full text-sm"><thead className="text-left text-xs text-muted"><tr><th className="pb-2">Time</th><th>Plate</th><th>Status</th><th>Latency</th></tr></thead>
            <tbody>{ALERTS.slice(-6).reverse().map((a) => <tr key={a.id} className="border-t border-white/5"><td className="py-2">{a.time}</td><td className="font-mono">{a.plate}</td><td><StatusBadge status={a.status} /></td><td>{a.latency} ms</td></tr>)}</tbody></table>
        </div>
      </div>
    </div>
  );
}
