import { useState } from "react";
import { Loader2, Upload } from "lucide-react";
import { PageHeader } from "@/components/shared/PageHeader";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { card, classify, parsePlate } from "@/lib/demo";

type Row = { variant: string; raw: string; clean: string; conf: number; valid?: boolean };
type Res = { rows: Row[]; best: { plate: string; conf: number; valid: boolean; parts: Record<string, string> | null }; live: boolean };
const API = import.meta.env.VITE_API_URL ?? "http://localhost:8000";

export default function AnprLab() {
  const [file, setFile] = useState<File | null>(null), [img, setImg] = useState<string | null>(null);
  const [res, setRes] = useState<Res | null>(null), [busy, setBusy] = useState(false), [err, setErr] = useState("");
  const run = async () => {
    if (!file) return;
    setBusy(true); setErr(""); setRes(null);
    try {
      const fd = new FormData(); fd.append("file", file);
      const r = await fetch(`${API}/api/v1/anpr`, { method: "POST", body: fd });
      const j = await r.json();
      if (!r.ok) throw new Error(j.detail ?? `HTTP ${r.status}`);
      setRes({ rows: j.variants.map((v: Row & { variant: string }) => v), best: j.best, live: true });
    } catch (e) {
      setErr(e instanceof TypeError ? "Backend not reachable. Start it on port 8000." : (e as Error).message);
    } finally { setBusy(false); }
  };
  const best = res?.best, parts = best?.parts ?? null;
  return (
    <div>
      <PageHeader title="ANPR Lab" subtitle="Upload a plate or vehicle image. The backend runs EasyOCR on four preprocessing variants, applies Indian-plate position correction and picks the best valid reading." />
      <div className="grid gap-4 lg:grid-cols-2">
        <div className={card}>
          <label className="flex h-56 cursor-pointer flex-col items-center justify-center rounded-lg border border-dashed border-white/20 text-sm text-muted hover:border-[#22D3EE]">
            {img ? <img src={img} alt="upload" className="max-h-52 rounded" /> : <><Upload className="mb-2" />Drop or click to upload a plate image</>}
            <input type="file" accept="image/*" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) { setFile(f); setImg(URL.createObjectURL(f)); setRes(null); setErr(""); } }} />
          </label>
          <button disabled={!file || busy} onClick={run} className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg bg-[#22D3EE] py-2 text-sm font-medium text-black disabled:opacity-40">
            {busy && <Loader2 size={14} className="animate-spin" />}{busy ? "Reading plate… (first run downloads models)" : "Run OCR"}
          </button>
          {err && <div className="mt-3 rounded bg-red-500/10 p-2 text-xs text-red-300">{err}</div>}
        </div>
        <div className={card}>
          <div className="mb-2 text-sm font-medium">Best candidate</div>
          {best ? (<div className="space-y-2">
            <div className="font-mono text-3xl tracking-widest">{best.plate || "—"}</div>
            <div className="text-sm">Confidence <b>{best.conf.toFixed(2)}</b> {best.conf < 0.7 && <span className="ml-2 rounded bg-amber-500/20 px-2 py-0.5 text-xs text-amber-300">LOW CONFIDENCE — not validated</span>}</div>
            {parts ? <div className="grid grid-cols-4 gap-2 text-center text-xs">{Object.entries(parts).map(([k, v]) => <div key={k} className="rounded bg-white/5 p-2"><div className="text-muted">{k}</div><div className="font-mono text-sm">{k === "state" ? parsePlate(best.plate)?.state ?? v : v}</div></div>)}</div> : <div className="text-xs text-red-400">Does not match the Indian plate format</div>}
            <div className="text-sm">Database: <StatusBadge status={classify(best.plate)} /></div>
          </div>) : <div className="text-sm text-muted">Upload an image and run OCR to see results.</div>}
        </div>
      </div>
      {res && <div className={`${card} mt-4`}>
        <div className="mb-2 text-sm font-medium">OCR candidates per preprocessing variant</div>
        <table className="w-full text-sm"><thead className="text-left text-xs text-muted"><tr><th>Variant</th><th>Raw text</th><th>After position correction</th><th>Confidence</th></tr></thead><tbody>
          {res.rows.map((r) => <tr key={r.variant} className="border-t border-white/5"><td className="py-1.5">{r.variant}</td><td className="font-mono">{r.raw || "—"}</td><td className="font-mono">{r.clean || "—"}</td><td>{r.conf.toFixed(2)}</td></tr>)}
        </tbody></table></div>}
    </div>
  );
}
