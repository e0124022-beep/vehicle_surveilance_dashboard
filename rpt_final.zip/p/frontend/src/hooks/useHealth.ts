import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

export interface ModelStatus {
  yolo: boolean;
  easyocr: boolean;
}

export interface HealthResponse {
  status: "ok" | "degraded";
  version: string;
  demo_mode: boolean;
  uptime_seconds: number;
  models_loaded: ModelStatus;
  errors: string[];
  timestamp: string;
}

export function useHealth() {
  return useQuery<HealthResponse>({
    queryKey: ["health"],
    queryFn: async () => {
      const res = await api.get<HealthResponse>("/api/v1/health");
      return res.data;
    },
    refetchInterval: 30_000,
    staleTime: 30_000,
  });
}
