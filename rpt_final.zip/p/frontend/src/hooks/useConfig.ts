import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

export interface ConfigResponse {
  demo_mode: boolean;
  app_env: string;
  app_version: string;
  backend_port: number;
  frontend_port: number;
  yolo_model_path: string;
  yolo_confidence: number;
  device: string;
  validator_window: number;
  validator_min_conf: number;
  datasets_root: string;
  outputs_root: string;
  max_upload_size_mb: number;
}

export function useConfig() {
  return useQuery<ConfigResponse>({
    queryKey: ["config"],
    queryFn: async () => {
      const res = await api.get<ConfigResponse>("/api/v1/config");
      return res.data;
    },
    staleTime: 60_000,
  });
}
